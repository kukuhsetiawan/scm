<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Produk extends My_Controller
{
     protected $access = array('Pemilik', 'Gudang','Produksi');

    function __construct()
    {
        parent::__construct();
        $this->load->model('Produk_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $produk = $this->Produk_model->get_all();

        $title = array(
            'title' => 'produk',
        );

        $data = array(
            'produk_data' => $produk,
        );
        $this->load->view('cover/header', $title);
        $this->load->view('produk/produk_list', $data);
        $this->load->view('cover/footer');
    }

    public function read($id) 
    {
        $row = $this->Produk_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id' => $row->id,
		'kode_produk' => $row->kode_produk,
		'nama_produk' => $row->nama_produk,
		'id_kategori' => $row->id_kategori,
		'satuan_produk' => $row->satuan_produk,
		'harga_pack' => $row->harga_pack,
	    );

            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('produk/produk_read', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('produk'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('produk/create_action'),
	    'id' => set_value('id'),
	    'kode_produk' => set_value('kode_produk'),
	    'nama_produk' => set_value('nama_produk'),
	    'id_kategori' => set_value('id_kategori'),
	    'satuan_produk' => set_value('satuan_produk'),
	    'harga_pack' => set_value('harga_pack'),
	);
         $title = array(
            'title' => 'Detail',
            );
        $this->load->view('cover/header', $title);
        $this->load->view('produk/produk_form', $data);
        $this->load->view('cover/footer');
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'kode_produk' => $this->input->post('kode_produk',TRUE),
		'nama_produk' => $this->input->post('nama_produk',TRUE),
		'id_kategori' => $this->input->post('id_kategori',TRUE),
		'satuan_produk' => $this->input->post('satuan_produk',TRUE),
		'harga_pack' => $this->input->post('harga_pack',TRUE),
	    );
        
            $this->Produk_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('produk'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Produk_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('produk/update_action'),
		'id' => set_value('id', $row->id),
		'kode_produk' => set_value('kode_produk', $row->kode_produk),
		'nama_produk' => set_value('nama_produk', $row->nama_produk),
		'id_kategori' => set_value('id_kategori', $row->id_kategori),
		'satuan_produk' => set_value('satuan_produk', $row->satuan_produk),
		'harga_pack' => set_value('harga_pack', $row->harga_pack),
	    );
            
            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('produk/produk_form', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('produk'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'kode_produk' => $this->input->post('kode_produk',TRUE),
		'nama_produk' => $this->input->post('nama_produk',TRUE),
		'id_kategori' => $this->input->post('id_kategori',TRUE),
		'satuan_produk' => $this->input->post('satuan_produk',TRUE),
		'harga_pack' => $this->input->post('harga_pack',TRUE),
	    );

            $this->Produk_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('produk'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Produk_model->get_by_id($id);

        if ($row) {
            $this->Produk_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('produk'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('produk'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('kode_produk', 'kode produk', 'trim|required');
	$this->form_validation->set_rules('nama_produk', 'nama produk', 'trim|required');
	$this->form_validation->set_rules('id_kategori', 'id kategori', 'trim|required');
	$this->form_validation->set_rules('satuan_produk', 'satuan produk', 'trim|required');
	$this->form_validation->set_rules('harga_pack', 'harga pack', 'trim|required|numeric');

	$this->form_validation->set_rules('id', 'id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "produk.xls";
        $judul = "produk";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Kode Produk");
	xlsWriteLabel($tablehead, $kolomhead++, "Nama Produk");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Kategori");
	xlsWriteLabel($tablehead, $kolomhead++, "Satuan Produk");
	xlsWriteLabel($tablehead, $kolomhead++, "Harga Pack");

	foreach ($this->Produk_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->kode_produk);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nama_produk);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_kategori);
	    xlsWriteLabel($tablebody, $kolombody++, $data->satuan_produk);
	    xlsWriteNumber($tablebody, $kolombody++, $data->harga_pack);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=produk.doc");

        $data = array(
            'produk_data' => $this->Produk_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('produk/produk_doc',$data);
    }

}

/* End of file Produk.php */
/* Location: ./application/controllers/Produk.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-06-02 02:05:24 */
/* http://harviacode.com */
<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Peramalan_bahan_baku extends My_Controller
{
     protected $access = array('Admin', 'Editor','Author');

    function __construct()
    {
        parent::__construct();
        $this->load->model('Peramalan_bahan_baku_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $peramalan_bahan_baku = $this->Peramalan_bahan_baku_model->get_all();

        $title = array(
            'title' => 'peramalan_bahan_baku',
        );

        $data = array(
            'peramalan_bahan_baku_data' => $peramalan_bahan_baku,
        );
        $this->load->view('cover/header', $title);
        $this->load->view('peramalan_bahan_baku/peramalan_bahan_baku_list', $data);
        $this->load->view('cover/footer');
    }

    public function read($id) 
    {
        $row = $this->Peramalan_bahan_baku_model->get_by_id($id);
        if ($row) {
            $data = array(
		'no_peramalan' => $row->no_peramalan,
		'id_bahan_baku' => $row->id_bahan_baku,
		'periode' => $row->periode,
		'id_user' => $row->id_user,
		'permintaan' => $row->permintaan,
		'nilai_alpha' => $row->nilai_alpha,
		'hasil_peramalan' => $row->hasil_peramalan,
		'id_pengadaan' => $row->id_pengadaan,
	    );

            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('peramalan_bahan_baku/peramalan_bahan_baku_read', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('peramalan_bahan_baku'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('peramalan_bahan_baku/create_action'),
	    'no_peramalan' => set_value('no_peramalan'),
	    'id_bahan_baku' => set_value('id_bahan_baku'),
	    'periode' => set_value('periode'),
	    'id_user' => set_value('id_user'),
	    'permintaan' => set_value('permintaan'),
	    'nilai_alpha' => set_value('nilai_alpha'),
	    'hasil_peramalan' => set_value('hasil_peramalan'),
	    'id_pengadaan' => set_value('id_pengadaan'),
	);
         $title = array(
            'title' => 'Detail',
            );
        $this->load->view('cover/header', $title);
        $this->load->view('peramalan_bahan_baku/peramalan_bahan_baku_form', $data);
        $this->load->view('cover/footer');
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'id_bahan_baku' => $this->input->post('id_bahan_baku',TRUE),
		'periode' => $this->input->post('periode',TRUE),
		'id_user' => $this->input->post('id_user',TRUE),
		'permintaan' => $this->input->post('permintaan',TRUE),
		'nilai_alpha' => $this->input->post('nilai_alpha',TRUE),
		'hasil_peramalan' => $this->input->post('hasil_peramalan',TRUE),
		'id_pengadaan' => $this->input->post('id_pengadaan',TRUE),
	    );
        
            $this->Peramalan_bahan_baku_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('peramalan_bahan_baku'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Peramalan_bahan_baku_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('peramalan_bahan_baku/update_action'),
		'no_peramalan' => set_value('no_peramalan', $row->no_peramalan),
		'id_bahan_baku' => set_value('id_bahan_baku', $row->id_bahan_baku),
		'periode' => set_value('periode', $row->periode),
		'id_user' => set_value('id_user', $row->id_user),
		'permintaan' => set_value('permintaan', $row->permintaan),
		'nilai_alpha' => set_value('nilai_alpha', $row->nilai_alpha),
		'hasil_peramalan' => set_value('hasil_peramalan', $row->hasil_peramalan),
		'id_pengadaan' => set_value('id_pengadaan', $row->id_pengadaan),
	    );
            
            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('peramalan_bahan_baku/peramalan_bahan_baku_form', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('peramalan_bahan_baku'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('no_peramalan', TRUE));
        } else {
            $data = array(
		'id_bahan_baku' => $this->input->post('id_bahan_baku',TRUE),
		'periode' => $this->input->post('periode',TRUE),
		'id_user' => $this->input->post('id_user',TRUE),
		'permintaan' => $this->input->post('permintaan',TRUE),
		'nilai_alpha' => $this->input->post('nilai_alpha',TRUE),
		'hasil_peramalan' => $this->input->post('hasil_peramalan',TRUE),
		'id_pengadaan' => $this->input->post('id_pengadaan',TRUE),
	    );

            $this->Peramalan_bahan_baku_model->update($this->input->post('no_peramalan', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('peramalan_bahan_baku'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Peramalan_bahan_baku_model->get_by_id($id);

        if ($row) {
            $this->Peramalan_bahan_baku_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('peramalan_bahan_baku'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('peramalan_bahan_baku'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('id_bahan_baku', 'id bahan baku', 'trim|required');
	$this->form_validation->set_rules('periode', 'periode', 'trim|required');
	$this->form_validation->set_rules('id_user', 'id user', 'trim|required');
	$this->form_validation->set_rules('permintaan', 'permintaan', 'trim|required');
	$this->form_validation->set_rules('nilai_alpha', 'nilai alpha', 'trim|required|numeric');
	$this->form_validation->set_rules('hasil_peramalan', 'hasil peramalan', 'trim|required|numeric');
	$this->form_validation->set_rules('id_pengadaan', 'id pengadaan', 'trim|required');

	$this->form_validation->set_rules('no_peramalan', 'no_peramalan', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "peramalan_bahan_baku.xls";
        $judul = "peramalan_bahan_baku";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Bahan Baku");
	xlsWriteLabel($tablehead, $kolomhead++, "Periode");
	xlsWriteLabel($tablehead, $kolomhead++, "Id User");
	xlsWriteLabel($tablehead, $kolomhead++, "Permintaan");
	xlsWriteLabel($tablehead, $kolomhead++, "Nilai Alpha");
	xlsWriteLabel($tablehead, $kolomhead++, "Hasil Peramalan");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Pengadaan");

	foreach ($this->Peramalan_bahan_baku_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_bahan_baku);
	    xlsWriteLabel($tablebody, $kolombody++, $data->periode);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_user);
	    xlsWriteNumber($tablebody, $kolombody++, $data->permintaan);
	    xlsWriteNumber($tablebody, $kolombody++, $data->nilai_alpha);
	    xlsWriteNumber($tablebody, $kolombody++, $data->hasil_peramalan);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_pengadaan);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=peramalan_bahan_baku.doc");

        $data = array(
            'peramalan_bahan_baku_data' => $this->Peramalan_bahan_baku_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('peramalan_bahan_baku/peramalan_bahan_baku_doc',$data);
    }

}

/* End of file Peramalan_bahan_baku.php */
/* Location: ./application/controllers/Peramalan_bahan_baku.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-06-02 02:05:23 */
/* http://harviacode.com */
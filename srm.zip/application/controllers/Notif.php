<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Notif extends My_Controller
{
     protected $access = array('Admin', 'Editor','Author');

    function __construct()
    {
        parent::__construct();
        $this->load->model('Notif_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $notif = $this->Notif_model->get_all();

        $title = array(
            'title' => 'notif',
        );

        $data = array(
            'notif_data' => $notif,
        );
        $this->load->view('cover/header', $title);
        $this->load->view('notif/notif_list', $data);
        $this->load->view('cover/footer');
    }

    public function read($id) 
    {
        $row = $this->Notif_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id' => $row->id,
		'user' => $row->user,
		'dari' => $row->dari,
		'ke' => $row->ke,
		'tanggal' => $row->tanggal,
		'tipe' => $row->tipe,
		'template' => $row->template,
		'id_' => $row->id_,
		'link' => $row->link,
	    );

            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('notif/notif_read', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('notif'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('notif/create_action'),
	    'id' => set_value('id'),
	    'user' => set_value('user'),
	    'dari' => set_value('dari'),
	    'ke' => set_value('ke'),
	    'tanggal' => set_value('tanggal'),
	    'tipe' => set_value('tipe'),
	    'template' => set_value('template'),
	    'id_' => set_value('id_'),
	    'link' => set_value('link'),
	);
         $title = array(
            'title' => 'Detail',
            );
        $this->load->view('cover/header', $title);
        $this->load->view('notif/notif_form', $data);
        $this->load->view('cover/footer');
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'user' => $this->input->post('user',TRUE),
		'dari' => $this->input->post('dari',TRUE),
		'ke' => $this->input->post('ke',TRUE),
		'tanggal' => $this->input->post('tanggal',TRUE),
		'tipe' => $this->input->post('tipe',TRUE),
		'template' => $this->input->post('template',TRUE),
		'id_' => $this->input->post('id_',TRUE),
		'link' => $this->input->post('link',TRUE),
	    );
        
            $this->Notif_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('notif'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Notif_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('notif/update_action'),
		'id' => set_value('id', $row->id),
		'user' => set_value('user', $row->user),
		'dari' => set_value('dari', $row->dari),
		'ke' => set_value('ke', $row->ke),
		'tanggal' => set_value('tanggal', $row->tanggal),
		'tipe' => set_value('tipe', $row->tipe),
		'template' => set_value('template', $row->template),
		'id_' => set_value('id_', $row->id_),
		'link' => set_value('link', $row->link),
	    );
            
            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('notif/notif_form', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('notif'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'user' => $this->input->post('user',TRUE),
		'dari' => $this->input->post('dari',TRUE),
		'ke' => $this->input->post('ke',TRUE),
		'tanggal' => $this->input->post('tanggal',TRUE),
		'tipe' => $this->input->post('tipe',TRUE),
		'template' => $this->input->post('template',TRUE),
		'id_' => $this->input->post('id_',TRUE),
		'link' => $this->input->post('link',TRUE),
	    );

            $this->Notif_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('notif'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Notif_model->get_by_id($id);

        if ($row) {
            $this->Notif_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('notif'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('notif'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('user', 'user', 'trim|required');
	$this->form_validation->set_rules('dari', 'dari', 'trim|required');
	$this->form_validation->set_rules('ke', 'ke', 'trim|required');
	$this->form_validation->set_rules('tanggal', 'tanggal', 'trim|required');
	$this->form_validation->set_rules('tipe', 'tipe', 'trim|required');
	$this->form_validation->set_rules('template', 'template', 'trim|required');
	$this->form_validation->set_rules('id_', 'id ', 'trim|required');
	$this->form_validation->set_rules('link', 'link', 'trim|required');

	$this->form_validation->set_rules('id', 'id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "notif.xls";
        $judul = "notif";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "User");
	xlsWriteLabel($tablehead, $kolomhead++, "Dari");
	xlsWriteLabel($tablehead, $kolomhead++, "Ke");
	xlsWriteLabel($tablehead, $kolomhead++, "Tanggal");
	xlsWriteLabel($tablehead, $kolomhead++, "Tipe");
	xlsWriteLabel($tablehead, $kolomhead++, "Template");
	xlsWriteLabel($tablehead, $kolomhead++, "Id ");
	xlsWriteLabel($tablehead, $kolomhead++, "Link");

	foreach ($this->Notif_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->user);
	    xlsWriteLabel($tablebody, $kolombody++, $data->dari);
	    xlsWriteLabel($tablebody, $kolombody++, $data->ke);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tanggal);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tipe);
	    xlsWriteNumber($tablebody, $kolombody++, $data->template);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_);
	    xlsWriteLabel($tablebody, $kolombody++, $data->link);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=notif.doc");

        $data = array(
            'notif_data' => $this->Notif_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('notif/notif_doc',$data);
    }

}

/* End of file Notif.php */
/* Location: ./application/controllers/Notif.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-05-09 17:32:12 */
/* http://harviacode.com */
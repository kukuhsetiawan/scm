<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Kapasitas extends My_Controller
{
     protected $access = array('Admin', 'Editor','Author');

    function __construct()
    {
        parent::__construct();
        $this->load->model('Kapasitas_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $kapasitas = $this->Kapasitas_model->get_all();

        $title = array(
            'title' => 'kapasitas',
        );

        $data = array(
            'kapasitas_data' => $kapasitas,
        );
        $this->load->view('cover/header', $title);
        $this->load->view('kapasitas/kapasitas_list', $data);
        $this->load->view('cover/footer');
    }

    public function read($id) 
    {
        $row = $this->Kapasitas_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id' => $row->id,
		'no_polisi' => $row->no_polisi,
		'id_produk' => $row->id_produk,
		'jumlah' => $row->jumlah,
	    );

            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('kapasitas/kapasitas_read', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('kapasitas'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('kapasitas/create_action'),
	    'id' => set_value('id'),
	    'no_polisi' => set_value('no_polisi'),
	    'id_produk' => set_value('id_produk'),
	    'jumlah' => set_value('jumlah'),
	);
         $title = array(
            'title' => 'Detail',
            );
        $this->load->view('cover/header', $title);
        $this->load->view('kapasitas/kapasitas_form', $data);
        $this->load->view('cover/footer');
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'no_polisi' => $this->input->post('no_polisi',TRUE),
		'id_produk' => $this->input->post('id_produk',TRUE),
		'jumlah' => $this->input->post('jumlah',TRUE),
	    );
        
            $this->Kapasitas_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('kapasitas'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Kapasitas_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('kapasitas/update_action'),
		'id' => set_value('id', $row->id),
		'no_polisi' => set_value('no_polisi', $row->no_polisi),
		'id_produk' => set_value('id_produk', $row->id_produk),
		'jumlah' => set_value('jumlah', $row->jumlah),
	    );
            
            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('kapasitas/kapasitas_form', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('kapasitas'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'no_polisi' => $this->input->post('no_polisi',TRUE),
		'id_produk' => $this->input->post('id_produk',TRUE),
		'jumlah' => $this->input->post('jumlah',TRUE),
	    );

            $this->Kapasitas_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('kapasitas'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Kapasitas_model->get_by_id($id);

        if ($row) {
            $this->Kapasitas_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('kapasitas'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('kapasitas'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('no_polisi', 'no polisi', 'trim|required');
	$this->form_validation->set_rules('id_produk', 'id produk', 'trim|required');
	$this->form_validation->set_rules('jumlah', 'jumlah', 'trim|required');

	$this->form_validation->set_rules('id', 'id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "kapasitas.xls";
        $judul = "kapasitas";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "No Polisi");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Produk");
	xlsWriteLabel($tablehead, $kolomhead++, "Jumlah");

	foreach ($this->Kapasitas_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->no_polisi);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_produk);
	    xlsWriteNumber($tablebody, $kolombody++, $data->jumlah);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=kapasitas.doc");

        $data = array(
            'kapasitas_data' => $this->Kapasitas_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('kapasitas/kapasitas_doc',$data);
    }

}

/* End of file Kapasitas.php */
/* Location: ./application/controllers/Kapasitas.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-05-09 17:32:11 */
/* http://harviacode.com */
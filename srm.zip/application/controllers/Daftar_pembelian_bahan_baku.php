<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Daftar_pembelian_bahan_baku extends My_Controller
{
     protected $access = array('Admin', 'Editor','Author');

    function __construct()
    {
        parent::__construct();
        $this->load->model('Daftar_pembelian_bahan_baku_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $daftar_pembelian_bahan_baku = $this->Daftar_pembelian_bahan_baku_model->get_all();

        $title = array(
            'title' => 'daftar_pembelian_bahan_baku',
        );

        $data = array(
            'daftar_pembelian_bahan_baku_data' => $daftar_pembelian_bahan_baku,
        );
        $this->load->view('cover/header', $title);
        $this->load->view('daftar_pembelian_bahan_baku/daftar_pembelian_bahan_baku_list', $data);
        $this->load->view('cover/footer');
    }

    public function read($id) 
    {
        $row = $this->Daftar_pembelian_bahan_baku_model->get_by_id($id);
        if ($row) {
            $data = array(
		'no_kebutuhan' => $row->no_kebutuhan,
		'tgl_pemesanan' => $row->tgl_pemesanan,
		'id_user' => $row->id_user,
		'status_pemesanan' => $row->status_pemesanan,
		'total_beli' => $row->total_beli,
	    );

            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('daftar_pembelian_bahan_baku/daftar_pembelian_bahan_baku_read', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('daftar_pembelian_bahan_baku'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('daftar_pembelian_bahan_baku/create_action'),
	    'no_kebutuhan' => set_value('no_kebutuhan'),
	    'tgl_pemesanan' => set_value('tgl_pemesanan'),
	    'id_user' => set_value('id_user'),
	    'status_pemesanan' => set_value('status_pemesanan'),
	    'total_beli' => set_value('total_beli'),
	);
         $title = array(
            'title' => 'Detail',
            );
        $this->load->view('cover/header', $title);
        $this->load->view('daftar_pembelian_bahan_baku/daftar_pembelian_bahan_baku_form', $data);
        $this->load->view('cover/footer');
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'tgl_pemesanan' => $this->input->post('tgl_pemesanan',TRUE),
		'id_user' => $this->input->post('id_user',TRUE),
		'status_pemesanan' => $this->input->post('status_pemesanan',TRUE),
		'total_beli' => $this->input->post('total_beli',TRUE),
	    );
        
            $this->Daftar_pembelian_bahan_baku_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('daftar_pembelian_bahan_baku'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Daftar_pembelian_bahan_baku_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('daftar_pembelian_bahan_baku/update_action'),
		'no_kebutuhan' => set_value('no_kebutuhan', $row->no_kebutuhan),
		'tgl_pemesanan' => set_value('tgl_pemesanan', $row->tgl_pemesanan),
		'id_user' => set_value('id_user', $row->id_user),
		'status_pemesanan' => set_value('status_pemesanan', $row->status_pemesanan),
		'total_beli' => set_value('total_beli', $row->total_beli),
	    );
            
            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('daftar_pembelian_bahan_baku/daftar_pembelian_bahan_baku_form', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('daftar_pembelian_bahan_baku'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('no_kebutuhan', TRUE));
        } else {
            $data = array(
		'tgl_pemesanan' => $this->input->post('tgl_pemesanan',TRUE),
		'id_user' => $this->input->post('id_user',TRUE),
		'status_pemesanan' => $this->input->post('status_pemesanan',TRUE),
		'total_beli' => $this->input->post('total_beli',TRUE),
	    );

            $this->Daftar_pembelian_bahan_baku_model->update($this->input->post('no_kebutuhan', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('daftar_pembelian_bahan_baku'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Daftar_pembelian_bahan_baku_model->get_by_id($id);

        if ($row) {
            $this->Daftar_pembelian_bahan_baku_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('daftar_pembelian_bahan_baku'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('daftar_pembelian_bahan_baku'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('tgl_pemesanan', 'tgl pemesanan', 'trim|required');
	$this->form_validation->set_rules('id_user', 'id user', 'trim|required');
	$this->form_validation->set_rules('status_pemesanan', 'status pemesanan', 'trim|required');
	$this->form_validation->set_rules('total_beli', 'total beli', 'trim|required|numeric');

	$this->form_validation->set_rules('no_kebutuhan', 'no_kebutuhan', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "daftar_pembelian_bahan_baku.xls";
        $judul = "daftar_pembelian_bahan_baku";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Tgl Pemesanan");
	xlsWriteLabel($tablehead, $kolomhead++, "Id User");
	xlsWriteLabel($tablehead, $kolomhead++, "Status Pemesanan");
	xlsWriteLabel($tablehead, $kolomhead++, "Total Beli");

	foreach ($this->Daftar_pembelian_bahan_baku_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tgl_pemesanan);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_user);
	    xlsWriteLabel($tablebody, $kolombody++, $data->status_pemesanan);
	    xlsWriteNumber($tablebody, $kolombody++, $data->total_beli);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=daftar_pembelian_bahan_baku.doc");

        $data = array(
            'daftar_pembelian_bahan_baku_data' => $this->Daftar_pembelian_bahan_baku_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('daftar_pembelian_bahan_baku/daftar_pembelian_bahan_baku_doc',$data);
    }

}

/* End of file Daftar_pembelian_bahan_baku.php */
/* Location: ./application/controllers/Daftar_pembelian_bahan_baku.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-05-09 17:32:09 */
/* http://harviacode.com */
<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Notif_template extends My_Controller
{
     protected $access = array('Admin', 'Editor','Author');

    function __construct()
    {
        parent::__construct();
        $this->load->model('Notif_template_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $notif_template = $this->Notif_template_model->get_all();

        $title = array(
            'title' => 'notif_template',
        );

        $data = array(
            'notif_template_data' => $notif_template,
        );
        $this->load->view('cover/header', $title);
        $this->load->view('notif_template/notif_template_list', $data);
        $this->load->view('cover/footer');
    }

    public function read($id) 
    {
        $row = $this->Notif_template_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id' => $row->id,
		'judul' => $row->judul,
		'detail' => $row->detail,
	    );

            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('notif_template/notif_template_read', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('notif_template'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('notif_template/create_action'),
	    'id' => set_value('id'),
	    'judul' => set_value('judul'),
	    'detail' => set_value('detail'),
	);
         $title = array(
            'title' => 'Detail',
            );
        $this->load->view('cover/header', $title);
        $this->load->view('notif_template/notif_template_form', $data);
        $this->load->view('cover/footer');
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'judul' => $this->input->post('judul',TRUE),
		'detail' => $this->input->post('detail',TRUE),
	    );
        
            $this->Notif_template_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('notif_template'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Notif_template_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('notif_template/update_action'),
		'id' => set_value('id', $row->id),
		'judul' => set_value('judul', $row->judul),
		'detail' => set_value('detail', $row->detail),
	    );
            
            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('notif_template/notif_template_form', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('notif_template'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'judul' => $this->input->post('judul',TRUE),
		'detail' => $this->input->post('detail',TRUE),
	    );

            $this->Notif_template_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('notif_template'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Notif_template_model->get_by_id($id);

        if ($row) {
            $this->Notif_template_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('notif_template'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('notif_template'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('judul', 'judul', 'trim|required');
	$this->form_validation->set_rules('detail', 'detail', 'trim|required');

	$this->form_validation->set_rules('id', 'id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "notif_template.xls";
        $judul = "notif_template";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Judul");
	xlsWriteLabel($tablehead, $kolomhead++, "Detail");

	foreach ($this->Notif_template_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->judul);
	    xlsWriteLabel($tablebody, $kolombody++, $data->detail);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=notif_template.doc");

        $data = array(
            'notif_template_data' => $this->Notif_template_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('notif_template/notif_template_doc',$data);
    }

}

/* End of file Notif_template.php */
/* Location: ./application/controllers/Notif_template.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-05-09 17:32:13 */
/* http://harviacode.com */
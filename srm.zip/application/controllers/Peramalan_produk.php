<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Peramalan_produk extends MY_Controller {
    
    protected $access = array('Gudang','Pengadaan','Keuangan','Pemilik','Pemasaran','Produksi', 'Distribusi');

    function __construct()
    {
        parent::__construct();
        $this->load->model('Peramalan_produk_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'peramalan_produk/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'peramalan_produk/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'peramalan_produk/index.html';
            $config['first_url'] = base_url() . 'peramalan_produk/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Peramalan_produk_model->total_rows($q);
        $peramalan_produk = $this->Peramalan_produk_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'peramalan_produk_data' => $peramalan_produk,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );

        $this->load->view('cover/header');
        $this->load->view('peramalan_produk/peramalan_produk_list', $data);
    }

    public function read($id) 
    {
        $row = $this->Peramalan_produk_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id' => $row->id,
		'nama_peramalan' => $row->nama_peramalan,
		'tanggal' => $row->tanggal,
		'produk' => $row->produk,
		'jumlah_produk' => $row->jumlah_produk,
	    );
            $this->load->view('cover/header');
            $this->load->view('peramalan_produk/peramalan_produk_read', $data);
            $this->load->view('footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('cover/peramalan_produk'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Tambah',
            'action' => site_url('peramalan_produk/create_action'),
	    'id' => set_value('id'),
	    'nama_peramalan' => set_value('nama_peramalan'),
	    'tanggal' => set_value('tanggal'),
	    'produk' => set_value('produk'),
	    'jumlah_produk' => set_value('jumlah_produk'),
        'content_produk' => $this->db->get('produk')
	);

        $this->load->view('cover/header');
        $this->load->view('peramalan_produk/peramalan_produk_form', $data);
        $this->load->view('cover/footer');
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'nama_peramalan' => $this->input->post('nama_peramalan',TRUE),
		'tanggal' => $this->input->post('tanggal',TRUE),
		'produk' => $this->input->post('produk',TRUE),
		'jumlah_produk' => $this->input->post('jumlah_produk',TRUE),
	    );

            $this->Peramalan_produk_model->insert($data);
            $this->session->set_flashdata('message', '<div class="col-md-12"><div class="alert alert-success" id="alert">Create Record Success</div></div>');
            redirect(site_url('peramalan_produk'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Peramalan_produk_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('peramalan_produk/update_action'),
		'id' => set_value('id', $row->id),
		'nama_peramalan' => set_value('nama_peramalan', $row->nama_peramalan),
		'tanggal' => set_value('tanggal', $row->tanggal),
		'produk' => set_value('produk', $row->produk),
		'jumlah_produk' => set_value('jumlah_produk', $row->jumlah_produk),
        'content_produk' => $this->db->get('produk')
	    );

            $this->load->view('header');
            $this->load->view('peramalan_produk/peramalan_produk_form', $data);
            $this->load->view('footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('peramalan_produk'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'nama_peramalan' => $this->input->post('nama_peramalan',TRUE),
		'tanggal' => $this->input->post('tanggal',TRUE),
		'produk' => $this->input->post('produk',TRUE),
		'jumlah_produk' => $this->input->post('jumlah_produk',TRUE),
	    );

            $this->Peramalan_produk_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', '<div class="col-md-12"><div class="alert alert-info" id="alert">Update Record Success</div></div>');
            redirect(site_url('peramalan_produk'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Peramalan_produk_model->get_by_id($id);

        if ($row) {
            $this->Peramalan_produk_model->delete($id);
            $this->session->set_flashdata('message', '<div class="col-md-12"><div class="alert alert-danger" id="alert">Delete Record Success</div></div>');
            redirect(site_url('peramalan_produk'));
        } else {
            $this->session->set_flashdata('message', '<div class="col-md-12"><div class="alert alert-info" id="alert">Record Not Found</div></div>');
            redirect(site_url('peramalan_produk'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('nama_peramalan', 'nama peramalan', 'trim|required');
	$this->form_validation->set_rules('tanggal', 'tanggal', 'trim|required');
	$this->form_validation->set_rules('produk', 'produk', 'trim|required');
	$this->form_validation->set_rules('jumlah_produk', 'jumlah produk', 'trim|required|numeric');

	$this->form_validation->set_rules('id', 'id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Peramalan_produk.php */
/* Location: ./application/controllers/Peramalan_produk.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-02-13 02:28:14 */
/* http://harviacode.com */
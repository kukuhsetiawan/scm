<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Nota_pembayaran extends My_Controller
{
     protected $access = array('Admin', 'Editor','Author');

    function __construct()
    {
        parent::__construct();
        $this->load->model('Nota_pembayaran_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $nota_pembayaran = $this->Nota_pembayaran_model->get_all();

        $title = array(
            'title' => 'nota_pembayaran',
        );

        $data = array(
            'nota_pembayaran_data' => $nota_pembayaran,
        );
        $this->load->view('cover/header', $title);
        $this->load->view('nota_pembayaran/nota_pembayaran_list', $data);
        $this->load->view('cover/footer');
    }

    public function read($id) 
    {
        $row = $this->Nota_pembayaran_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id' => $row->id,
		'no_pembayaran' => $row->no_pembayaran,
		'total_bayar' => $row->total_bayar,
		'id_pemesanan' => $row->id_pemesanan,
		'status_pembayaran' => $row->status_pembayaran,
	    );

            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('nota_pembayaran/nota_pembayaran_read', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('nota_pembayaran'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('nota_pembayaran/create_action'),
	    'id' => set_value('id'),
	    'no_pembayaran' => set_value('no_pembayaran'),
	    'total_bayar' => set_value('total_bayar'),
	    'id_pemesanan' => set_value('id_pemesanan'),
	    'status_pembayaran' => set_value('status_pembayaran'),
	);
         $title = array(
            'title' => 'Detail',
            );
        $this->load->view('cover/header', $title);
        $this->load->view('nota_pembayaran/nota_pembayaran_form', $data);
        $this->load->view('cover/footer');
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'no_pembayaran' => $this->input->post('no_pembayaran',TRUE),
		'total_bayar' => $this->input->post('total_bayar',TRUE),
		'id_pemesanan' => $this->input->post('id_pemesanan',TRUE),
		'status_pembayaran' => $this->input->post('status_pembayaran',TRUE),
	    );
        
            $this->Nota_pembayaran_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('nota_pembayaran'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Nota_pembayaran_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('nota_pembayaran/update_action'),
		'id' => set_value('id', $row->id),
		'no_pembayaran' => set_value('no_pembayaran', $row->no_pembayaran),
		'total_bayar' => set_value('total_bayar', $row->total_bayar),
		'id_pemesanan' => set_value('id_pemesanan', $row->id_pemesanan),
		'status_pembayaran' => set_value('status_pembayaran', $row->status_pembayaran),
	    );
            
            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('nota_pembayaran/nota_pembayaran_form', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('nota_pembayaran'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'no_pembayaran' => $this->input->post('no_pembayaran',TRUE),
		'total_bayar' => $this->input->post('total_bayar',TRUE),
		'id_pemesanan' => $this->input->post('id_pemesanan',TRUE),
		'status_pembayaran' => $this->input->post('status_pembayaran',TRUE),
	    );

            $this->Nota_pembayaran_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('nota_pembayaran'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Nota_pembayaran_model->get_by_id($id);

        if ($row) {
            $this->Nota_pembayaran_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('nota_pembayaran'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('nota_pembayaran'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('no_pembayaran', 'no pembayaran', 'trim|required');
	$this->form_validation->set_rules('total_bayar', 'total bayar', 'trim|required|numeric');
	$this->form_validation->set_rules('id_pemesanan', 'id pemesanan', 'trim|required');
	$this->form_validation->set_rules('status_pembayaran', 'status pembayaran', 'trim|required');

	$this->form_validation->set_rules('id', 'id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "nota_pembayaran.xls";
        $judul = "nota_pembayaran";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "No Pembayaran");
	xlsWriteLabel($tablehead, $kolomhead++, "Total Bayar");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Pemesanan");
	xlsWriteLabel($tablehead, $kolomhead++, "Status Pembayaran");

	foreach ($this->Nota_pembayaran_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->no_pembayaran);
	    xlsWriteNumber($tablebody, $kolombody++, $data->total_bayar);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_pemesanan);
	    xlsWriteLabel($tablebody, $kolombody++, $data->status_pembayaran);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=nota_pembayaran.doc");

        $data = array(
            'nota_pembayaran_data' => $this->Nota_pembayaran_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('nota_pembayaran/nota_pembayaran_doc',$data);
    }

}

/* End of file Nota_pembayaran.php */
/* Location: ./application/controllers/Nota_pembayaran.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-06-02 02:05:21 */
/* http://harviacode.com */
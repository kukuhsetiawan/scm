<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Pelanggan extends My_Controller
{
     protected $access = array('Admin', 'Pemesanan','Author');

    function __construct()
    {
        parent::__construct();
        $this->load->model('Pelanggan_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $pelanggan = $this->Pelanggan_model->get_all();

        $title = array(
            'title' => 'pelanggan',
        );

        $data = array(
            'pelanggan_data' => $pelanggan,
        );
        $this->load->view('cover/header', $title);
        $this->load->view('pelanggan/pelanggan_list', $data);
        $this->load->view('cover/footer');
    }

    public function read($id) 
    {
        $row = $this->Pelanggan_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_pelanggan' => $row->id_pelanggan,
		'nama_pelanggan' => $row->nama_pelanggan,
		'telp_pel' => $row->telp_pel,
		'alamat_pelanggan' => $row->alamat_pelanggan,
		'username' => $row->username,
		'lokasi' => $row->lokasi,
		'jenis_kirim' => $row->jenis_kirim,
	    );

            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('pelanggan/pelanggan_read', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('pelanggan'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('pelanggan/create_action'),
	    'id_pelanggan' => set_value('id_pelanggan'),
	    'nama_pelanggan' => set_value('nama_pelanggan'),
	    'telp_pel' => set_value('telp_pel'),
	    'alamat_pelanggan' => set_value('alamat_pelanggan'),
	    'username' => set_value('username'),
	    'lokasi' => set_value('lokasi'),
	    'jenis_kirim' => set_value('jenis_kirim'),
	);
         $title = array(
            'title' => 'Detail',
            );
        $this->load->view('cover/header', $title);
        $this->load->view('pelanggan/pelanggan_form', $data);
        $this->load->view('cover/footer');
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'nama_pelanggan' => $this->input->post('nama_pelanggan',TRUE),
		'telp_pel' => $this->input->post('telp_pel',TRUE),
		'alamat_pelanggan' => $this->input->post('alamat_pelanggan',TRUE),
		'username' => $this->input->post('username',TRUE),
		'lokasi' => $this->input->post('lokasi',TRUE),
		'jenis_kirim' => $this->input->post('jenis_kirim',TRUE),
	    );
        
            $this->Pelanggan_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('pelanggan'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Pelanggan_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('pelanggan/update_action'),
		'id_pelanggan' => set_value('id_pelanggan', $row->id_pelanggan),
		'nama_pelanggan' => set_value('nama_pelanggan', $row->nama_pelanggan),
		'telp_pel' => set_value('telp_pel', $row->telp_pel),
		'alamat_pelanggan' => set_value('alamat_pelanggan', $row->alamat_pelanggan),
		'username' => set_value('username', $row->username),
		'lokasi' => set_value('lokasi', $row->lokasi),
		'jenis_kirim' => set_value('jenis_kirim', $row->jenis_kirim),
	    );
            
            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('pelanggan/pelanggan_form', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('pelanggan'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_pelanggan', TRUE));
        } else {
            $data = array(
		'nama_pelanggan' => $this->input->post('nama_pelanggan',TRUE),
		'telp_pel' => $this->input->post('telp_pel',TRUE),
		'alamat_pelanggan' => $this->input->post('alamat_pelanggan',TRUE),
		'username' => $this->input->post('username',TRUE),
		'lokasi' => $this->input->post('lokasi',TRUE),
		'jenis_kirim' => $this->input->post('jenis_kirim',TRUE),
	    );

            $this->Pelanggan_model->update($this->input->post('id_pelanggan', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('pelanggan'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Pelanggan_model->get_by_id($id);

        if ($row) {
            $this->Pelanggan_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('pelanggan'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('pelanggan'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('nama_pelanggan', 'nama pelanggan', 'trim|required');
	$this->form_validation->set_rules('telp_pel', 'telp pel', 'trim|required');
	$this->form_validation->set_rules('alamat_pelanggan', 'alamat pelanggan', 'trim|required');
	$this->form_validation->set_rules('username', 'username', 'trim|required');
	$this->form_validation->set_rules('lokasi', 'lokasi', 'trim|required');
	$this->form_validation->set_rules('jenis_kirim', 'jenis kirim', 'trim|required');

	$this->form_validation->set_rules('id_pelanggan', 'id_pelanggan', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "pelanggan.xls";
        $judul = "pelanggan";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Nama Pelanggan");
	xlsWriteLabel($tablehead, $kolomhead++, "Telp Pel");
	xlsWriteLabel($tablehead, $kolomhead++, "Alamat Pelanggan");
	xlsWriteLabel($tablehead, $kolomhead++, "Username");
	xlsWriteLabel($tablehead, $kolomhead++, "Lokasi");
	xlsWriteLabel($tablehead, $kolomhead++, "Jenis Kirim");

	foreach ($this->Pelanggan_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nama_pelanggan);
	    xlsWriteLabel($tablebody, $kolombody++, $data->telp_pel);
	    xlsWriteLabel($tablebody, $kolombody++, $data->alamat_pelanggan);
	    xlsWriteLabel($tablebody, $kolombody++, $data->username);
	    xlsWriteLabel($tablebody, $kolombody++, $data->lokasi);
	    xlsWriteLabel($tablebody, $kolombody++, $data->jenis_kirim);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=pelanggan.doc");

        $data = array(
            'pelanggan_data' => $this->Pelanggan_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('pelanggan/pelanggan_doc',$data);
    }

}

/* End of file Pelanggan.php */
/* Location: ./application/controllers/Pelanggan.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-05-09 17:32:13 */
/* http://harviacode.com */
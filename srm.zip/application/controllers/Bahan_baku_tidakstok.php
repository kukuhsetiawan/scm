<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Bahan_baku_tidakstok extends My_Controller
{
     protected $access = array('Gudang','Pengadaan','Keuangan','Pemilik','Pemasaran','Produksi', 'Distribusi');
    

    function __construct()
    {
        parent::__construct();
        $this->load->model('Bahan_baku_tidakstok_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $bahan_baku_tidakstok = $this->Bahan_baku_tidakstok_model->get_all();

        $title = array(
            'title' => 'bahan_baku_tidakstok',
        );

        $data = array(
            'bahan_baku_tidakstok_data' => $bahan_baku_tidakstok,
        );
        $this->load->view('cover/header', $title);
        $this->load->view('bahan_baku_tidakstok/bahan_baku_tidakstok_list', $data);
        $this->load->view('cover/footer');
    }

    public function read($id) 
    {
        $row = $this->Bahan_baku_tidakstok_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id' => $row->id,
		'id_bahan_baku_tidakstok' => $row->id_bahan_baku_tidakstok,
		'nama_bahan_baku' => $row->nama_bahan_baku,
		'id_supplier' => $row->id_supplier,
		'harga_bahan_baku' => $row->harga_bahan_baku,
		'satuan' => $row->satuan,
		'keterangan' => $row->keterangan,
	    );

            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('bahan_baku_tidakstok/bahan_baku_tidakstok_read', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bahan_baku_tidakstok'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('bahan_baku_tidakstok/create_action'),
	    'id' => set_value('id'),
	    'id_bahan_baku_tidakstok' => set_value('id_bahan_baku_tidakstok'),
	    'nama_bahan_baku' => set_value('nama_bahan_baku'),
	    'id_supplier' => set_value('id_supplier'),
	    'harga_bahan_baku' => set_value('harga_bahan_baku'),
	    'satuan' => set_value('satuan'),
	    'keterangan' => set_value('keterangan'),
	);
         $title = array(
            'title' => 'Detail',
            );
        $this->load->view('cover/header', $title);
        $this->load->view('bahan_baku_tidakstok/bahan_baku_tidakstok_form', $data);
        $this->load->view('cover/footer');
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'id_bahan_baku_tidakstok' => $this->input->post('id_bahan_baku_tidakstok',TRUE),
		'nama_bahan_baku' => $this->input->post('nama_bahan_baku',TRUE),
		'id_supplier' => $this->input->post('id_supplier',TRUE),
		'harga_bahan_baku' => $this->input->post('harga_bahan_baku',TRUE),
		'satuan' => $this->input->post('satuan',TRUE),
		'keterangan' => $this->input->post('keterangan',TRUE),
	    );
        
            $this->Bahan_baku_tidakstok_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('bahan_baku_tidakstok'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Bahan_baku_tidakstok_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('bahan_baku_tidakstok/update_action'),
		'id' => set_value('id', $row->id),
		'id_bahan_baku_tidakstok' => set_value('id_bahan_baku_tidakstok', $row->id_bahan_baku_tidakstok),
		'nama_bahan_baku' => set_value('nama_bahan_baku', $row->nama_bahan_baku),
		'id_supplier' => set_value('id_supplier', $row->id_supplier),
		'harga_bahan_baku' => set_value('harga_bahan_baku', $row->harga_bahan_baku),
		'satuan' => set_value('satuan', $row->satuan),
		'keterangan' => set_value('keterangan', $row->keterangan),
	    );
            
            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('bahan_baku_tidakstok/bahan_baku_tidakstok_form', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bahan_baku_tidakstok'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'id_bahan_baku_tidakstok' => $this->input->post('id_bahan_baku_tidakstok',TRUE),
		'nama_bahan_baku' => $this->input->post('nama_bahan_baku',TRUE),
		'id_supplier' => $this->input->post('id_supplier',TRUE),
		'harga_bahan_baku' => $this->input->post('harga_bahan_baku',TRUE),
		'satuan' => $this->input->post('satuan',TRUE),
		'keterangan' => $this->input->post('keterangan',TRUE),
	    );

            $this->Bahan_baku_tidakstok_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('bahan_baku_tidakstok'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Bahan_baku_tidakstok_model->get_by_id($id);

        if ($row) {
            $this->Bahan_baku_tidakstok_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('bahan_baku_tidakstok'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bahan_baku_tidakstok'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('id_bahan_baku_tidakstok', 'id bahan baku tidakstok', 'trim|required');
	$this->form_validation->set_rules('nama_bahan_baku', 'nama bahan baku', 'trim|required');
	$this->form_validation->set_rules('id_supplier', 'id supplier', 'trim|required');
	$this->form_validation->set_rules('harga_bahan_baku', 'harga bahan baku', 'trim|required|numeric');
	$this->form_validation->set_rules('satuan', 'satuan', 'trim|required');
	$this->form_validation->set_rules('keterangan', 'keterangan', 'trim|required');

	$this->form_validation->set_rules('id', 'id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "bahan_baku_tidakstok.xls";
        $judul = "bahan_baku_tidakstok";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Bahan Baku Tidakstok");
	xlsWriteLabel($tablehead, $kolomhead++, "Nama Bahan Baku");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Supplier");
	xlsWriteLabel($tablehead, $kolomhead++, "Harga Bahan Baku");
	xlsWriteLabel($tablehead, $kolomhead++, "Satuan");
	xlsWriteLabel($tablehead, $kolomhead++, "Keterangan");

	foreach ($this->Bahan_baku_tidakstok_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_bahan_baku_tidakstok);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nama_bahan_baku);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_supplier);
	    xlsWriteNumber($tablebody, $kolombody++, $data->harga_bahan_baku);
	    xlsWriteLabel($tablebody, $kolombody++, $data->satuan);
	    xlsWriteLabel($tablebody, $kolombody++, $data->keterangan);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=bahan_baku_tidakstok.doc");

        $data = array(
            'bahan_baku_tidakstok_data' => $this->Bahan_baku_tidakstok_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('bahan_baku_tidakstok/bahan_baku_tidakstok_doc',$data);
    }

}

/* End of file Bahan_baku_tidakstok.php */
/* Location: ./application/controllers/Bahan_baku_tidakstok.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-07-10 23:43:02 */
/* http://harviacode.com */
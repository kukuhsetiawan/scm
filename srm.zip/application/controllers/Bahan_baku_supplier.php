<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Bahan_baku_supplier extends My_Controller
{
     protected $access = array('Admin', 'Editor','Author');

    function __construct()
    {
        parent::__construct();
        $this->load->model('Bahan_baku_supplier_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $bahan_baku_supplier = $this->Bahan_baku_supplier_model->get_all();

        $title = array(
            'title' => 'bahan_baku_supplier',
        );

        $data = array(
            'bahan_baku_supplier_data' => $bahan_baku_supplier,
        );
        $this->load->view('cover/header', $title);
        $this->load->view('bahan_baku_supplier/bahan_baku_supplier_list', $data);
        $this->load->view('cover/footer');
    }

    public function read($id) 
    {
        $row = $this->Bahan_baku_supplier_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id' => $row->id,
		'id_bahan_baku_supp' => $row->id_bahan_baku_supp,
		'id_supplier' => $row->id_supplier,
		'nama_bahan_baku' => $row->nama_bahan_baku,
		'stock' => $row->stock,
		'harga' => $row->harga,
	    );

            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('bahan_baku_supplier/bahan_baku_supplier_read', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bahan_baku_supplier'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('bahan_baku_supplier/create_action'),
	    'id' => set_value('id'),
	    'id_bahan_baku_supp' => set_value('id_bahan_baku_supp'),
	    'id_supplier' => set_value('id_supplier'),
	    'nama_bahan_baku' => set_value('nama_bahan_baku'),
	    'stock' => set_value('stock'),
	    'harga' => set_value('harga'),
	);
         $title = array(
            'title' => 'Detail',
            );
        $this->load->view('cover/header', $title);
        $this->load->view('bahan_baku_supplier/bahan_baku_supplier_form', $data);
        $this->load->view('cover/footer');
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'id_bahan_baku_supp' => $this->input->post('id_bahan_baku_supp',TRUE),
		'id_supplier' => $this->input->post('id_supplier',TRUE),
		'nama_bahan_baku' => $this->input->post('nama_bahan_baku',TRUE),
		'stock' => $this->input->post('stock',TRUE),
		'harga' => $this->input->post('harga',TRUE),
	    );
        
            $this->Bahan_baku_supplier_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('bahan_baku_supplier'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Bahan_baku_supplier_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('bahan_baku_supplier/update_action'),
		'id' => set_value('id', $row->id),
		'id_bahan_baku_supp' => set_value('id_bahan_baku_supp', $row->id_bahan_baku_supp),
		'id_supplier' => set_value('id_supplier', $row->id_supplier),
		'nama_bahan_baku' => set_value('nama_bahan_baku', $row->nama_bahan_baku),
		'stock' => set_value('stock', $row->stock),
		'harga' => set_value('harga', $row->harga),
	    );
            
            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('bahan_baku_supplier/bahan_baku_supplier_form', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bahan_baku_supplier'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'id_bahan_baku_supp' => $this->input->post('id_bahan_baku_supp',TRUE),
		'id_supplier' => $this->input->post('id_supplier',TRUE),
		'nama_bahan_baku' => $this->input->post('nama_bahan_baku',TRUE),
		'stock' => $this->input->post('stock',TRUE),
		'harga' => $this->input->post('harga',TRUE),
	    );

            $this->Bahan_baku_supplier_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('bahan_baku_supplier'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Bahan_baku_supplier_model->get_by_id($id);

        if ($row) {
            $this->Bahan_baku_supplier_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('bahan_baku_supplier'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bahan_baku_supplier'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('id_bahan_baku_supp', 'id bahan baku supp', 'trim|required');
	$this->form_validation->set_rules('id_supplier', 'id supplier', 'trim|required');
	$this->form_validation->set_rules('nama_bahan_baku', 'nama bahan baku', 'trim|required');
	$this->form_validation->set_rules('stock', 'stock', 'trim|required');
	$this->form_validation->set_rules('harga', 'harga', 'trim|required|numeric');

	$this->form_validation->set_rules('id', 'id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "bahan_baku_supplier.xls";
        $judul = "bahan_baku_supplier";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Bahan Baku Supp");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Supplier");
	xlsWriteLabel($tablehead, $kolomhead++, "Nama Bahan Baku");
	xlsWriteLabel($tablehead, $kolomhead++, "Stock");
	xlsWriteLabel($tablehead, $kolomhead++, "Harga");

	foreach ($this->Bahan_baku_supplier_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_bahan_baku_supp);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_supplier);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nama_bahan_baku);
	    xlsWriteNumber($tablebody, $kolombody++, $data->stock);
	    xlsWriteNumber($tablebody, $kolombody++, $data->harga);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=bahan_baku_supplier.doc");

        $data = array(
            'bahan_baku_supplier_data' => $this->Bahan_baku_supplier_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('bahan_baku_supplier/bahan_baku_supplier_doc',$data);
    }

}

/* End of file Bahan_baku_supplier.php */
/* Location: ./application/controllers/Bahan_baku_supplier.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-05-09 17:32:08 */
/* http://harviacode.com */
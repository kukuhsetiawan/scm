<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Pengiriman extends My_Controller
{
     protected $access = array('Gudang','Pengadaan','Keuangan','Pemilik','Pemasaran','Produksi', 'Distribusi');

    function __construct()
    {
        parent::__construct();
        $this->load->model('Pengiriman_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $pengiriman = $this->Pengiriman_model->get_all();

        $title = array(
            'title' => 'pengiriman',
        );

        $data = array(
            'pengiriman_data' => $pengiriman,
        );
        $this->load->view('cover/header', $title);
        $this->load->view('pengiriman/pengiriman_list', $data);
        $this->load->view('cover/footer');
    }

    public function read($id) 
    {
        $row = $this->Pengiriman_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id' => $row->id,
		'id_pemesanan' => $row->id_pemesanan,
		'tgl_pengiriman' => $row->tgl_pengiriman,
		'kendaraan' => $row->kendaraan,
		'status_pengiriman' => $row->status_pengiriman,
		'supir' => $row->supir,
		'alamat' => $row->alamat,
		'jarak' => $row->jarak,
	    );

            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('pengiriman/pengiriman_read', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('pengiriman'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('pengiriman/create_action'),
	    'id' => set_value('id'),
	    'id_pemesanan' => set_value('id_pemesanan'),
	    'tgl_pengiriman' => set_value('tgl_pengiriman'),
	    'kendaraan' => set_value('kendaraan'),
	    'status_pengiriman' => set_value('status_pengiriman'),
	    'supir' => set_value('supir'),
	    'alamat' => set_value('alamat'),
	    'jarak' => set_value('jarak'),

	);
         $title = array(
            'title' => 'Detail',
            );

         $this->db->join('produk', 'pemesanan.id_produk = produk.id_produk', 'left');
         $this->db->where('status_pemesanan', 'selesai');
         $data['pemesanan'] = $this->db->get('pemesanan')->result();

         $data['kendaraan'] = $this->db->get('kendaraan')->result();

        $this->load->view('cover/header', $title);
        $this->load->view('pengiriman/pengiriman_form', $data);
        $this->load->view('cover/footer');
    }
    
    public function create_action() 
    {
        
            $data = array(
		'id_pemesanan' => $this->input->post('id_pemesanan',TRUE),
		'tgl_pengiriman' => $this->input->post('tgl_pengiriman',TRUE),
		'kendaraan' => $this->input->post('kendaraan',TRUE),
		'status_pengiriman' => $this->input->post('status_pengiriman',TRUE),
		'supir' => $this->input->post('supir',TRUE),
		'alamat' => $this->input->post('alamat',TRUE),
		'jarak' => $this->input->post('jarak',TRUE),
	    );
        
            $this->Pengiriman_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('pengiriman'));
        
    }
    
    public function update($id) 
    {
        $row = $this->Pengiriman_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('pengiriman/update_action'),
		'id' => set_value('id', $row->id),
		'id_pemesanan' => set_value('id_pemesanan', $row->id_pemesanan),
		'tgl_pengiriman' => set_value('tgl_pengiriman', $row->tgl_pengiriman),
		'kendaraan' => set_value('kendaraan', $row->kendaraan),
		'status_pengiriman' => set_value('status_pengiriman', $row->status_pengiriman),
		'supir' => set_value('supir', $row->supir),
		'alamat' => set_value('alamat', $row->alamat),
		'jarak' => set_value('jarak', $row->jarak),
	    );
            
            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('pengiriman/pengiriman_form', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('pengiriman'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'id_pemesanan' => $this->input->post('id_pemesanan',TRUE),
		'tgl_pengiriman' => $this->input->post('tgl_pengiriman',TRUE),
		'kendaraan' => $this->input->post('kendaraan',TRUE),
		'status_pengiriman' => $this->input->post('status_pengiriman',TRUE),
		'supir' => $this->input->post('supir',TRUE),
		'alamat' => $this->input->post('alamat',TRUE),
		'jarak' => $this->input->post('jarak',TRUE),
	    );

            $this->Pengiriman_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('pengiriman'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Pengiriman_model->get_by_id($id);

        if ($row) {
            $this->Pengiriman_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('pengiriman'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('pengiriman'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('id_pemesanan', 'id pemesanan', 'trim|required');
	$this->form_validation->set_rules('tgl_pengiriman', 'tgl pengiriman', 'trim|required');
	$this->form_validation->set_rules('kendaraan', 'kendaraan', 'trim|required');
	$this->form_validation->set_rules('status_pengiriman', 'status pengiriman', 'trim|required');
	$this->form_validation->set_rules('supir', 'supir', 'trim|required');
	$this->form_validation->set_rules('alamat', 'alamat', 'trim|required');
	$this->form_validation->set_rules('jarak', 'jarak', 'trim|required');

	$this->form_validation->set_rules('id', 'id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "pengiriman.xls";
        $judul = "pengiriman";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Pemesanan");
	xlsWriteLabel($tablehead, $kolomhead++, "Tgl Pengiriman");
	xlsWriteLabel($tablehead, $kolomhead++, "Kendaraan");
	xlsWriteLabel($tablehead, $kolomhead++, "Status Pengiriman");
	xlsWriteLabel($tablehead, $kolomhead++, "Supir");
	xlsWriteLabel($tablehead, $kolomhead++, "Alamat");
	xlsWriteLabel($tablehead, $kolomhead++, "Jarak");

	foreach ($this->Pengiriman_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_pemesanan);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tgl_pengiriman);
	    xlsWriteLabel($tablebody, $kolombody++, $data->kendaraan);
	    xlsWriteLabel($tablebody, $kolombody++, $data->status_pengiriman);
	    xlsWriteNumber($tablebody, $kolombody++, $data->supir);
	    xlsWriteLabel($tablebody, $kolombody++, $data->alamat);
	    xlsWriteLabel($tablebody, $kolombody++, $data->jarak);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=pengiriman.doc");

        $data = array(
            'pengiriman_data' => $this->Pengiriman_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('pengiriman/pengiriman_doc',$data);
    }

}

/* End of file Pengiriman.php */
/* Location: ./application/controllers/Pengiriman.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-07-20 18:52:14 */
/* http://harviacode.com */
<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Biaya_simpan extends My_Controller
{
     protected $access = array('Admin', 'Editor','Author');

    function __construct()
    {
        parent::__construct();
        $this->load->model('Biaya_simpan_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $biaya_simpan = $this->Biaya_simpan_model->get_all();

        $title = array(
            'title' => 'biaya_simpan',
        );

        $data = array(
            'biaya_simpan_data' => $biaya_simpan,
        );
        $this->load->view('cover/header', $title);
        $this->load->view('biaya_simpan/biaya_simpan_list', $data);
        $this->load->view('cover/footer');
    }

    public function read($id) 
    {
        $row = $this->Biaya_simpan_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id' => $row->id,
		'jenis' => $row->jenis,
		'jumlah' => $row->jumlah,
	    );

            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('biaya_simpan/biaya_simpan_read', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('biaya_simpan'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('biaya_simpan/create_action'),
	    'id' => set_value('id'),
	    'jenis' => set_value('jenis'),
	    'jumlah' => set_value('jumlah'),
	);
         $title = array(
            'title' => 'Detail',
            );
        $this->load->view('cover/header', $title);
        $this->load->view('biaya_simpan/biaya_simpan_form', $data);
        $this->load->view('cover/footer');
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'jenis' => $this->input->post('jenis',TRUE),
		'jumlah' => $this->input->post('jumlah',TRUE),
	    );
        
            $this->Biaya_simpan_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('biaya_simpan'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Biaya_simpan_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('biaya_simpan/update_action'),
		'id' => set_value('id', $row->id),
		'jenis' => set_value('jenis', $row->jenis),
		'jumlah' => set_value('jumlah', $row->jumlah),
	    );
            
            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('biaya_simpan/biaya_simpan_form', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('biaya_simpan'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'jenis' => $this->input->post('jenis',TRUE),
		'jumlah' => $this->input->post('jumlah',TRUE),
	    );

            $this->Biaya_simpan_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('biaya_simpan'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Biaya_simpan_model->get_by_id($id);

        if ($row) {
            $this->Biaya_simpan_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('biaya_simpan'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('biaya_simpan'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('jenis', 'jenis', 'trim|required');
	$this->form_validation->set_rules('jumlah', 'jumlah', 'trim|required|numeric');

	$this->form_validation->set_rules('id', 'id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "biaya_simpan.xls";
        $judul = "biaya_simpan";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Jenis");
	xlsWriteLabel($tablehead, $kolomhead++, "Jumlah");

	foreach ($this->Biaya_simpan_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->jenis);
	    xlsWriteNumber($tablebody, $kolombody++, $data->jumlah);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=biaya_simpan.doc");

        $data = array(
            'biaya_simpan_data' => $this->Biaya_simpan_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('biaya_simpan/biaya_simpan_doc',$data);
    }

}

/* End of file Biaya_simpan.php */
/* Location: ./application/controllers/Biaya_simpan.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-06-02 02:05:19 */
/* http://harviacode.com */
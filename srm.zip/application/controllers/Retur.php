<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Retur extends My_Controller
{
     protected $access = array('Admin', 'Editor','Author');

    function __construct()
    {
        parent::__construct();
        $this->load->model('Retur_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $retur = $this->Retur_model->get_all();

        $title = array(
            'title' => 'retur',
        );

        $data = array(
            'retur_data' => $retur,
        );
        $this->load->view('cover/header', $title);
        $this->load->view('retur/retur_list', $data);
        $this->load->view('cover/footer');
    }

    public function read($id) 
    {
        $row = $this->Retur_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id' => $row->id,
		'id_pemesanan' => $row->id_pemesanan,
		'tanggal_lapor' => $row->tanggal_lapor,
		'keluhan' => $row->keluhan,
	    );

            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('retur/retur_read', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('retur'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('retur/create_action'),
	    'id' => set_value('id'),
	    'id_pemesanan' => set_value('id_pemesanan'),
	    'tanggal_lapor' => set_value('tanggal_lapor'),
	    'keluhan' => set_value('keluhan'),
	);
         $title = array(
            'title' => 'Detail',
            );
        $this->load->view('cover/header', $title);
        $this->load->view('retur/retur_form', $data);
        $this->load->view('cover/footer');
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'id_pemesanan' => $this->input->post('id_pemesanan',TRUE),
		'tanggal_lapor' => $this->input->post('tanggal_lapor',TRUE),
		'keluhan' => $this->input->post('keluhan',TRUE),
	    );
        
            $this->Retur_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('retur'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Retur_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('retur/update_action'),
		'id' => set_value('id', $row->id),
		'id_pemesanan' => set_value('id_pemesanan', $row->id_pemesanan),
		'tanggal_lapor' => set_value('tanggal_lapor', $row->tanggal_lapor),
		'keluhan' => set_value('keluhan', $row->keluhan),
	    );
            
            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('retur/retur_form', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('retur'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'id_pemesanan' => $this->input->post('id_pemesanan',TRUE),
		'tanggal_lapor' => $this->input->post('tanggal_lapor',TRUE),
		'keluhan' => $this->input->post('keluhan',TRUE),
	    );

            $this->Retur_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('retur'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Retur_model->get_by_id($id);

        if ($row) {
            $this->Retur_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('retur'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('retur'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('id_pemesanan', 'id pemesanan', 'trim|required');
	$this->form_validation->set_rules('tanggal_lapor', 'tanggal lapor', 'trim|required');
	$this->form_validation->set_rules('keluhan', 'keluhan', 'trim|required');

	$this->form_validation->set_rules('id', 'id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "retur.xls";
        $judul = "retur";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Pemesanan");
	xlsWriteLabel($tablehead, $kolomhead++, "Tanggal Lapor");
	xlsWriteLabel($tablehead, $kolomhead++, "Keluhan");

	foreach ($this->Retur_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_pemesanan);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tanggal_lapor);
	    xlsWriteLabel($tablebody, $kolombody++, $data->keluhan);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=retur.doc");

        $data = array(
            'retur_data' => $this->Retur_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('retur/retur_doc',$data);
    }

}

/* End of file Retur.php */
/* Location: ./application/controllers/Retur.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-06-02 02:05:24 */
/* http://harviacode.com */
<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Bom extends My_Controller
{
     protected $access = array('Produksi');

    function __construct()
    {
        parent::__construct();
        $this->load->model('Bom_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $bom = $this->Bom_model->get_all();

        $title = array(
            'title' => 'bom',
        );

        $data = array(
            'bom_data' => $bom,
        );
        $this->load->view('cover/header', $title);
        $this->load->view('bom/bom_list', $data);
        $this->load->view('cover/footer');
    }

    public function read($id) 
    {
        $row = $this->Bom_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_bom' => $row->id_bom,
		'id_produk' => $row->id_produk,
		'id_bahan_baku' => $row->id_bahan_baku,
		'jumlah_kebutuhan' => $row->jumlah_kebutuhan,
	    );

            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('bom/bom_read', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bom'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('bom/create_action'),
	    'id_bom' => set_value('id_bom'),
	    'id_produk' => set_value('id_produk'),
	    'id_bahan_baku' => set_value('id_bahan_baku'),
	    'jumlah_kebutuhan' => set_value('jumlah_kebutuhan'),
        'content_produk' => $this->db->get('produk')->result(),
        'content_bahan_baku' => $this->db->get('bahan_baku')->result()
	);
         $title = array(
            'title' => 'Detail',
            );
        $this->load->view('cover/header', $title);
        $this->load->view('bom/bom_form', $data);
        $this->load->view('cover/footer');
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'id_produk' => $this->input->post('id_produk',TRUE),
		'id_bahan_baku' => $this->input->post('id_bahan_baku',TRUE),
		'jumlah_kebutuhan' => $this->input->post('jumlah_kebutuhan',TRUE),
	    );
        
            $this->Bom_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('bom'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Bom_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('bom/update_action'),
		'id_bom' => set_value('id_bom', $row->id_bom),
		'id_produk' => set_value('id_produk', $row->id_produk),
		'id_bahan_baku' => set_value('id_bahan_baku', $row->id_bahan_baku),
		'jumlah_kebutuhan' => set_value('jumlah_kebutuhan', $row->jumlah_kebutuhan),
	    );
            
            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('bom/bom_form', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bom'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_bom', TRUE));
        } else {
            $data = array(
		'id_produk' => $this->input->post('id_produk',TRUE),
		'id_bahan_baku' => $this->input->post('id_bahan_baku',TRUE),
		'jumlah_kebutuhan' => $this->input->post('jumlah_kebutuhan',TRUE),
	    );

            $this->Bom_model->update($this->input->post('id_bom', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('bom'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Bom_model->get_by_id($id);

        if ($row) {
            $this->Bom_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('bom'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bom'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('id_produk', 'id produk', 'trim|required');
	$this->form_validation->set_rules('id_bahan_baku', 'id bahan baku', 'trim|required');
	$this->form_validation->set_rules('jumlah_kebutuhan', 'jumlah kebutuhan', 'trim|required');

	$this->form_validation->set_rules('id_bom', 'id_bom', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "bom.xls";
        $judul = "bom";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Produk");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Bahan Baku");
	xlsWriteLabel($tablehead, $kolomhead++, "Jumlah Kebutuhan");

	foreach ($this->Bom_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_produk);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_bahan_baku);
	    xlsWriteNumber($tablebody, $kolombody++, $data->jumlah_kebutuhan);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=bom.doc");

        $data = array(
            'bom_data' => $this->Bom_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('bom/bom_doc',$data);
    }

}

/* End of file Bom.php */
/* Location: ./application/controllers/Bom.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-06-02 02:05:19 */
/* http://harviacode.com */
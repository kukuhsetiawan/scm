<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class Main extends My_Controller {

		protected $access = array('Gudang','Pengadaan','Keuangan','Pemilik','Pemasaran','Produksi', 'Distribusi');
	
		public function index()
		{

			$title = array(
				'title' => 'Dashboard' ,
			);

			$this->load->view('cover/header',$title);
			$this->load->view('index');
			$this->load->view('cover/footer');
		}
	
	}
	
	/* End of file Main.php */
	/* Location: ./application/controllers/Main.php */

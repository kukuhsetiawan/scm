<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Supplier extends My_Controller
{
     protected $access = array('Pengadaan');

    function __construct()
    {
        parent::__construct();
        $this->load->model('Supplier_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $supplier = $this->Supplier_model->get_all();

        $title = array(
            'title' => 'supplier',
        );

        $data = array(
            'supplier_data' => $supplier,
        );
        $this->load->view('cover/header', $title);
        $this->load->view('supplier/supplier_list', $data);
        $this->load->view('cover/footer');
    }

    public function read($id) 
    {
        $row = $this->Supplier_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id' => $row->id,
		'id_supplier' => $row->id_supplier,
		'nama_supplier' => $row->nama_supplier,
		'telp_supp' => $row->telp_supp,
		'alamat_supplier' => $row->alamat_supplier,
	    );

            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('supplier/supplier_read', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('supplier'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('supplier/create_action'),
	    'id' => set_value('id'),
	    'id_supplier' => set_value('id_supplier'),
	    'nama_supplier' => set_value('nama_supplier'),
	    'telp_supp' => set_value('telp_supp'),
	    'alamat_supplier' => set_value('alamat_supplier'),
	);
         $title = array(
            'title' => 'Detail',
            );
        $this->load->view('cover/header', $title);
        $this->load->view('supplier/supplier_form', $data);
        $this->load->view('cover/footer');
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'id_supplier' => $this->input->post('id_supplier',TRUE),
		'nama_supplier' => $this->input->post('nama_supplier',TRUE),
		'telp_supp' => $this->input->post('telp_supp',TRUE),
		'alamat_supplier' => $this->input->post('alamat_supplier',TRUE),
	    );
        
            $this->Supplier_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('supplier'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Supplier_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('supplier/update_action'),
		'id' => set_value('id', $row->id),
		'id_supplier' => set_value('id_supplier', $row->id_supplier),
		'nama_supplier' => set_value('nama_supplier', $row->nama_supplier),
		'telp_supp' => set_value('telp_supp', $row->telp_supp),
		'alamat_supplier' => set_value('alamat_supplier', $row->alamat_supplier),
	    );
            
            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('supplier/supplier_form', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('supplier'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'id_supplier' => $this->input->post('id_supplier',TRUE),
		'nama_supplier' => $this->input->post('nama_supplier',TRUE),
		'telp_supp' => $this->input->post('telp_supp',TRUE),
		'alamat_supplier' => $this->input->post('alamat_supplier',TRUE),
	    );

            $this->Supplier_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('supplier'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Supplier_model->get_by_id($id);

        if ($row) {
            $this->Supplier_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('supplier'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('supplier'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('id_supplier', 'id supplier', 'trim|required');
	$this->form_validation->set_rules('nama_supplier', 'nama supplier', 'trim|required');
	$this->form_validation->set_rules('telp_supp', 'telp supp', 'trim|required');
	$this->form_validation->set_rules('alamat_supplier', 'alamat supplier', 'trim|required');

	$this->form_validation->set_rules('id', 'id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "supplier.xls";
        $judul = "supplier";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Supplier");
	xlsWriteLabel($tablehead, $kolomhead++, "Nama Supplier");
	xlsWriteLabel($tablehead, $kolomhead++, "Telp Supp");
	xlsWriteLabel($tablehead, $kolomhead++, "Alamat Supplier");

	foreach ($this->Supplier_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_supplier);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nama_supplier);
	    xlsWriteLabel($tablebody, $kolombody++, $data->telp_supp);
	    xlsWriteLabel($tablebody, $kolombody++, $data->alamat_supplier);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=supplier.doc");

        $data = array(
            'supplier_data' => $this->Supplier_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('supplier/supplier_doc',$data);
    }

}

/* End of file Supplier.php */
/* Location: ./application/controllers/Supplier.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-06-02 02:05:25 */
/* http://harviacode.com */
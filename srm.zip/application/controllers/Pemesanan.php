<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Pemesanan extends MY_Controller {
    
    protected $access = array('Gudang','Pengadaan','Keuangan','Pemilik','Pemasaran','Produksi', 'Distribusi');

    function __construct()
    {
        parent::__construct();
        $this->load->model('Pemesanan_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'pemesanan/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'pemesanan/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'pemesanan/index.html';
            $config['first_url'] = base_url() . 'pemesanan/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Pemesanan_model->total_rows($q);
        // $pemesanan = $this->Pemesanan_model->get_limit_data($config['per_page'], $start, $q);
        $pemesanan = $this->db->query('SELECT pe.*, pr.nama_produk as nama_produk, pr.harga*pe.jumlah as total_bayar, 0.5*pr.harga*pe.jumlah as dp FROM pemesanan pe, produk pr WHERE pe.id_produk = pr.id_produk ORDER BY pe.id_pemesanan DESC')->result();

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'pemesanan_data' => $pemesanan,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );

        $this->load->view('cover/header');
        $this->load->view('pemesanan/pemesanan_list', $data);
        $this->load->view('cover/footer');
    }

    public function selesai()
    {
        $this->db->where('status_pemesanan', 'selesai');
        $data = array(
            'content' => $this->db->get('pemesanan')->result(), 
            'total' =>$this->db->query("SELECT SUM(pr.harga*pe.jumlah) as total_selesai FROM pemesanan pe,produk pr WHERE pe.id_produk=pr.id_produk AND pe.status_pemesanan ='selesai' ")->result(),
            'laba' =>$this->db->query("SELECT SUM((pr.harga-pr.harga)*pe.jumlah) as laba_selesai FROM pemesanan pe,produk pr WHERE pe.id_produk=pr.id_produk AND pe.status_pemesanan ='selesai' ")->result()
        );

        $this->load->view('cover/header');
        $this->load->view('pemesanan/selesai', $data);
        $this->load->view('cover/footer');
    }

    
    public function cetak_nota($value='')
    {
        $data['rincian'] = $this->db->query("SELECT pe.*, pr.nama_produk as nama_produk, pr.harga*pe.jumlah as total_bayar, 0.5*pr.harga*pe.jumlah as dp FROM pemesanan pe, produk pr WHERE pe.id_produk = pr.id_produk AND pe.suffix = '$value' ORDER BY pe.id_pemesanan DESC")->result();
        $data['total'] = $this->db->query("SELECT DISTINCT(pe.tgl_selesai) as tgl_selesai, SUM(pr.harga*pe.jumlah) as total_bayar, SUM(0.5*pr.harga*pe.jumlah) as dp FROM pemesanan pe, produk pr WHERE pe.id_produk = pr.id_produk AND pe.suffix = '$value' ")->result();
        $this->load->view('pemesanan/cetak_nota', $data);
    }

    public function read($id) 
    {
        $row = $this->Pemesanan_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_pemesanan' => $row->id_pemesanan,
		'tgl_pemesanan' => $row->tgl_pemesanan,
		'id_user' => $row->id_user,
		'bayar_dp' => $row->bayar_dp,
		'id_produk' => $row->id_produk,
		'status_pemesanan' => $row->status_pemesanan,
	    );
            $this->load->view('cover/header');
            $this->load->view('pemesanan/pemesanan_read', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('pemesanan'));
        }
    }

    public function pilih_transaksi()
    {
        # code...
    }

    public function pesan()
    {
        $this->load->view('cover/header');
        $this->load->view('pemesanan/pesan');
        $this->load->view('cover/footer');
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('pemesanan/create_action'),
	    'id_pemesanan' => set_value('id_pemesanan'),
	    'tgl_pemesanan' => set_value('tgl_pemesanan'),
	    'id_user' => set_value('id_user'),
	    'bayar_dp' => set_value('bayar_dp'),
	    'jumlah' => set_value('jumlah'),
	    'status_pemesanan' => set_value('status_pemesanan'),
        'content_produk' => $this->db->get('produk')->result(),
        'content_retail' => $this->db->get('retail')->result()
	);

        $this->load->view('cover/header');
        $this->load->view('pemesanan/pemesanan_form', $data);
        $this->load->view('cover/footer');
    }
    
    public function create_action() 
    {
      
          /*  $data = array(
		
		'tgl_pemesanan' => $this->input->post('tgl_pemesanan',TRUE),
		'id_pelanggan' => $this->input->post('id_pelanggan',TRUE),
		'id_user' => $this->input->post('id_user',TRUE),
		'id_produk' => $this->input->post('id_produk',TRUE),
		'status_pemesanan' => $this->input->post('status_pemesanan',TRUE),
        'jumlah' => $this->input->post('jumlah'),
	    );

            $this->Pemesanan_model->insert($data);
            $this->session->set_flashdata('message', '<div class="col-md-12"><div class="alert alert-success" id="alert">Create Record Success</div></div>');
            redirect(site_url('pemesanan'));*/

            foreach($_POST['data'] as $d){
                $this->db->insert('pemesanan',$d);
            }
            $this->session->set_flashdata('message', '<div class="col-md-12"><div class="alert alert-success" id="alert">Create Record Success</div></div>');
            redirect('pemesanan');
        
    }
    
    public function update($id) 
    {
        $row = $this->Pemesanan_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('pemesanan/update_action'),
		
		'status_pemesanan' => set_value('status_pemesanan', $row->status_pemesanan),
        'id_pemesanan' => set_value('id_pemesanan', $row->id_pemesanan),

	    );

            $this->db->where('id_pemesanan', $id);

            $data['content'] = $this->db->get('pemesanan')->result();

            $this->load->view('cover/header');
            $this->load->view('pemesanan/konfirm_status', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('pemesanan'));
        }
    }
    
    public function update_action($id) 
    {
       
            $data = array(
		'tgl_selesai' => $this->input->post('tgl_selesai',TRUE),

		'status_pemesanan' => $this->input->post('status_pemesanan',TRUE),

	    );
            $this->db->where('id_pemesanan', $id);

            $this->db->update('pemesanan', $data);
            $this->session->set_flashdata('message', '<div class="col-md-12"><div class="alert alert-info" id="alert">Update Record Success</div></div>');
            redirect(site_url('pemesanan'));
    
    }

    public function konfirm_status($id) 
    {
       
            $data = array(
     
        'status_pemesanan' => $this->input->post('status_pemesanan',TRUE),
        'tgl_selesai' => $this->input->post('tgl_selesai',TRUE),

        );

            $this->db->where('id_pemesanan', $id);
            $this->db->set('status_pemesanan', $data['status_pemesanan']);
            $this->db->set('tgl_selesai', $data['tgl_selesai']);
            $this->db->update('pemesanan');

            $this->session->set_flashdata('message', '<div class="col-md-12"><div class="alert alert-info" id="alert">Update Record Success</div></div>');
            redirect(site_url('pemesanan'));
    
    }
    
    public function delete($id) 
    {
        $row = $this->Pemesanan_model->get_by_id($id);

        if ($row) {
            $this->Pemesanan_model->delete($id);
            $this->session->set_flashdata('message', '<div class="col-md-12"><div class="alert alert-danger" id="alert">Delete Record Success</div></div>');
            redirect(site_url('pemesanan'));
        } else {
            $this->session->set_flashdata('message', '<div class="col-md-12"><div class="alert alert-info" id="alert">Record Not Found</div></div>');
            redirect(site_url('pemesanan'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('tgl_pemesanan', 'tgl pemesanan', 'trim|required');
	$this->form_validation->set_rules('id_user', 'id user', 'trim|required');
	$this->form_validation->set_rules('bayar_dp', 'bayar dp', 'trim|required|numeric');
	$this->form_validation->set_rules('total_bayar', 'total bayar', 'trim|required|numeric');
	$this->form_validation->set_rules('status_pemesanan', 'status pemesanan', 'trim|required');

	$this->form_validation->set_rules('id_pemesanan', 'id_pemesanan', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "pemesanan.xls";
        $judul = "pemesanan";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Kode Pemesanan");
	xlsWriteLabel($tablehead, $kolomhead++, "Tgl Pemesanan");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Pelanggan");
	xlsWriteLabel($tablehead, $kolomhead++, "Id User");
	xlsWriteLabel($tablehead, $kolomhead++, "Bayar Dp");
	xlsWriteLabel($tablehead, $kolomhead++, "Total Bayar");
	xlsWriteLabel($tablehead, $kolomhead++, "Status Pemesanan");

	foreach ($this->Pemesanan_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tgl_pemesanan);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_user);
	    xlsWriteNumber($tablebody, $kolombody++, $data->bayar_dp);
	    xlsWriteNumber($tablebody, $kolombody++, $data->total_bayar);
	    xlsWriteLabel($tablebody, $kolombody++, $data->status_pemesanan);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=pemesanan.doc");

        $data = array(
            'pemesanan_data' => $this->Pemesanan_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('pemesanan/pemesanan_doc',$data);
    }

}

/* End of file Pemesanan.php */
/* Location: ./application/controllers/Pemesanan.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-01-19 21:29:40 */
/* http://harviacode.com */
<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Peramalan extends MY_Controller {
    
    protected $access = array('Pengadaan');

    function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
      
        $data = array(
            'content_produk' => $this->db->get('produk')->result(),

        );

        $this->load->view('header');
        $this->load->view('peramalan_index', $data);
        $this->load->view('footer');
    }

    

    public function pilih_peramalan()
    {
        $cari=$this->input->get('cari');

        $alpha21_r = $this->db->query("SELECT 0.1*(SELECT COUNT(tgl_pemesanan) FROM pemesanan WHERE MONTH(tgl_pemesanan) = 1 AND id_produk like '%$cari%' )+0.9*(SELECT COUNT(tgl_pemesanan) FROM pemesanan WHERE MONTH(tgl_pemesanan) = 12 AND id_produk like '%$cari%') as alpha21_hasil ");
        $alpha22_r = $this->db->query("SELECT 0.2*(SELECT COUNT(tgl_pemesanan) FROM pemesanan WHERE MONTH(tgl_pemesanan) = 1 AND id_produk like '%$cari%')+0.8*(SELECT COUNT(tgl_pemesanan) FROM pemesanan WHERE MONTH(tgl_pemesanan) = 12 AND id_produk like '%$cari%') as alpha22_hasil ");
        $alpha23_r = $this->db->query("SELECT 0.3*(SELECT COUNT(tgl_pemesanan) FROM pemesanan WHERE MONTH(tgl_pemesanan) = 1 AND id_produk like '%$cari%')+0.7*(SELECT COUNT(tgl_pemesanan) FROM pemesanan WHERE MONTH(tgl_pemesanan) = 12 AND id_produk like '%$cari%') as alpha23_hasil ");
        $alpha24_r = $this->db->query("SELECT 0.4*(SELECT COUNT(tgl_pemesanan) FROM pemesanan WHERE MONTH(tgl_pemesanan) = 1 AND id_produk like '%$cari%')+0.6*(SELECT COUNT(tgl_pemesanan) FROM pemesanan WHERE MONTH(tgl_pemesanan) = 12 AND id_produk like '%$cari%') as alpha24_hasil ");
        $alpha25_r = $this->db->query("SELECT 0.5*(SELECT COUNT(tgl_pemesanan) FROM pemesanan WHERE MONTH(tgl_pemesanan) = 1 AND id_produk like '%$cari%')+0.5*(SELECT COUNT(tgl_pemesanan) FROM pemesanan WHERE MONTH(tgl_pemesanan) = 12 AND id_produk like '%$cari%') as alpha25_hasil ");
        $alpha26_r = $this->db->query("SELECT 0.6*(SELECT COUNT(tgl_pemesanan) FROM pemesanan WHERE MONTH(tgl_pemesanan) = 1 AND id_produk like '%$cari%')+0.4*(SELECT COUNT(tgl_pemesanan) FROM pemesanan WHERE MONTH(tgl_pemesanan) = 12 AND id_produk like '%$cari%') as alpha26_hasil ");
        $alpha27_r = $this->db->query("SELECT 0.7*(SELECT COUNT(tgl_pemesanan) FROM pemesanan WHERE MONTH(tgl_pemesanan) = 1 AND id_produk like '%$cari%')+0.3*(SELECT COUNT(tgl_pemesanan) FROM pemesanan WHERE MONTH(tgl_pemesanan) = 12 AND id_produk like '%$cari%') as alpha27_hasil ");
        $alpha28_r = $this->db->query("SELECT 0.8*(SELECT COUNT(tgl_pemesanan) FROM pemesanan WHERE MONTH(tgl_pemesanan) = 1 AND id_produk like '%$cari%')+0.2*(SELECT COUNT(tgl_pemesanan) FROM pemesanan WHERE MONTH(tgl_pemesanan) = 12 AND id_produk like '%$cari%') as alpha28_hasil ");
        $alpha29_r = $this->db->query("SELECT 0.9*(SELECT COUNT(tgl_pemesanan) FROM pemesanan WHERE MONTH(tgl_pemesanan) = 1 AND id_produk like '%$cari%')+0.1*(SELECT COUNT(tgl_pemesanan) FROM pemesanan WHERE MONTH(tgl_pemesanan) = 12 AND id_produk like '%$cari%') as alpha29_hasil ");

        $data = array(
            'data1' => $this->db->query("SELECT COUNT(tgl_pemesanan) AS total1 FROM pemesanan WHERE MONTH(tgl_pemesanan) = 12  AND id_produk like '%$cari%'")->result(), 
            'data2' => $this->db->query("SELECT COUNT(tgl_pemesanan) AS total2 FROM pemesanan WHERE MONTH(tgl_pemesanan) = 1 AND id_produk like '%$cari%'")->result(), 


            'alpha21' => $alpha21_r->result(),
            'alpha22' => $alpha22_r->result(),
            'alpha23' => $alpha23_r->result(),
            'alpha24' => $alpha24_r->result(),
            'alpha25' => $alpha25_r->result(),
            'alpha26' => $alpha26_r->result(),
            'alpha27' => $alpha27_r->result(),
            'alpha28' => $alpha28_r->result(),
            'alpha29' => $alpha29_r->result(),


        );

        $this->load->view('header');
        $this->load->view('peramalan', $data);
        $this->load->view('footer');
    }


}

<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Detail_pemesanan extends My_Controller
{
     protected $access = array('Admin', 'Editor','Author');

    function __construct()
    {
        parent::__construct();
        $this->load->model('Detail_pemesanan_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $detail_pemesanan = $this->Detail_pemesanan_model->get_all();

        $title = array(
            'title' => 'detail_pemesanan',
        );

        $data = array(
            'detail_pemesanan_data' => $detail_pemesanan,
        );
        $this->load->view('cover/header', $title);
        $this->load->view('detail_pemesanan/detail_pemesanan_list', $data);
        $this->load->view('cover/footer');
    }

    public function read($id) 
    {
        $row = $this->Detail_pemesanan_model->get_by_id($id);
        if ($row) {
            $data = array(
		'no_pemesanan' => $row->no_pemesanan,
		'id_pemesanan' => $row->id_pemesanan,
		'id_produk' => $row->id_produk,
		'harga_produk' => $row->harga_produk,
		'jumlah_beli' => $row->jumlah_beli,
		'satuan_produk' => $row->satuan_produk,
	    );

            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('detail_pemesanan/detail_pemesanan_read', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('detail_pemesanan'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('detail_pemesanan/create_action'),
	    'no_pemesanan' => set_value('no_pemesanan'),
	    'id_pemesanan' => set_value('id_pemesanan'),
	    'id_produk' => set_value('id_produk'),
	    'harga_produk' => set_value('harga_produk'),
	    'jumlah_beli' => set_value('jumlah_beli'),
	    'satuan_produk' => set_value('satuan_produk'),
	);
         $title = array(
            'title' => 'Detail',
            );
        $this->load->view('cover/header', $title);
        $this->load->view('detail_pemesanan/detail_pemesanan_form', $data);
        $this->load->view('cover/footer');
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'id_pemesanan' => $this->input->post('id_pemesanan',TRUE),
		'id_produk' => $this->input->post('id_produk',TRUE),
		'harga_produk' => $this->input->post('harga_produk',TRUE),
		'jumlah_beli' => $this->input->post('jumlah_beli',TRUE),
		'satuan_produk' => $this->input->post('satuan_produk',TRUE),
	    );
        
            $this->Detail_pemesanan_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('detail_pemesanan'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Detail_pemesanan_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('detail_pemesanan/update_action'),
		'no_pemesanan' => set_value('no_pemesanan', $row->no_pemesanan),
		'id_pemesanan' => set_value('id_pemesanan', $row->id_pemesanan),
		'id_produk' => set_value('id_produk', $row->id_produk),
		'harga_produk' => set_value('harga_produk', $row->harga_produk),
		'jumlah_beli' => set_value('jumlah_beli', $row->jumlah_beli),
		'satuan_produk' => set_value('satuan_produk', $row->satuan_produk),
	    );
            
            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('detail_pemesanan/detail_pemesanan_form', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('detail_pemesanan'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('no_pemesanan', TRUE));
        } else {
            $data = array(
		'id_pemesanan' => $this->input->post('id_pemesanan',TRUE),
		'id_produk' => $this->input->post('id_produk',TRUE),
		'harga_produk' => $this->input->post('harga_produk',TRUE),
		'jumlah_beli' => $this->input->post('jumlah_beli',TRUE),
		'satuan_produk' => $this->input->post('satuan_produk',TRUE),
	    );

            $this->Detail_pemesanan_model->update($this->input->post('no_pemesanan', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('detail_pemesanan'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Detail_pemesanan_model->get_by_id($id);

        if ($row) {
            $this->Detail_pemesanan_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('detail_pemesanan'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('detail_pemesanan'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('id_pemesanan', 'id pemesanan', 'trim|required');
	$this->form_validation->set_rules('id_produk', 'id produk', 'trim|required');
	$this->form_validation->set_rules('harga_produk', 'harga produk', 'trim|required|numeric');
	$this->form_validation->set_rules('jumlah_beli', 'jumlah beli', 'trim|required');
	$this->form_validation->set_rules('satuan_produk', 'satuan produk', 'trim|required');

	$this->form_validation->set_rules('no_pemesanan', 'no_pemesanan', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "detail_pemesanan.xls";
        $judul = "detail_pemesanan";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Pemesanan");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Produk");
	xlsWriteLabel($tablehead, $kolomhead++, "Harga Produk");
	xlsWriteLabel($tablehead, $kolomhead++, "Jumlah Beli");
	xlsWriteLabel($tablehead, $kolomhead++, "Satuan Produk");

	foreach ($this->Detail_pemesanan_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_pemesanan);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_produk);
	    xlsWriteNumber($tablebody, $kolombody++, $data->harga_produk);
	    xlsWriteNumber($tablebody, $kolombody++, $data->jumlah_beli);
	    xlsWriteLabel($tablebody, $kolombody++, $data->satuan_produk);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=detail_pemesanan.doc");

        $data = array(
            'detail_pemesanan_data' => $this->Detail_pemesanan_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('detail_pemesanan/detail_pemesanan_doc',$data);
    }

}

/* End of file Detail_pemesanan.php */
/* Location: ./application/controllers/Detail_pemesanan.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-06-02 02:05:20 */
/* http://harviacode.com */
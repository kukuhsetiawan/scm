<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Persediaan_produk extends My_Controller
{
     protected $access = array('Admin', 'Editor','Author');

    function __construct()
    {
        parent::__construct();
        $this->load->model('Persediaan_produk_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $persediaan_produk = $this->Persediaan_produk_model->get_all();

        $title = array(
            'title' => 'persediaan_produk',
        );

        $data = array(
            'persediaan_produk_data' => $persediaan_produk,
        );
        $this->load->view('cover/header', $title);
        $this->load->view('persediaan_produk/persediaan_produk_list', $data);
        $this->load->view('cover/footer');
    }

    public function read($id) 
    {
        $row = $this->Persediaan_produk_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_persediaan_produk' => $row->id_persediaan_produk,
		'id_pemesanan' => $row->id_pemesanan,
		'id_produk' => $row->id_produk,
		'stok' => $row->stok,
		'jumlah_produksi' => $row->jumlah_produksi,
	    );

            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('persediaan_produk/persediaan_produk_read', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('persediaan_produk'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('persediaan_produk/create_action'),
	    'id_persediaan_produk' => set_value('id_persediaan_produk'),
	    'id_pemesanan' => set_value('id_pemesanan'),
	    'id_produk' => set_value('id_produk'),
	    'stok' => set_value('stok'),
	    'jumlah_produksi' => set_value('jumlah_produksi'),
	);
         $title = array(
            'title' => 'Detail',
            );
        $this->load->view('cover/header', $title);
        $this->load->view('persediaan_produk/persediaan_produk_form', $data);
        $this->load->view('cover/footer');
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'id_pemesanan' => $this->input->post('id_pemesanan',TRUE),
		'id_produk' => $this->input->post('id_produk',TRUE),
		'stok' => $this->input->post('stok',TRUE),
		'jumlah_produksi' => $this->input->post('jumlah_produksi',TRUE),
	    );
        
            $this->Persediaan_produk_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('persediaan_produk'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Persediaan_produk_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('persediaan_produk/update_action'),
		'id_persediaan_produk' => set_value('id_persediaan_produk', $row->id_persediaan_produk),
		'id_pemesanan' => set_value('id_pemesanan', $row->id_pemesanan),
		'id_produk' => set_value('id_produk', $row->id_produk),
		'stok' => set_value('stok', $row->stok),
		'jumlah_produksi' => set_value('jumlah_produksi', $row->jumlah_produksi),
	    );
            
            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('persediaan_produk/persediaan_produk_form', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('persediaan_produk'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_persediaan_produk', TRUE));
        } else {
            $data = array(
		'id_pemesanan' => $this->input->post('id_pemesanan',TRUE),
		'id_produk' => $this->input->post('id_produk',TRUE),
		'stok' => $this->input->post('stok',TRUE),
		'jumlah_produksi' => $this->input->post('jumlah_produksi',TRUE),
	    );

            $this->Persediaan_produk_model->update($this->input->post('id_persediaan_produk', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('persediaan_produk'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Persediaan_produk_model->get_by_id($id);

        if ($row) {
            $this->Persediaan_produk_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('persediaan_produk'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('persediaan_produk'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('id_pemesanan', 'id pemesanan', 'trim|required');
	$this->form_validation->set_rules('id_produk', 'id produk', 'trim|required');
	$this->form_validation->set_rules('stok', 'stok', 'trim|required');
	$this->form_validation->set_rules('jumlah_produksi', 'jumlah produksi', 'trim|required');

	$this->form_validation->set_rules('id_persediaan_produk', 'id_persediaan_produk', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "persediaan_produk.xls";
        $judul = "persediaan_produk";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Pemesanan");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Produk");
	xlsWriteLabel($tablehead, $kolomhead++, "Stok");
	xlsWriteLabel($tablehead, $kolomhead++, "Jumlah Produksi");

	foreach ($this->Persediaan_produk_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_pemesanan);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_produk);
	    xlsWriteNumber($tablebody, $kolombody++, $data->stok);
	    xlsWriteNumber($tablebody, $kolombody++, $data->jumlah_produksi);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=persediaan_produk.doc");

        $data = array(
            'persediaan_produk_data' => $this->Persediaan_produk_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('persediaan_produk/persediaan_produk_doc',$data);
    }

}

/* End of file Persediaan_produk.php */
/* Location: ./application/controllers/Persediaan_produk.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-05-09 17:32:15 */
/* http://harviacode.com */
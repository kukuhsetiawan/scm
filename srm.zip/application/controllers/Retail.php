<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Retail extends My_Controller
{
     protected $access = array('Pemasaran', 'Pemesanan');

    function __construct()
    {
        parent::__construct();
        $this->load->model('Retail_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $retail = $this->Retail_model->get_all();

        $title = array(
            'title' => 'retail',
        );

        $data = array(
            'retail_data' => $retail,
        );
        $this->load->view('cover/header', $title);
        $this->load->view('retail/retail_list', $data);
        $this->load->view('cover/footer');
    }

    public function read($id) 
    {
        $row = $this->Retail_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id' => $row->id,
		'id_retail' => $row->id_retail,
		'nama' => $row->nama,
		'no_telp' => $row->no_telp,
		'alamat' => $row->alamat,
		'lokasi' => $row->lokasi,
		'id_user' => $row->id_user,
	    );

            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('retail/retail_read', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('retail'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('retail/create_action'),
	    'id' => set_value('id'),
	    'id_retail' => set_value('id_retail'),
	    'nama' => set_value('nama'),
	    'no_telp' => set_value('no_telp'),
	    'alamat' => set_value('alamat'),
	    'lokasi' => set_value('lokasi'),
	    'id_user' => set_value('id_user'),
        
	);
         $title = array(
            'title' => 'Detail',
            );
        $this->load->view('cover/header', $title);
        $this->load->view('retail/retail_form', $data);
        $this->load->view('cover/footer');
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'id_retail' => $this->input->post('id_retail',TRUE),
		'nama' => $this->input->post('nama',TRUE),
		'no_telp' => $this->input->post('no_telp',TRUE),
		'alamat' => $this->input->post('alamat',TRUE),
		'lokasi' => $this->input->post('lokasi',TRUE),
		'id_user' => $this->input->post('id_user',TRUE),
	    );
        
            $this->Retail_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('retail'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Retail_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('retail/update_action'),
		'id' => set_value('id', $row->id),
		'id_retail' => set_value('id_retail', $row->id_retail),
		'nama' => set_value('nama', $row->nama),
		'no_telp' => set_value('no_telp', $row->no_telp),
		'alamat' => set_value('alamat', $row->alamat),
		'lokasi' => set_value('lokasi', $row->lokasi),
		'id_user' => set_value('id_user', $row->id_user),
	    );
            
            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('retail/retail_form', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('retail'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'id_retail' => $this->input->post('id_retail',TRUE),
		'nama' => $this->input->post('nama',TRUE),
		'no_telp' => $this->input->post('no_telp',TRUE),
		'alamat' => $this->input->post('alamat',TRUE),
		'lokasi' => $this->input->post('lokasi',TRUE),
		'id_user' => $this->input->post('id_user',TRUE),
	    );

            $this->Retail_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('retail'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Retail_model->get_by_id($id);

        if ($row) {
            $this->Retail_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('retail'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('retail'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('id_retail', 'id retail', 'trim|required');
	$this->form_validation->set_rules('nama', 'nama', 'trim|required');
	$this->form_validation->set_rules('no_telp', 'no telp', 'trim|required');
	$this->form_validation->set_rules('alamat', 'alamat', 'trim|required');
	$this->form_validation->set_rules('lokasi', 'lokasi', 'trim|required');
	$this->form_validation->set_rules('id_user', 'id user', 'trim|required');

	$this->form_validation->set_rules('id', 'id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "retail.xls";
        $judul = "retail";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Retail");
	xlsWriteLabel($tablehead, $kolomhead++, "Nama");
	xlsWriteLabel($tablehead, $kolomhead++, "No Telp");
	xlsWriteLabel($tablehead, $kolomhead++, "Alamat");
	xlsWriteLabel($tablehead, $kolomhead++, "Lokasi");
	xlsWriteLabel($tablehead, $kolomhead++, "Id User");

	foreach ($this->Retail_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_retail);
	    xlsWriteNumber($tablebody, $kolombody++, $data->nama);
	    xlsWriteNumber($tablebody, $kolombody++, $data->no_telp);
	    xlsWriteNumber($tablebody, $kolombody++, $data->alamat);
	    xlsWriteLabel($tablebody, $kolombody++, $data->lokasi);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_user);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=retail.doc");

        $data = array(
            'retail_data' => $this->Retail_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('retail/retail_doc',$data);
    }

}

/* End of file Retail.php */
/* Location: ./application/controllers/Retail.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-06-02 02:05:24 */
/* http://harviacode.com */
<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Safety_stock extends MY_Controller {
    
    protected $access = array('Gudang','Pengadaan');

    function __construct()
    {
        parent::__construct();
        $this->load->model('Bom_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'bom/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'bom/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'bom/index.html';
            $config['first_url'] = base_url() . 'bom/index.html';
        }

        $config['per_page'] = 100;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Bom_model->total_rows($q);
        $bom = $this->db->query("SELECT ba.nama_bahan_baku as n_bahan_baku, bo.jumlah_kebutuhan as j_kebutuhan, ba.stock_aman as stock, ba.satuan as s_bahan_baku FROM bahan_baku ba, bom bo WHERE ba.id = bo.id_bahan_baku ");

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'bom_data' => $bom,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );

        $this->load->view('cover/header');
        $this->load->view('monitoring', $data);
        $this->load->view('cover/footer');
    }

    public function eoq_nota($value = '')
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'bom/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'bom/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'bom/index.html';
            $config['first_url'] = base_url() . 'bom/index.html';
        }

        $config['per_page'] = 100;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Bom_model->total_rows($q);
        $bom = $this->db->query("SELECT bo.id_bom as id_bom, ba.nama_bahan_baku as n_bahan_baku, bo.jumlah_kebutuhan as j_kebutuhan, ba.stock as stock, ba.satuan_bahan_baku as s_bahan_baku FROM bahan_baku ba, bom bo WHERE ba.id_bahan_baku = bo.id_bahan_baku AND bo.id_bom = '$value'");

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'bom_data' => $bom,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );

        $this->load->view('eoq_nota', $data);
    }

    public function eoq()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'bom/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'bom/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'bom/index.html';
            $config['first_url'] = base_url() . 'bom/index.html';
        }

        $config['per_page'] = 100;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Bom_model->total_rows($q);
        $bom = $this->db->query("SELECT ba.nama_bahan_baku as n_bahan_baku, bo.jumlah_kebutuhan as j_kebutuhan, ba.stock as stock, ba.satuan_bahan_baku as s_bahan_baku FROM bahan_baku ba, bom bo WHERE ba.id_bahan_baku = bo.id_bahan_baku AND nama_bahan_baku='Cat' OR nama_bahan_baku='Impra' OR nama_bahan_baku='Dempul' OR nama_bahan_baku='Kayu bakar'");

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'bom_data' => $bom,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );

        $this->load->view('cover/header');
        $this->load->view('eoq', $data);
        $this->load->view('cover/footer');
    }

    public function rop()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'bom/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'bom/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'bom/index.html';
            $config['first_url'] = base_url() . 'bom/index.html';
        }

        $config['per_page'] = 100;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Bom_model->total_rows($q);
        $bom = $this->db->query("SELECT nama_bahan_baku as n_bahan_baku, stock, satuan_bahan_baku as s_bahan_baku FROM bahan_baku WHERE nama_bahan_baku='Tanah liat' OR nama_bahan_baku='Pasir kali'");

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'bom_data' => $bom,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );

        $this->load->view('cover/header');
        $this->load->view('rop', $data);
        $this->load->view('cover/footer');
    }

   

   

}

/* End of file Bom.php */
/* Location: ./application/controllers/Bom.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-01-29 23:43:19 */
/* http://harviacode.com */
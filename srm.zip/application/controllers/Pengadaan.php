<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Pengadaan extends MY_Controller {
    
    protected $access = array('Gudang','Pengadaan','Keuangan','Pemilik','Pemasaran','Produksi', 'Distribusi');

    function __construct()
    {
        parent::__construct();
        $this->load->model('Pengadaan_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'pengadaan/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'pengadaan/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'pengadaan/index.html';
            $config['first_url'] = base_url() . 'pengadaan/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Pengadaan_model->total_rows($q);
        $pengadaan = $this->Pengadaan_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'pengadaan_data' => $pengadaan,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );

        $this->load->view('cover/header');
        $this->load->view('pengadaan/pengadaan_list', $data);
        $this->load->view('cover/footer');
    }
    public function read_bahan_baku($value='')
    {
        $this->db->where('id_supplier', $value);
        $data['pengadaan_data'] = $this->db->get('pengadaan')->result();
        $data['supplier'] = $this->db->query("SELECT * FROM supplier WHERE id_supplier='$value'")->result();
        $this->load->view('pengadaan_bahan_baku', $data);
    }
    public function read($id) 
    {
        $row = $this->Pengadaan_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id' => $row->id,
		'id_bahan_baku' => $row->id_bahan_baku,
		'id_supplier' => $row->id_supplier,
		'jumlah_rencana_pemberlian' => $row->jumlah_rencana_pemberlian,
		'tanggal_pembelian' => $row->tanggal_pembelian,
	    );
            $this->load->view('pengadaan/pengadaan_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('pengadaan'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('pengadaan/create_action'),
	    'id' => set_value('id'),
	    'id_bahan_baku' => set_value('id_bahan_baku'),
	    'id_supplier' => set_value('id_supplier'),
	    'jumlah_rencana_pemberlian' => set_value('jumlah_rencana_pemberlian'),
	    'tanggal_pembelian' => set_value('tanggal_pembelian'),
        'bahan_baku' =>$this->db->get('bahan_baku'),
        'supplier' =>$this->db->get('supplier')
	);

        $this->load->view('cover/header');
        $this->load->view('pengadaan/pengadaan_form', $data);
        $this->load->view('cover/footer');
    }
    
    public function create_action() 
    {
        
            $data = array(
		'id_bahan_baku' => $this->input->post('id_bahan_baku',TRUE),
		'id_supplier' => $this->input->post('id_supplier',TRUE),
		'jumlah_rencana_pemberlian' => $this->input->post('jumlah_rencana_pemberlian',TRUE),
		'tanggal_pembelian' => $this->input->post('tanggal_pembelian',TRUE),
	    );

            $this->Pengadaan_model->insert($data);
            $this->session->set_flashdata('message', '<div class="col-md-12"><div class="alert alert-success" id="alert">Create Record Success</div></div>');
            redirect(site_url('pengadaan'));
    
    }
    
    public function update($id) 
    {
        $row = $this->Pengadaan_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('pengadaan/update_action'),
		'id' => set_value('id', $row->id),
		'id_bahan_baku' => set_value('id_bahan_baku', $row->id_bahan_baku),
		'id_supplier' => set_value('id_supplier', $row->id_supplier),
		'jumlah_rencana_pemberlian' => set_value('jumlah_rencana_pemberlian', $row->jumlah_rencana_pemberlian),
		'tanggal_pembelian' => set_value('tanggal_pembelian', $row->tanggal_pembelian),
	    );

            $this->load->view('header');
            $this->load->view('pengadaan/pengadaan_form', $data);
            $this->load->view('footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('pengadaan'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'id_bahan_baku' => $this->input->post('id_bahan_baku',TRUE),
		'id_supplier' => $this->input->post('id_supplier',TRUE),
		'jumlah_rencana_pemberlian' => $this->input->post('jumlah_rencana_pemberlian',TRUE),
		'tanggal_pembelian' => $this->input->post('tanggal_pembelian',TRUE),
	    );

            $this->Pengadaan_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', '<div class="col-md-12"><div class="alert alert-info" id="alert">Update Record Success</div></div>');
            redirect(site_url('pengadaan'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Pengadaan_model->get_by_id($id);

        if ($row) {
            $this->Pengadaan_model->delete($id);
            $this->session->set_flashdata('message', '<div class="col-md-12"><div class="alert alert-danger" id="alert">Delete Record Success</div></div>');
            redirect(site_url('pengadaan'));
        } else {
            $this->session->set_flashdata('message', '<div class="col-md-12"><div class="alert alert-info" id="alert">Record Not Found</div></div>');
            redirect(site_url('pengadaan'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('id_bahan_baku', 'id bahan baku', 'trim|required');
	$this->form_validation->set_rules('id_supplier', 'id supplier', 'trim|required');
	$this->form_validation->set_rules('jumlah_rencana_pemberlian', 'jumlah rencana pemberlian', 'trim|required');
	$this->form_validation->set_rules('tanggal_pembelian', 'tanggal pembelian', 'trim|required');

	$this->form_validation->set_rules('id', 'id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Pengadaan.php */
/* Location: ./application/controllers/Pengadaan.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-02-18 03:28:42 */
/* http://harviacode.com */
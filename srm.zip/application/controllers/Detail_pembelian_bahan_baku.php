<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Detail_pembelian_bahan_baku extends My_Controller
{
     protected $access = array('Admin', 'Editor','Author');

    function __construct()
    {
        parent::__construct();
        $this->load->model('Detail_pembelian_bahan_baku_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $detail_pembelian_bahan_baku = $this->Detail_pembelian_bahan_baku_model->get_all();

        $title = array(
            'title' => 'detail_pembelian_bahan_baku',
        );

        $data = array(
            'detail_pembelian_bahan_baku_data' => $detail_pembelian_bahan_baku,
        );
        $this->load->view('cover/header', $title);
        $this->load->view('detail_pembelian_bahan_baku/detail_pembelian_bahan_baku_list', $data);
        $this->load->view('cover/footer');
    }

    public function read($id) 
    {
        $row = $this->Detail_pembelian_bahan_baku_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_detail_bahan_baku' => $row->id_detail_bahan_baku,
		'id_pengadaan' => $row->id_pengadaan,
		'id_bahan_baku' => $row->id_bahan_baku,
		'jumlah_kebutuhan' => $row->jumlah_kebutuhan,
		'harga' => $row->harga,
		'status_bahan_baku' => $row->status_bahan_baku,
	    );

            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('detail_pembelian_bahan_baku/detail_pembelian_bahan_baku_read', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('detail_pembelian_bahan_baku'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('detail_pembelian_bahan_baku/create_action'),
	    'id_detail_bahan_baku' => set_value('id_detail_bahan_baku'),
	    'id_pengadaan' => set_value('id_pengadaan'),
	    'id_bahan_baku' => set_value('id_bahan_baku'),
	    'jumlah_kebutuhan' => set_value('jumlah_kebutuhan'),
	    'harga' => set_value('harga'),
	    'status_bahan_baku' => set_value('status_bahan_baku'),
	);
         $title = array(
            'title' => 'Detail',
            );
        $this->load->view('cover/header', $title);
        $this->load->view('detail_pembelian_bahan_baku/detail_pembelian_bahan_baku_form', $data);
        $this->load->view('cover/footer');
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'id_pengadaan' => $this->input->post('id_pengadaan',TRUE),
		'id_bahan_baku' => $this->input->post('id_bahan_baku',TRUE),
		'jumlah_kebutuhan' => $this->input->post('jumlah_kebutuhan',TRUE),
		'harga' => $this->input->post('harga',TRUE),
		'status_bahan_baku' => $this->input->post('status_bahan_baku',TRUE),
	    );
        
            $this->Detail_pembelian_bahan_baku_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('detail_pembelian_bahan_baku'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Detail_pembelian_bahan_baku_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('detail_pembelian_bahan_baku/update_action'),
		'id_detail_bahan_baku' => set_value('id_detail_bahan_baku', $row->id_detail_bahan_baku),
		'id_pengadaan' => set_value('id_pengadaan', $row->id_pengadaan),
		'id_bahan_baku' => set_value('id_bahan_baku', $row->id_bahan_baku),
		'jumlah_kebutuhan' => set_value('jumlah_kebutuhan', $row->jumlah_kebutuhan),
		'harga' => set_value('harga', $row->harga),
		'status_bahan_baku' => set_value('status_bahan_baku', $row->status_bahan_baku),
	    );
            
            $title = array(
            'title' => 'Detail',
            );
            $this->load->view('cover/header', $title);
            $this->load->view('detail_pembelian_bahan_baku/detail_pembelian_bahan_baku_form', $data);
            $this->load->view('cover/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('detail_pembelian_bahan_baku'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_detail_bahan_baku', TRUE));
        } else {
            $data = array(
		'id_pengadaan' => $this->input->post('id_pengadaan',TRUE),
		'id_bahan_baku' => $this->input->post('id_bahan_baku',TRUE),
		'jumlah_kebutuhan' => $this->input->post('jumlah_kebutuhan',TRUE),
		'harga' => $this->input->post('harga',TRUE),
		'status_bahan_baku' => $this->input->post('status_bahan_baku',TRUE),
	    );

            $this->Detail_pembelian_bahan_baku_model->update($this->input->post('id_detail_bahan_baku', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('detail_pembelian_bahan_baku'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Detail_pembelian_bahan_baku_model->get_by_id($id);

        if ($row) {
            $this->Detail_pembelian_bahan_baku_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('detail_pembelian_bahan_baku'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('detail_pembelian_bahan_baku'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('id_pengadaan', 'id pengadaan', 'trim|required');
	$this->form_validation->set_rules('id_bahan_baku', 'id bahan baku', 'trim|required');
	$this->form_validation->set_rules('jumlah_kebutuhan', 'jumlah kebutuhan', 'trim|required');
	$this->form_validation->set_rules('harga', 'harga', 'trim|required|numeric');
	$this->form_validation->set_rules('status_bahan_baku', 'status bahan baku', 'trim|required');

	$this->form_validation->set_rules('id_detail_bahan_baku', 'id_detail_bahan_baku', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "detail_pembelian_bahan_baku.xls";
        $judul = "detail_pembelian_bahan_baku";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Pengadaan");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Bahan Baku");
	xlsWriteLabel($tablehead, $kolomhead++, "Jumlah Kebutuhan");
	xlsWriteLabel($tablehead, $kolomhead++, "Harga");
	xlsWriteLabel($tablehead, $kolomhead++, "Status Bahan Baku");

	foreach ($this->Detail_pembelian_bahan_baku_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_pengadaan);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_bahan_baku);
	    xlsWriteNumber($tablebody, $kolombody++, $data->jumlah_kebutuhan);
	    xlsWriteNumber($tablebody, $kolombody++, $data->harga);
	    xlsWriteLabel($tablebody, $kolombody++, $data->status_bahan_baku);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=detail_pembelian_bahan_baku.doc");

        $data = array(
            'detail_pembelian_bahan_baku_data' => $this->Detail_pembelian_bahan_baku_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('detail_pembelian_bahan_baku/detail_pembelian_bahan_baku_doc',$data);
    }

}

/* End of file Detail_pembelian_bahan_baku.php */
/* Location: ./application/controllers/Detail_pembelian_bahan_baku.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-06-02 02:05:19 */
/* http://harviacode.com */
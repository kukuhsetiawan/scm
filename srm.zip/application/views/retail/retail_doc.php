<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            .word-table {
                border:1px solid black !important; 
                border-collapse: collapse !important;
                width: 100%;
            }
            .word-table tr th, .word-table tr td{
                border:1px solid black !important; 
                padding: 5px 10px;
            }
        </style>
    </head>
    <body>
        <h2>Retail List</h2>
        <table class="word-table" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>Id Retail</th>
		<th>Nama</th>
		<th>No Telp</th>
		<th>Alamat</th>
		<th>Lokasi</th>
		<th>Id User</th>
		
            </tr><?php
            foreach ($retail_data as $retail)
            {
                ?>
                <tr>
		      <td><?php echo ++$start ?></td>
		      <td><?php echo $retail->id_retail ?></td>
		      <td><?php echo $retail->nama ?></td>
		      <td><?php echo $retail->no_telp ?></td>
		      <td><?php echo $retail->alamat ?></td>
		      <td><?php echo $retail->lokasi ?></td>
		      <td><?php echo $retail->id_user ?></td>	
                </tr>
                <?php
            }
            ?>
        </table>
    </body>
</html>

        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Bahan_baku_supplier <?php echo $button ?></h2>
         <div class="box-body">
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">Id Bahan Baku Supp <?php echo form_error('id_bahan_baku_supp') ?></label>
            <input type="text" class="form-control" name="id_bahan_baku_supp" id="id_bahan_baku_supp" placeholder="Id Bahan Baku Supp" value="<?php echo $id_bahan_baku_supp; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Id Supplier <?php echo form_error('id_supplier') ?></label>
            <input type="text" class="form-control" name="id_supplier" id="id_supplier" placeholder="Id Supplier" value="<?php echo $id_supplier; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Nama Bahan Baku <?php echo form_error('nama_bahan_baku') ?></label>
            <input type="text" class="form-control" name="nama_bahan_baku" id="nama_bahan_baku" placeholder="Nama Bahan Baku" value="<?php echo $nama_bahan_baku; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Stock <?php echo form_error('stock') ?></label>
            <input type="text" class="form-control" name="stock" id="stock" placeholder="Stock" value="<?php echo $stock; ?>" />
        </div>
	    <div class="form-group">
            <label for="double">Harga <?php echo form_error('harga') ?></label>
            <input type="text" class="form-control" name="harga" id="harga" placeholder="Harga" value="<?php echo $harga; ?>" />
        </div>
	    <input type="hidden" name="id" value="<?php echo $id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('bahan_baku_supplier') ?>" class="btn btn-default">Cancel</a>
	</form>
    </div>

        </div>
    </section>
    </div>
    </section>    
    
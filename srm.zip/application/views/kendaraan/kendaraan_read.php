
        
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Kendaraan Read</h2>
        <div class="box-body">
        <table class="table">
	    <tr><td>No Polisi</td><td><?php echo $no_polisi; ?></td></tr>
	    <tr><td>Jenis Kendaraan</td><td><?php echo $jenis_kendaraan; ?></td></tr>
	    <tr><td>Kapasitas</td><td><?php echo $kapasitas; ?></td></tr>
	    <tr><td>Status Operasi</td><td><?php echo $status_operasi; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('kendaraan') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </div>

        </div>
    </section>
    </div>
    </section>    
    
        
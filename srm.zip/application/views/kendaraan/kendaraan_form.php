
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Kendaraan <?php echo $button ?></h2>
         <div class="box-body">
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">No Polisi <?php echo form_error('no_polisi') ?></label>
            <input type="text" class="form-control" name="no_polisi" id="no_polisi" placeholder="No Polisi" value="<?php echo $no_polisi; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Jenis Kendaraan <?php echo form_error('jenis_kendaraan') ?></label>
            <input type="text" class="form-control" name="jenis_kendaraan" id="jenis_kendaraan" placeholder="Jenis Kendaraan" value="<?php echo $jenis_kendaraan; ?>" />
        </div>
	    <div class="form-group">
            <label for="double">Kapasitas <?php echo form_error('kapasitas') ?></label>
            <input type="text" class="form-control" name="kapasitas" id="kapasitas" placeholder="Kapasitas" value="<?php echo $kapasitas; ?>" />
        </div>
	    <div class="form-group">
            <label for="enum">Status Operasi <?php echo form_error('status_operasi') ?></label>
            <input type="text" class="form-control" name="status_operasi" id="status_operasi" placeholder="Status Operasi" value="<?php echo $status_operasi; ?>" />
        </div>
	    <input type="hidden" name="id" value="<?php echo $id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('kendaraan') ?>" class="btn btn-default">Cancel</a>
	</form>
    </div>

        </div>
    </section>
    </div>
    </section>    
    
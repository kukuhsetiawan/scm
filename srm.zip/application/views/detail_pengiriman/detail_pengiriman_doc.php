<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            .word-table {
                border:1px solid black !important; 
                border-collapse: collapse !important;
                width: 100%;
            }
            .word-table tr th, .word-table tr td{
                border:1px solid black !important; 
                padding: 5px 10px;
            }
        </style>
    </head>
    <body>
        <h2>Detail_pengiriman List</h2>
        <table class="word-table" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>Id Pengiriman</th>
		<th>Id Pemesanan</th>
		<th>Id Produk</th>
		<th>Status</th>
		
            </tr><?php
            foreach ($detail_pengiriman_data as $detail_pengiriman)
            {
                ?>
                <tr>
		      <td><?php echo ++$start ?></td>
		      <td><?php echo $detail_pengiriman->id_pengiriman ?></td>
		      <td><?php echo $detail_pengiriman->id_pemesanan ?></td>
		      <td><?php echo $detail_pengiriman->id_produk ?></td>
		      <td><?php echo $detail_pengiriman->status ?></td>	
                </tr>
                <?php
            }
            ?>
        </table>
    </body>
</html>
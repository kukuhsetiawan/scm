
        
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Supir Read</h2>
        <div class="box-body">
        <table class="table">
	    <tr><td>Nama</td><td><?php echo $nama; ?></td></tr>
	    <tr><td>Sim</td><td><?php echo $sim; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('supir') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </div>

        </div>
    </section>
    </div>
    </section>    
    
        
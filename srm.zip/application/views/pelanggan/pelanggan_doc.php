<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            .word-table {
                border:1px solid black !important; 
                border-collapse: collapse !important;
                width: 100%;
            }
            .word-table tr th, .word-table tr td{
                border:1px solid black !important; 
                padding: 5px 10px;
            }
        </style>
    </head>
    <body>
        <h2>Pelanggan List</h2>
        <table class="word-table" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>Nama Pelanggan</th>
		<th>Telp Pel</th>
		<th>Alamat Pelanggan</th>
		<th>Username</th>
		<th>Lokasi</th>
		<th>Jenis Kirim</th>
		
            </tr><?php
            foreach ($pelanggan_data as $pelanggan)
            {
                ?>
                <tr>
		      <td><?php echo ++$start ?></td>
		      <td><?php echo $pelanggan->nama_pelanggan ?></td>
		      <td><?php echo $pelanggan->telp_pel ?></td>
		      <td><?php echo $pelanggan->alamat_pelanggan ?></td>
		      <td><?php echo $pelanggan->username ?></td>
		      <td><?php echo $pelanggan->lokasi ?></td>
		      <td><?php echo $pelanggan->jenis_kirim ?></td>	
                </tr>
                <?php
            }
            ?>
        </table>
    </body>
</html>
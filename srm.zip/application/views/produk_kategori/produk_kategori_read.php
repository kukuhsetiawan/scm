
        
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Produk_kategori Read</h2>
        <div class="box-body">
        <table class="table">
	    <tr><td>Kategori</td><td><?php echo $kategori; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('produk_kategori') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </div>

        </div>
    </section>
    </div>
    </section>    
    
        
<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            .word-table {
                border:1px solid black !important; 
                border-collapse: collapse !important;
                width: 100%;
            }
            .word-table tr th, .word-table tr td{
                border:1px solid black !important; 
                padding: 5px 10px;
            }
        </style>
    </head>
    <body>
        <h2>Bahan_baku List</h2>
        <table class="word-table" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>Id Bahan Baku</th>
		<th>Jenis Bahan Baku</th>
		<th>Nama Bahan Baku</th>
		<th>Id Supplier</th>
		<th>Harga Bahan Baku</th>
		<th>Satuan</th>
		<th>Stock Aman</th>
		<th>Keterangan</th>
		
            </tr><?php
            foreach ($bahan_baku_data as $bahan_baku)
            {
                ?>
                <tr>
		      <td><?php echo ++$start ?></td>
		      <td><?php echo $bahan_baku->id_bahan_baku ?></td>
		      <td><?php echo $bahan_baku->jenis_bahan_baku ?></td>
		      <td><?php echo $bahan_baku->nama_bahan_baku ?></td>
		      <td><?php echo $bahan_baku->id_supplier ?></td>
		      <td><?php echo $bahan_baku->harga_bahan_baku ?></td>
		      <td><?php echo $bahan_baku->satuan ?></td>
		      <td><?php echo $bahan_baku->stock_aman ?></td>
		      <td><?php echo $bahan_baku->keterangan ?></td>	
                </tr>
                <?php
            }
            ?>
        </table>
    </body>
</html>
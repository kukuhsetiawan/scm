
        
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Supplier Read</h2>
        <div class="box-body">
        <table class="table">
	    <tr><td>Id Supplier</td><td><?php echo $id_supplier; ?></td></tr>
	    <tr><td>Nama Supplier</td><td><?php echo $nama_supplier; ?></td></tr>
	    <tr><td>Telp Supp</td><td><?php echo $telp_supp; ?></td></tr>
	    <tr><td>Alamat Supplier</td><td><?php echo $alamat_supplier; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('supplier') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </div>

        </div>
    </section>
    </div>
    </section>    
    
        
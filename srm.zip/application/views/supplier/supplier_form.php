
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Supplier <?php echo $button ?></h2>
         <div class="box-body">
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">Id Supplier <?php echo form_error('id_supplier') ?></label>
            <input type="text" class="form-control" name="id_supplier" id="id_supplier" placeholder="Id Supplier" value="<?php echo $id_supplier; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Nama Supplier <?php echo form_error('nama_supplier') ?></label>
            <input type="text" class="form-control" name="nama_supplier" id="nama_supplier" placeholder="Nama Supplier" value="<?php echo $nama_supplier; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Telp Supp <?php echo form_error('telp_supp') ?></label>
            <input type="text" class="form-control" name="telp_supp" id="telp_supp" placeholder="Telp Supp" value="<?php echo $telp_supp; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Alamat Supplier <?php echo form_error('alamat_supplier') ?></label>
            <input type="text" class="form-control" name="alamat_supplier" id="alamat_supplier" placeholder="Alamat Supplier" value="<?php echo $alamat_supplier; ?>" />
        </div>
	    <input type="hidden" name="id" value="<?php echo $id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('supplier') ?>" class="btn btn-default">Cancel</a>
	</form>
    </div>

        </div>
    </section>
    </div>
    </section>    
    

<?php

    $to        = "indra@gmail.com";    //Email tujuan pengiriman
    $subject = "Lupa Password Asihhati furniture";
    $headers    = "Email Dari: ".$_GET['email'];
    $message    = "Ini dari lupa password agus, tolong segera passwordnya dikasih tau ke ".$_GET['email'];
 
    if($_GET['email']){
        mail($to,$subject,$message,$headers); //fungsi mail() untuk mengirimkan email
        echo "<script language='JavaScript'>alert('Pesan Terkirim :) ');window.location.href='auth';</script>"; // pesan jika email berhasil di kirim

    } else {
	
        echo "<script language='JavaScript'>alert('Silahkan masukan email anda :)');window.location.href='auth/forget';</script>";

    }



?>



        
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Peramalan_bahan_baku Read</h2>
        <div class="box-body">
        <table class="table">
	    <tr><td>Id Bahan Baku</td><td><?php echo $id_bahan_baku; ?></td></tr>
	    <tr><td>Periode</td><td><?php echo $periode; ?></td></tr>
	    <tr><td>Id User</td><td><?php echo $id_user; ?></td></tr>
	    <tr><td>Permintaan</td><td><?php echo $permintaan; ?></td></tr>
	    <tr><td>Nilai Alpha</td><td><?php echo $nilai_alpha; ?></td></tr>
	    <tr><td>Hasil Peramalan</td><td><?php echo $hasil_peramalan; ?></td></tr>
	    <tr><td>Id Pengadaan</td><td><?php echo $id_pengadaan; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('peramalan_bahan_baku') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </div>

        </div>
    </section>
    </div>
    </section>    
    
        
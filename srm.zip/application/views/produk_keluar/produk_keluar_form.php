
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Produk_keluar <?php echo $button ?></h2>
         <div class="box-body">
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="int">Id Persediaan Produk <?php echo form_error('id_persediaan_produk') ?></label>
            <input type="text" class="form-control" name="id_persediaan_produk" id="id_persediaan_produk" placeholder="Id Persediaan Produk" value="<?php echo $id_persediaan_produk; ?>" />
        </div>
	    <div class="form-group">
            <label for="date">Tanggal Pengeluaran <?php echo form_error('tanggal_pengeluaran') ?></label>
            <input type="text" class="form-control" name="tanggal_pengeluaran" id="tanggal_pengeluaran" placeholder="Tanggal Pengeluaran" value="<?php echo $tanggal_pengeluaran; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Jumlah <?php echo form_error('jumlah') ?></label>
            <input type="text" class="form-control" name="jumlah" id="jumlah" placeholder="Jumlah" value="<?php echo $jumlah; ?>" />
        </div>
	    <input type="hidden" name="id" value="<?php echo $id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('produk_keluar') ?>" class="btn btn-default">Cancel</a>
	</form>
    </div>

        </div>
    </section>
    </div>
    </section>    
    
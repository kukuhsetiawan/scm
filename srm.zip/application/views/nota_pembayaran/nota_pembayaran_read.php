
        
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Nota_pembayaran Read</h2>
        <div class="box-body">
        <table class="table">
	    <tr><td>No Pembayaran</td><td><?php echo $no_pembayaran; ?></td></tr>
	    <tr><td>Total Bayar</td><td><?php echo $total_bayar; ?></td></tr>
	    <tr><td>Id Pemesanan</td><td><?php echo $id_pemesanan; ?></td></tr>
	    <tr><td>Status Pembayaran</td><td><?php echo $status_pembayaran; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('nota_pembayaran') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </div>

        </div>
    </section>
    </div>
    </section>    
    
        
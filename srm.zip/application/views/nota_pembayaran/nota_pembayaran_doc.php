<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            .word-table {
                border:1px solid black !important; 
                border-collapse: collapse !important;
                width: 100%;
            }
            .word-table tr th, .word-table tr td{
                border:1px solid black !important; 
                padding: 5px 10px;
            }
        </style>
    </head>
    <body>
        <h2>Nota_pembayaran List</h2>
        <table class="word-table" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>No Pembayaran</th>
		<th>Total Bayar</th>
		<th>Id Pemesanan</th>
		<th>Status Pembayaran</th>
		
            </tr><?php
            foreach ($nota_pembayaran_data as $nota_pembayaran)
            {
                ?>
                <tr>
		      <td><?php echo ++$start ?></td>
		      <td><?php echo $nota_pembayaran->no_pembayaran ?></td>
		      <td><?php echo $nota_pembayaran->total_bayar ?></td>
		      <td><?php echo $nota_pembayaran->id_pemesanan ?></td>
		      <td><?php echo $nota_pembayaran->status_pembayaran ?></td>	
                </tr>
                <?php
            }
            ?>
        </table>
    </body>
</html>
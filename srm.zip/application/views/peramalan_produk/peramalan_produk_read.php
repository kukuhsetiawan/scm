<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Peramalan_produk Read</h2>
        <table class="table">
	    <tr><td>Nama Peramalan</td><td><?php echo $nama_peramalan; ?></td></tr>
	    <tr><td>Tanggal</td><td><?php echo $tanggal; ?></td></tr>
	    <tr><td>Produk</td><td><?php echo $produk; ?></td></tr>
	    <tr><td>Jumlah Produk</td><td><?php echo $jumlah_produk; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('peramalan_produk') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>
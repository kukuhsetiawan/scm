  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script>
  $( function() {
    $( "#datepicker" ).datepicker({
    });
  } );
  </script>
<div id="page-wrapper">
            <div class="main-page">
                <div class="validation-section">
                    <h2></h2>
                    <div class="col-md-6 validation-grid">
                        <h4><span>Peramalan_produk</span> </h4>
                        <div class="validation-grid1">
                            <div class="valid-top">
                                <form id="defaultForm" method="post" class="form-horizontal" action="<?php echo $action; ?>">
                                    <div class="form-group">

	    <div class="form-group">
            <label class="col-lg-3 control-label" for="varchar">Nama Peramalan <?php echo form_error('nama_peramalan') ?></label>
           <div class="col-lg-5"> <input type="text" class="form-control" name="nama_peramalan" id="nama_peramalan" placeholder="Nama Peramalan" value="<?php echo $nama_peramalan; ?>" /></div>
        </div>
	    <div class="form-group">
            <label class="col-lg-3 control-label" for="date">Tanggal <?php echo form_error('tanggal') ?></label>
           <div class="col-lg-5"> <input type="text" class="form-control" name="tanggal" id="datepicker" data-date-format='yyyy-mm-dd' placeholder="Tanggal" value="<?php echo $tanggal; ?>" /></div>
        </div>
	    <div class="form-group">
            <label class="col-lg-3 control-label" for="varchar">Produk <?php echo form_error('produk') ?></label>
           <div class="col-lg-5"> 
                <select name="produk" id="" class="form-control">
                    <option>--Pilih--</option>
                    <?php foreach ($content_produk->result() as $key): ?>
                        <option value="<?php echo $key->nama_produk; ?>"><?php echo $key->nama_produk; ?></option>
                    <?php endforeach ?>
                </select>

                <!-- <input type="text" class="form-control" name="produk" id="produk" placeholder="Produk" value="<?php echo $produk; ?>" /> -->
            </div>
        </div>
	  <input type="hidden" class="form-control" name="jumlah_produk" id="jumlah_produk" placeholder="Jumlah Produk" value="<?php echo rand(10,50); ?>" />
	    <input type="hidden" name="id" value="<?php echo $id; ?>" /> 
	    
                                    <div class="form-group">
                                        <div class="col-lg-9 col-lg-offset-3">
                                            <button type="submit" class="btn btn-primary"><?php echo $button ?></button>
                                       

 
	    
                                    
                                            <a href="<?php echo site_url('peramalan_produk') ?>" class="btn btn-default">Cancel</a>
                                        </div>
                                    </div>

	
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>

   
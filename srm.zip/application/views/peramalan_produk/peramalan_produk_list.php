

<body>
<!-- START BREADCRUMB -->
<ul class="breadcrumb">
  <li><a href="">Home</a></li>                    
  <li class="active">Peramalan_produk</li>
</ul>
<!-- END BREADCRUMB -->
<!-- PAGE TITLE -->
<div class="page-title">                    
  <h2>Peramalan_produk</h2>
</div>
<!-- END PAGE TITLE -->                

<!-- PAGE CONTENT WRAPPER -->
<div class="page-content-wrap">                
  <div class="row">
    <div class="col-md-12">

<!-- START DEFAULT DATATABLE -->
    <div class="panel panel-default">
    <div class="panel-heading">
    <ul class="panel-controls">
       <?php echo anchor(site_url('peramalan_produk/create'),'Tambah', 'class="btn btn-success btn-lg"'); ?>
       
      <!-- <div class="col-md-3 text-right">
                <form action="<?php echo site_url('peramalan_produk/index'); ?>" class="form-inline" method="get">
                    <div class="input-group">
                        <input type="text" class="form-control" name="q" value="<?php echo $q; ?>">
                        <span class="input-group-btn">
                            <?php 
                                if ($q <> '')
                                {
                                    ?>
                                    <a href="<?php echo site_url('peramalan_produk'); ?>" class="btn btn-default">Reset</a>
                                    <?php
                                }
                            ?>
                          <button class="btn btn-primary" type="submit">Search</button>
                        </span>
                    </div>
                </form>
            </div> -->
    </ul>                                
    </div>
    <?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
    <div class="panel-body">

    


       
       <table class="table">
          <thead>
            <tr>
                <th>No</th>
		<th>Nama Peramalan</th>
		<th>Tanggal</th>
		<th>Produk</th>
		<th>Jumlah Produk</th>
        <th>ROP</th>
        <th>Safety Stock</th>
		<th>Action</th>
            </tr></thead><?php
            foreach ($peramalan_produk_data as $peramalan_produk)
            {
                ?>
                <tbody><tr>
			<th width="80px"><h5><?php echo ++$start ?></h5></th>
			<th><h5><?php echo $peramalan_produk->nama_peramalan ?></h5></th>
			<th><h5><?php echo $peramalan_produk->tanggal ?></h5></th>
			<th><h5><?php echo $peramalan_produk->produk ?></h5></th>
			<th><h5><?php echo $peramalan_produk->jumlah_produk ?></h5></th>
            <?php if ($peramalan_produk->jumlah_produk < 13): ?>
                <th>0</th>
                <th>0</th>
            <?php else: ?>
                <th><h5><?php echo ceil($peramalan_produk->jumlah_produk/6) ?></h5></th>
            <th><h5><?php echo ceil($peramalan_produk->jumlah_produk/6-1) ?></h5></th>
            <?php endif ?>
			<th style="text-align:center" width="200px">
				<?php 
				// echo anchor(site_url('peramalan_produk/read/'.$peramalan_produk->id),'<i class="fa fa-eye"></i>',array('title'=>'detail','class'=>'btn btn-default btn-sm')); 
				echo '  '; 
				echo anchor(site_url('peramalan_produk/update/'.$peramalan_produk->id),'<i class="fa fa-pencil-square-o"></i>',array('title'=>'edit','class'=>'btn btn-warning btn-sm')); 
				echo '  '; 
				echo anchor(site_url('peramalan_produk/delete/'.$peramalan_produk->id),'<i class="fa fa-trash-o"></i>','title="delete" class="btn btn-danger btn-sm" onclick="javasciprt: return confirm(\'Are You Sure ?\')"'); 
				?>
			</th>
		</tr>
                <?php
            }
            ?>
        </tbody>

        </table>



    </div>
</div>
<!-- END DEFAULT DATATABLE -->

<div class="row">
            <div class="col-md-6">
                <a href="#" class="btn btn-primary">Total Record : <?php echo $total_rows ?></a>
	    </div>
            <div class="col-md-6 text-right">
                <?php echo $pagination ?>
            </div>
        </div>
</div>
</div>
</div>
<!-- PAGE CONTENT WRAPPER -->                                      

    
    <!-- START SCRIPTS -->
        <!-- START PLUGINS -->
        <script type="text/javascript" src="<?php echo base_url(); ?>temp/js/plugins/jquery/jquery.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>temp/js/plugins/jquery/jquery-ui.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>temp/js/plugins/bootstrap/bootstrap.min.js"></script>        
        <!-- END PLUGINS -->                

        <!-- THIS PAGE PLUGINS -->
        <script type="text/javascript" src="<?php echo base_url(); ?>temp/js/plugins/icheck/icheck.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>temp/js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
        
        <script type="text/javascript" src="<?php echo base_url(); ?>temp/js/plugins/datatables/jquery.dataTables.min.js"></script>    
        <!-- END PAGE PLUGINS -->

        <!-- START TEMPLATE -->
        <script type="text/javascript" src="<?php echo base_url(); ?>temp/js/settings.js"></script>
        
        <script type="text/javascript" src="<?php echo base_url(); ?>temp/js/plugins.js"></script>        
        <script type="text/javascript" src="<?php echo base_url(); ?>temp/js/actions.js"></script>        
        <!-- END TEMPLATE -->
    <!-- END SCRIPTS --> 
        
    </body>

   
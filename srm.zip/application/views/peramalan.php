
        <div id="page-wrapper">
            <div class="main-page">

           
                   

                <div class="grid-section">
                        <h2 class="hdg">Peramalan</h2>
                    <div class="row mb40">
                                <div class="col-md-12 table-grid">
                                <div class="panel panel-widget">
                                    <div class="bs-docs-example">
                                        
<!-- isi content -->
<div class="row" style="margin-bottom: 10px">
            <div class="col-md-4">
                 
            </div>
            <div class="col-md-4 text-center">
                <div style="margin-top: 8px" id="message">
                   
                </div>
            </div>
            <div class="col-md-1 text-right">
            </div>
            <div class="col-md-3 text-right">
               
            </div>
        </div>

        <table class="table table-striped" style="margin-bottom: 10px" >
            <tr >
                <th rowspan="2">Bulan</th>
		<th rowspan="2">Permintaan Per Unit</th>
		<th colspan="9" class="text-center">Nilai Alpha</th> 
        </tr>
        <tr>
            <th>0.1</th>
            <th>0.2</th>
            <th>0.3</th>
            <th>0.4</th>
            <th>0.5</th>
            <th>0.6</th>
            <th>0.7</th>
            <th>0.8</th>
            <th>0.9</th>
        </tr>
        <tr>
            <td>April</td>
            <td>
            <?php foreach ($data1 as $key): ?>
                <?php echo $key->total1; ?>
            <?php endforeach ?>
            </td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td>Mei</td>
            <?php foreach ($data2 as $key): ?>
                <td><?php echo $key->total2; ?></td>
            <?php endforeach ?>
            <td>
            <?php foreach ($data1 as $key): ?>
                <?php echo 0.1*$key->total1+0.9*$key->total1; ?>
            <?php endforeach ?>
            </td>
            <td>
            <?php foreach ($data1 as $key): ?>
                <?php echo 0.2*$key->total1+0.8*$key->total1; ?>
            <?php endforeach ?>
            </td>
            <td>
            <?php foreach ($data1 as $key): ?>
                <?php echo 0.3*$key->total1+0.7*$key->total1; ?>
            <?php endforeach ?>
            </td>
            <td>
            <?php foreach ($data1 as $key): ?>
                <?php echo 0.4*$key->total1+0.6*$key->total1; ?>
            <?php endforeach ?>
            </td>
            <td>
                <?php foreach ($data1 as $key): ?>
                <?php echo 0.5*$key->total1+0.5*$key->total1; ?>
            <?php endforeach ?>
            </td>
            <td><?php foreach ($data1 as $key): ?>
                <?php echo 0.6*$key->total1+0.4*$key->total1; ?>
            <?php endforeach ?></td>
           
            <td><?php foreach ($data1 as $key): ?>
                <?php echo 0.7*$key->total1+0.3*$key->total1; ?>
            <?php endforeach ?>
            </td>
            <td>
            <?php foreach ($data1 as $key): ?>
                <?php echo 0.8*$key->total1+0.2*$key->total1; ?>
            <?php endforeach ?>
            </td>
            <td>
                <?php foreach ($data1 as $key): ?>
                <?php echo 0.9*$key->total1+0.1*$key->total1; ?>
            <?php endforeach ?>
            </td>
        </tr>
        <tr>
            <td>Juni</td>
            <?php foreach ($data3 as $key): ?>
                <td><?php echo $key->total3; ?></td>
            <?php endforeach ?>
            <td>
                <?php foreach ($alpha21 as $key): ?>
                    <?php echo $key->alpha21_hasil; ?>
                <?php endforeach ?>
            </td>
            <td>
                <?php foreach ($alpha22 as $key): ?>
                    <?php echo $key->alpha22_hasil; ?>
                <?php endforeach ?>
            </td>
            <td>
                <?php foreach ($alpha23 as $key): ?>
                    <?php echo $key->alpha23_hasil; ?>
                <?php endforeach ?>
            </td>
            <td>
                <?php foreach ($alpha24 as $key): ?>
                    <?php echo $key->alpha24_hasil; ?>
                <?php endforeach ?>
            </td>
            <td>
                <?php foreach ($alpha25 as $key): ?>
                    <?php echo $key->alpha25_hasil; ?>
                <?php endforeach ?>
            </td>
            <td>
                <?php foreach ($alpha26 as $key): ?>
                    <?php echo $key->alpha26_hasil; ?>
                <?php endforeach ?>
            </td>
            <td>
                <?php foreach ($alpha27 as $key): ?>
                    <?php echo $key->alpha27_hasil; ?>
                <?php endforeach ?>
            </td>
            <td>
                <?php foreach ($alpha28 as $key): ?>
                    <?php echo $key->alpha28_hasil; ?>
                <?php endforeach ?>
            </td>
            <td>
                <?php foreach ($alpha29 as $key): ?>
                    <?php echo $key->alpha29_hasil; ?>
                <?php endforeach ?>
            </td>
        </tr>

        <tr>
            <td>Hasil Peramalan (Juli)</td>
            <td>
                
            </td>
            <td>
                <?php foreach ($alpha31 as $key): ?>
                    <?php echo $key->alpha31_hasil; ?>
                <?php endforeach ?>
            </td>
            <td>
                <?php foreach ($alpha32 as $key): ?>
                    <?php echo $key->alpha32_hasil; ?>
                <?php endforeach ?>
            </td>
            <td>
                <?php foreach ($alpha33 as $key): ?>
                    <?php echo $key->alpha33_hasil; ?>
                <?php endforeach ?>
            </td>
            <td>
                <?php foreach ($alpha34 as $key): ?>
                    <?php echo $key->alpha34_hasil; ?>
                <?php endforeach ?>
            </td>
            <td>
                <?php foreach ($alpha35 as $key): ?>
                    <?php echo $key->alpha35_hasil; ?>
                <?php endforeach ?>
            </td>
            <td>
                <?php foreach ($alpha36 as $key): ?>
                    <?php echo $key->alpha36_hasil; ?>
                <?php endforeach ?>
            </td>
            <td>
                <?php foreach ($alpha37 as $key): ?>
                    <?php echo $key->alpha37_hasil; ?>
                <?php endforeach ?>
            </td>
            <td>
                <?php foreach ($alpha38 as $key): ?>
                    <?php echo $key->alpha38_hasil; ?>
                <?php endforeach ?>
            </td>
            <td>
                <?php foreach ($alpha39 as $key): ?>
                    <?php echo $key->alpha39_hasil; ?>
                <?php endforeach ?>
            </td>
        </tr>


		
            
               
            
        </table>
      <br><br>

      

        


                                    </div>
                                </div>
                            </div>

                </div>
                </div>
                </div>

                </div>
                <div class="clearfix"> </div>
            </div>
            </div>
            </div>



   

        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Biaya_pesan <?php echo $button ?></h2>
         <div class="box-body">
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">Id Supplier <?php echo form_error('id_supplier') ?></label>
            <input type="text" class="form-control" name="id_supplier" id="id_supplier" placeholder="Id Supplier" value="<?php echo $id_supplier; ?>" />
        </div>
	    <div class="form-group">
            <label for="enum">Jenis Biaya <?php echo form_error('jenis_biaya') ?></label>
            <input type="text" class="form-control" name="jenis_biaya" id="jenis_biaya" placeholder="Jenis Biaya" value="<?php echo $jenis_biaya; ?>" />
        </div>
	    <div class="form-group">
            <label for="double">Jumlah <?php echo form_error('jumlah') ?></label>
            <input type="text" class="form-control" name="jumlah" id="jumlah" placeholder="Jumlah" value="<?php echo $jumlah; ?>" />
        </div>
	    <input type="hidden" name="id" value="<?php echo $id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('biaya_pesan') ?>" class="btn btn-default">Cancel</a>
	</form>
    </div>

        </div>
    </section>
    </div>
    </section>    
    
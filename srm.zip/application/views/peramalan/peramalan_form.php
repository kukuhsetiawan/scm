
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Peramalan <?php echo $button ?></h2>
         <div class="box-body">
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">Id Produk <?php echo form_error('id_produk') ?></label>
            <input type="text" class="form-control" name="id_produk" id="id_produk" placeholder="Id Produk" value="<?php echo $id_produk; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Periode <?php echo form_error('periode') ?></label>
            <input type="text" class="form-control" name="periode" id="periode" placeholder="Periode" value="<?php echo $periode; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Id User <?php echo form_error('id_user') ?></label>
            <input type="text" class="form-control" name="id_user" id="id_user" placeholder="Id User" value="<?php echo $id_user; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Permintaan <?php echo form_error('permintaan') ?></label>
            <input type="text" class="form-control" name="permintaan" id="permintaan" placeholder="Permintaan" value="<?php echo $permintaan; ?>" />
        </div>
	    <div class="form-group">
            <label for="double">Nilai Alpha <?php echo form_error('nilai_alpha') ?></label>
            <input type="text" class="form-control" name="nilai_alpha" id="nilai_alpha" placeholder="Nilai Alpha" value="<?php echo $nilai_alpha; ?>" />
        </div>
	    <div class="form-group">
            <label for="double">Hasil Peramalan <?php echo form_error('hasil_peramalan') ?></label>
            <input type="text" class="form-control" name="hasil_peramalan" id="hasil_peramalan" placeholder="Hasil Peramalan" value="<?php echo $hasil_peramalan; ?>" />
        </div>
	    <input type="hidden" name="no" value="<?php echo $no; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('peramalan') ?>" class="btn btn-default">Cancel</a>
	</form>
    </div>

        </div>
    </section>
    </div>
    </section>    
    
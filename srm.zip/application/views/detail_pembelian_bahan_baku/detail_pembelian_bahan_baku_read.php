
        
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Detail_pembelian_bahan_baku Read</h2>
        <div class="box-body">
        <table class="table">
	    <tr><td>Id Pengadaan</td><td><?php echo $id_pengadaan; ?></td></tr>
	    <tr><td>Id Bahan Baku</td><td><?php echo $id_bahan_baku; ?></td></tr>
	    <tr><td>Jumlah Kebutuhan</td><td><?php echo $jumlah_kebutuhan; ?></td></tr>
	    <tr><td>Harga</td><td><?php echo $harga; ?></td></tr>
	    <tr><td>Status Bahan Baku</td><td><?php echo $status_bahan_baku; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('detail_pembelian_bahan_baku') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </div>

        </div>
    </section>
    </div>
    </section>    
    
        
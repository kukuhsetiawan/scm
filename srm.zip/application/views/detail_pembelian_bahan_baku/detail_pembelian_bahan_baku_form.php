
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Detail_pembelian_bahan_baku <?php echo $button ?></h2>
         <div class="box-body">
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="int">Id Pengadaan <?php echo form_error('id_pengadaan') ?></label>
            <input type="text" class="form-control" name="id_pengadaan" id="id_pengadaan" placeholder="Id Pengadaan" value="<?php echo $id_pengadaan; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Id Bahan Baku <?php echo form_error('id_bahan_baku') ?></label>
            <input type="text" class="form-control" name="id_bahan_baku" id="id_bahan_baku" placeholder="Id Bahan Baku" value="<?php echo $id_bahan_baku; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Jumlah Kebutuhan <?php echo form_error('jumlah_kebutuhan') ?></label>
            <input type="text" class="form-control" name="jumlah_kebutuhan" id="jumlah_kebutuhan" placeholder="Jumlah Kebutuhan" value="<?php echo $jumlah_kebutuhan; ?>" />
        </div>
	    <div class="form-group">
            <label for="double">Harga <?php echo form_error('harga') ?></label>
            <input type="text" class="form-control" name="harga" id="harga" placeholder="Harga" value="<?php echo $harga; ?>" />
        </div>
	    <div class="form-group">
            <label for="enum">Status Bahan Baku <?php echo form_error('status_bahan_baku') ?></label>
            <input type="text" class="form-control" name="status_bahan_baku" id="status_bahan_baku" placeholder="Status Bahan Baku" value="<?php echo $status_bahan_baku; ?>" />
        </div>
	    <input type="hidden" name="id_detail_bahan_baku" value="<?php echo $id_detail_bahan_baku; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('detail_pembelian_bahan_baku') ?>" class="btn btn-default">Cancel</a>
	</form>
    </div>

        </div>
    </section>
    </div>
    </section>    
    

        
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Produk List</h2>
        <div class="row" style="margin-bottom: 10px">
            <div class="col-md-6">
                <?php if ($this->session->userdata('role') == 'Pemilik'): ?>
                    
                <?php else: ?>
                    <?php echo anchor(site_url('produk/create'),'Create', 'class="btn btn-primary"'); ?>
                <?php endif ?>
            </div>
            <div class="col-md-6 text-center">
                <div style="margin-top: 8px" id="message">
                    <?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
                </div>
            </div>
        </div>
        <div class="box-body">
        <table class="table table-bordered table-striped" id="example1">
            <thead>
            <tr>
                <th>No</th>
		<th>Kode Produk</th>
		<th>Nama Produk</th>
		<th>Id Kategori</th>
		<th>Satuan Produk</th>
		<th>Harga Pack</th>
		<th>Action</th>
                            </tr>
                            </thead>
                            <tbody><?php
                            $start = 0;
                            foreach ($produk_data as $produk)
                            {
                                 ?>
            
            <tr>
            
			<td width="80px"><?php echo ++$start ?></td>
			<td><?php echo $produk->kode_produk ?></td>
			<td><?php echo $produk->nama_produk ?></td>
			<td><?php echo $produk->id_kategori ?></td>
			<td><?php echo $produk->satuan_produk ?></td>
			<td><?php echo $produk->harga_pack ?></td>
			<td style="text-align:center" width="200px">
				<?php 
				echo anchor(site_url('produk/read/'.$produk->id),'<i class="fa fa-eye"></i>',array('title'=>'detail','class'=>'btn btn-default btn-sm')); 
				echo '  '; 
				echo anchor(site_url('produk/update/'.$produk->id),'<i class="fa fa-pencil-square-o"></i>',array('title'=>'edit','class'=>'btn btn-warning btn-sm')); 
				echo '  '; 
				echo anchor(site_url('produk/delete/'.$produk->id),'<i class="fa fa-trash-o"></i>','title="delete" class="btn btn-danger btn-sm" onclick="javasciprt: return confirm(\'Are You Sure ?\')"'); 
				?>
			</td>
		</tr> 
                <?php
            }
            ?>
        </tbody>
        </table>
        </div>
        <div class="row">
            <div class="col-md-6">
                
		<?php echo anchor(site_url('produk/excel'), 'Excel', 'class="btn btn-primary"'); ?>
		<?php echo anchor(site_url('produk/word'), 'Word', 'class="btn btn-primary"'); ?>
	 
    </div>
    </section>
    </div>
    </section>    
    
   
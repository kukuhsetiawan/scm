
        
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Bom Read</h2>
        <div class="box-body">
        <table class="table">
	    <tr><td>Id Produk</td><td><?php echo $id_produk; ?></td></tr>
	    <tr><td>Id Bahan Baku</td><td><?php echo $id_bahan_baku; ?></td></tr>
	    <tr><td>Jumlah Kebutuhan</td><td><?php echo $jumlah_kebutuhan; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('bom') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </div>

        </div>
    </section>
    </div>
    </section>    
    
        
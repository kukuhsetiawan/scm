
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Bom <?php echo $button ?></h2>
         <div class="box-body">
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="int">Produk <?php echo form_error('id_produk') ?></label>
            <select name="id_produk" id="" class="form-control">
                <option>-Pilih Produk-</option>
                <?php foreach ($content_produk as $key): ?>
                    <option value="<?php echo $key->id ?>"><?php echo $key->nama_produk ?></option>
                <?php endforeach ?>
            </select>
            <!-- <input type="text" class="form-control" name="id_produk" id="id_produk" placeholder="Id Produk" value="<?php echo $id_produk; ?>" /> -->
        </div>
	    <div class="form-group">
            <label for="varchar">Bahan Baku <?php echo form_error('id_bahan_baku') ?></label>
            <select name="id_bahan_baku" id="" class="form-control">
                <option>-Pilih Bahan Baku-</option>
                <?php foreach ($content_bahan_baku as $key): ?>
                    <option value="<?php echo $key->id ?>"><?php echo $key->nama_bahan_baku ?></option>
                <?php endforeach ?>
            </select>
            <!-- <input type="text" class="form-control" name="id_bahan_baku" id="id_bahan_baku" placeholder="Id Bahan Baku" value="<?php echo $id_bahan_baku; ?>" /> -->
        </div>
	    <div class="form-group">
            <label for="int">Jumlah Kebutuhan <?php echo form_error('jumlah_kebutuhan') ?></label>
            <input type="text" class="form-control" name="jumlah_kebutuhan" id="jumlah_kebutuhan" placeholder="Jumlah Kebutuhan" value="<?php echo $jumlah_kebutuhan; ?>" />
        </div>
	    <input type="hidden" name="id_bom" value="<?php echo $id_bom; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('bom') ?>" class="btn btn-default">Cancel</a>
	</form>
    </div>

        </div>
    </section>
    </div>
    </section>    
    
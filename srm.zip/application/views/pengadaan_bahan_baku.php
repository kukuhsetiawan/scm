<body onload="window.print()">
<img src="<?php echo base_url(); ?>logo.jpg" alt="" width="150"><br><br>
<?php foreach ($supplier as $key): ?>
    Nomor Nota : N<?php echo date("Ymd"); ?> <br>
    Nama Supplier : <?php echo $key->nama_supplier; ?><br>
    Telp :  <?php echo $key->telp_supp; ?><br>
    Alamat Supplier :  <?php echo $key->alamat_supplier; ?><br> <br>
    
<?php endforeach ?>
        <table class="table table-striped" style="margin-bottom: 10px" border="1">
            <tr>
		<th>Id Bahan Baku</th>
		<th>Id Supplier</th>
		<th>Jumlah</th>
            </tr><?php
            foreach ($pengadaan_data as $pengadaan)
            {
                ?>
                <tr>
			<td><?php echo $pengadaan->id_bahan_baku ?></td>
			<td><?php echo $pengadaan->id_supplier ?></td>
			<td><?php echo $pengadaan->jumlah_rencana_pemberlian ?></td>
		
		</tr>
                <?php
            }
            ?>
        </table> <br> <br>
        <?php echo date("Y-m-d"); ?> <br>
        Tanda Terima, <br><br>
        <br><br>

        

   
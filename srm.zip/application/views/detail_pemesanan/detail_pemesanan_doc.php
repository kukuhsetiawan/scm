<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            .word-table {
                border:1px solid black !important; 
                border-collapse: collapse !important;
                width: 100%;
            }
            .word-table tr th, .word-table tr td{
                border:1px solid black !important; 
                padding: 5px 10px;
            }
        </style>
    </head>
    <body>
        <h2>Detail_pemesanan List</h2>
        <table class="word-table" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>Id Pemesanan</th>
		<th>Id Produk</th>
		<th>Harga Produk</th>
		<th>Jumlah Beli</th>
		<th>Satuan Produk</th>
		
            </tr><?php
            foreach ($detail_pemesanan_data as $detail_pemesanan)
            {
                ?>
                <tr>
		      <td><?php echo ++$start ?></td>
		      <td><?php echo $detail_pemesanan->id_pemesanan ?></td>
		      <td><?php echo $detail_pemesanan->id_produk ?></td>
		      <td><?php echo $detail_pemesanan->harga_produk ?></td>
		      <td><?php echo $detail_pemesanan->jumlah_beli ?></td>
		      <td><?php echo $detail_pemesanan->satuan_produk ?></td>	
                </tr>
                <?php
            }
            ?>
        </table>
    </body>
</html>

        
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Detail_pemesanan Read</h2>
        <div class="box-body">
        <table class="table">
	    <tr><td>Id Pemesanan</td><td><?php echo $id_pemesanan; ?></td></tr>
	    <tr><td>Id Produk</td><td><?php echo $id_produk; ?></td></tr>
	    <tr><td>Harga Produk</td><td><?php echo $harga_produk; ?></td></tr>
	    <tr><td>Jumlah Beli</td><td><?php echo $jumlah_beli; ?></td></tr>
	    <tr><td>Satuan Produk</td><td><?php echo $satuan_produk; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('detail_pemesanan') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </div>

        </div>
    </section>
    </div>
    </section>    
    
        
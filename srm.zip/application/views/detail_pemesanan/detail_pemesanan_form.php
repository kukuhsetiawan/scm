
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Detail_pemesanan <?php echo $button ?></h2>
         <div class="box-body">
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="int">Id Pemesanan <?php echo form_error('id_pemesanan') ?></label>
            <input type="text" class="form-control" name="id_pemesanan" id="id_pemesanan" placeholder="Id Pemesanan" value="<?php echo $id_pemesanan; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Id Produk <?php echo form_error('id_produk') ?></label>
            <input type="text" class="form-control" name="id_produk" id="id_produk" placeholder="Id Produk" value="<?php echo $id_produk; ?>" />
        </div>
	    <div class="form-group">
            <label for="double">Harga Produk <?php echo form_error('harga_produk') ?></label>
            <input type="text" class="form-control" name="harga_produk" id="harga_produk" placeholder="Harga Produk" value="<?php echo $harga_produk; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Jumlah Beli <?php echo form_error('jumlah_beli') ?></label>
            <input type="text" class="form-control" name="jumlah_beli" id="jumlah_beli" placeholder="Jumlah Beli" value="<?php echo $jumlah_beli; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Satuan Produk <?php echo form_error('satuan_produk') ?></label>
            <input type="text" class="form-control" name="satuan_produk" id="satuan_produk" placeholder="Satuan Produk" value="<?php echo $satuan_produk; ?>" />
        </div>
	    <input type="hidden" name="no_pemesanan" value="<?php echo $no_pemesanan; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('detail_pemesanan') ?>" class="btn btn-default">Cancel</a>
	</form>
    </div>

        </div>
    </section>
    </div>
    </section>    
    
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script>
  $( function() {
    $( "#datepicker" ).datepicker({
        dateFormat: 'yy-mm-dd'
    });
  } );
</script>

<div id="page-wrapper">
            <div class="main-page">
                <div class="validation-section">
                    <h2></h2>
                    <div class="col-md-6 validation-grid">
                        <h4><span>Pengadaan</span> </h4>
                        <div class="validation-grid1">
                            <div class="valid-top">
                                <form id="defaultForm" method="post" class="form-horizontal" action="<?php echo $action; ?>">
                                    <div class="form-group">

	    <div class="form-group">
            <label class="col-lg-3 control-label" for="int">Bahan Baku <?php echo form_error('id_bahan_baku') ?></label>
           <div class="col-lg-5"> 
                <select name="id_bahan_baku" id="" class="form-control">
                    <option>--Pilih--</option>
                    <?php foreach ($bahan_baku->result() as $key): ?>
                        <option value="<?php echo $key->id_bahan_baku; ?>"><?php echo $key->nama_bahan_baku; ?></option>
                    <?php endforeach ?>
                </select>

                <!-- <input type="text" class="form-control" name="id_bahan_baku" id="id_bahan_baku" placeholder="Id Bahan Baku" value="<?php echo $id_bahan_baku; ?>" /> -->
            </div>
        </div>
	    <div class="form-group">
            <label class="col-lg-3 control-label" for="int">Supplier <?php echo form_error('id_supplier') ?></label>
           <div class="col-lg-5"> 
                <select name="id_supplier" id="" class="form-control">
                    <option>--Pilih--</option>
                    <?php foreach ($supplier->result() as $key): ?>
                        <option value="<?php echo $key->id_supplier; ?>"><?php echo $key->nama_supplier; ?></option>
                    <?php endforeach ?>
                </select>
                <!-- <input type="text" class="form-control" name="id_supplier" id="id_supplier" placeholder="Id Supplier" value="<?php echo $id_supplier; ?>" /> -->
            </div>
        </div>
	    <div class="form-group">
            <label class="col-lg-3 control-label" for="int">Jumlah Rencana Pembelian <?php echo form_error('jumlah_rencana_pemberlian') ?></label>
           <div class="col-lg-5"> <input type="text" class="form-control" name="jumlah_rencana_pemberlian" id="jumlah_rencana_pemberlian" placeholder="Jumlah Rencana Pemberlian" value="<?php echo $jumlah_rencana_pemberlian; ?>" /></div>
        </div>
	    <div class="form-group">
            <label class="col-lg-3 control-label" for="date">Tanggal Pembelian <?php echo form_error('tanggal_pembelian') ?></label>
           <div class="col-lg-5"> <input type="text" class="form-control" name="tanggal_pembelian" id="datepicker" data-date-format='yyyy-mm-dd' placeholder="yyyy-mm-dd" value="<?php echo $tanggal_pembelian; ?>" /></div>
        </div>
	    <input type="hidden" name="id" value="<?php echo $id; ?>" /> 
	    
                                    <div class="form-group">
                                        <div class="col-lg-9 col-lg-offset-3">
                                            <button type="submit" class="btn btn-primary"><?php echo $button ?></button>
                                       

 
	    
                                    
                                            <a href="<?php echo site_url('pengadaan') ?>" class="btn btn-default">Cancel</a>
                                        </div>
                                    </div>

	
</div>
</form>
<br>
<br>
<br>
<br>
</div>
</div>
</div>
</div>

   </div>
</div>

<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
$( function() {
$( "#datepicker" ).datepicker({
});
} );
</script>
<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            .word-table {
                border:1px solid black !important; 
                border-collapse: collapse !important;
                width: 100%;
            }
            .word-table tr th, .word-table tr td{
                border:1px solid black !important; 
                padding: 5px 10px;
            }
        </style>
    </head>
    <body>
        <h2>Pemesanan_produk List</h2>
        <table class="word-table" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>Id Retail</th>
		<th>Id Produk</th>
		<th>Id User</th>
		<th>Tgl Pemesanan</th>
		<th>Bayar Dp</th>
		<th>Status Pemesanan</th>
		<th>Total Bayar</th>
		<th>Suffix</th>
		
            </tr><?php
            foreach ($pemesanan_produk_data as $pemesanan_produk)
            {
                ?>
                <tr>
		      <td><?php echo ++$start ?></td>
		      <td><?php echo $pemesanan_produk->id_retail ?></td>
		      <td><?php echo $pemesanan_produk->id_produk ?></td>
		      <td><?php echo $pemesanan_produk->id_user ?></td>
		      <td><?php echo $pemesanan_produk->tgl_pemesanan ?></td>
		      <td><?php echo $pemesanan_produk->bayar_dp ?></td>
		      <td><?php echo $pemesanan_produk->status_pemesanan ?></td>
		      <td><?php echo $pemesanan_produk->total_bayar ?></td>
		      <td><?php echo $pemesanan_produk->suffix ?></td>	
                </tr>
                <?php
            }
            ?>
        </table>
    </body>
</html>

        
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Pemesanan_produk Read</h2>
        <div class="box-body">
        <table class="table">
	    <tr><td>Id Retail</td><td><?php echo $id_retail; ?></td></tr>
	    <tr><td>Id Produk</td><td><?php echo $id_produk; ?></td></tr>
	    <tr><td>Id User</td><td><?php echo $id_user; ?></td></tr>
	    <tr><td>Tgl Pemesanan</td><td><?php echo $tgl_pemesanan; ?></td></tr>
	    <tr><td>Bayar Dp</td><td><?php echo $bayar_dp; ?></td></tr>
	    <tr><td>Status Pemesanan</td><td><?php echo $status_pemesanan; ?></td></tr>
	    <tr><td>Total Bayar</td><td><?php echo $total_bayar; ?></td></tr>
	    <tr><td>Suffix</td><td><?php echo $suffix; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('pemesanan_produk') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </div>

        </div>
    </section>
    </div>
    </section>    
    
        
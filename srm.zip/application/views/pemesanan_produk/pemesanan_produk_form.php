
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Pemesanan_produk <?php echo $button ?></h2>
         <div class="box-body">
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">Id Retail <?php echo form_error('id_retail') ?></label>
            <input type="text" class="form-control" name="id_retail" id="id_retail" placeholder="Id Retail" value="<?php echo $id_retail; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Id Produk <?php echo form_error('id_produk') ?></label>
            <input type="text" class="form-control" name="id_produk" id="id_produk" placeholder="Id Produk" value="<?php echo $id_produk; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Id User <?php echo form_error('id_user') ?></label>
            <input type="text" class="form-control" name="id_user" id="id_user" placeholder="Id User" value="<?php echo $id_user; ?>" />
        </div>
	    <div class="form-group">
            <label for="datetime">Tgl Pemesanan <?php echo form_error('tgl_pemesanan') ?></label>
            <input type="text" class="form-control" name="tgl_pemesanan" id="tgl_pemesanan" placeholder="Tgl Pemesanan" value="<?php echo $tgl_pemesanan; ?>" />
        </div>
	    <div class="form-group">
            <label for="double">Bayar Dp <?php echo form_error('bayar_dp') ?></label>
            <input type="text" class="form-control" name="bayar_dp" id="bayar_dp" placeholder="Bayar Dp" value="<?php echo $bayar_dp; ?>" />
        </div>
	    <div class="form-group">
            <label for="enum">Status Pemesanan <?php echo form_error('status_pemesanan') ?></label>
            <input type="text" class="form-control" name="status_pemesanan" id="status_pemesanan" placeholder="Status Pemesanan" value="<?php echo $status_pemesanan; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Total Bayar <?php echo form_error('total_bayar') ?></label>
            <input type="text" class="form-control" name="total_bayar" id="total_bayar" placeholder="Total Bayar" value="<?php echo $total_bayar; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Suffix <?php echo form_error('suffix') ?></label>
            <input type="text" class="form-control" name="suffix" id="suffix" placeholder="Suffix" value="<?php echo $suffix; ?>" />
        </div>
	    <input type="hidden" name="id_pemesanan" value="<?php echo $id_pemesanan; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('pemesanan_produk') ?>" class="btn btn-default">Cancel</a>
	</form>
    </div>

        </div>
    </section>
    </div>
    </section>    
    
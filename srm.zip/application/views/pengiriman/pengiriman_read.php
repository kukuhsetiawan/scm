
        
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Pengiriman Read</h2>
        <div class="box-body">
        <table class="table">
	    <tr><td>Id Pemesanan</td><td><?php echo $id_pemesanan; ?></td></tr>
	    <tr><td>Tgl Pengiriman</td><td><?php echo $tgl_pengiriman; ?></td></tr>
	    <tr><td>Kendaraan</td><td><?php echo $kendaraan; ?></td></tr>
	    <tr><td>Status Pengiriman</td><td><?php echo $status_pengiriman; ?></td></tr>
	    <tr><td>Supir</td><td><?php echo $supir; ?></td></tr>
	    <tr><td>Alamat</td><td><?php echo $alamat; ?></td></tr>
	    <tr><td>Jarak</td><td><?php echo $jarak; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('pengiriman') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </div>

        </div>
    </section>
    </div>
    </section>    
    
        

        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Pengiriman <?php echo $button ?></h2>
         <div class="box-body">
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="int">Id Pemesanan <?php echo form_error('id_pemesanan') ?></label>
            <select name="id_pemesanan" id="" class="form-control">
                <option>-Pilih Pemesanan-</option>
                <?php foreach ($pemesanan as $key): ?>
                    <option value="<?php echo $key->id_pemesanan ?>"><?php echo $key->id_pemesanan ?> - <?php echo $key->nama_produk ?></option>
                <?php endforeach ?>
            </select>
            <!-- <input type="text" class="form-control" name="id_pemesanan" id="id_pemesanan" placeholder="Id Pemesanan" value="<?php echo $id_pemesanan; ?>" /> -->
        </div>
	    <div class="form-group">
            <!-- <label for="date">Tgl Pengiriman <?php echo form_error('tgl_pengiriman') ?></label> -->
            <input type="hidden" class="form-control" name="tgl_pengiriman" id="tgl_pengiriman" placeholder="Tgl Pengiriman" value="<?php echo date('Y-m-d'); ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Kendaraan <?php echo form_error('kendaraan') ?></label>
            <select name="kendaraan" id="" class="form-control">
                <option>-Pilih Kendaraan-</option>
                <?php foreach ($kendaraan as $key): ?>
                    <option value="<?php echo $key->jenis_kendaraan ?>"><?php echo $key->jenis_kendaraan ?> - <?php echo $key->no_polisi ?></option>
                <?php endforeach ?>
            </select>
            <!-- <input type="text" class="form-control" name="kendaraan" id="kendaraan" placeholder="Kendaraan" value="<?php echo $kendaraan; ?>" /> -->
        </div>
	    <div class="form-group">
            <!-- <label for="varchar">Status Pengiriman <?php echo form_error('status_pengiriman') ?></label> -->
          
            <input type="hidden" class="form-control" name="status_pengiriman" id="status_pengiriman" placeholder="Status Pengiriman" value="Dikirim" />
        </div>
	    <div class="form-group">
            <!-- <label for="int">Supir <?php echo form_error('supir') ?></label> -->
            <input type="hidden" class="form-control" name="supir" id="supir" placeholder="Supir" value="Opik" />
        </div>
	    <div class="form-group">
            <label for="alamat">Alamat <?php echo form_error('alamat') ?></label>
            <textarea class="form-control" rows="3" name="alamat" id="alamat" placeholder="Alamat"><?php echo $alamat; ?></textarea>
        </div>
	    <div class="form-group">
            <label for="varchar">Jarak <?php echo form_error('jarak') ?></label>
            <input type="text" class="form-control" name="jarak" id="jarak" placeholder="Jarak" value="<?php echo $jarak; ?>" />
        </div>
	    <input type="hidden" name="id" value="<?php echo $id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('pengiriman') ?>" class="btn btn-default">Cancel</a>
	</form>
    </div>

        </div>
    </section>
    </div>
    </section>    
    
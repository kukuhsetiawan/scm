
<div id="page-wrapper">
            <div class="main-page">
                <div class="validation-section">
                    <h2></h2>
                    <div class="col-md-6 validation-grid">
                        <h4><span>Peramalan</span> </h4>
                        <div class="validation-grid1">
                            <div class="valid-top">
                                <form id="defaultForm" method="get" class="form-horizontal" action="<?=base_url().'peramalan/pilih_peramalan'; ?>">
                                    <div class="form-group">

        
        <div class="form-group">
            <label class="col-lg-3 control-label" for="double">Nama Produk </label>
           <div class="col-lg-5"> 
                <select name="cari" class="form-control">
                    <option>--Pilih Produk--</option>
                   <?php foreach ($content_produk as $key): ?>
                        <option value="<?php echo $key->id; ?>"><?php echo $key->nama_produk; ?></option>
                   <?php endforeach ?>
                </select>
                
           </div>
        </div>

       

        
                                    <div class="form-group">
                                        <div class="col-lg-9 col-lg-offset-3">
                                            <button type="submit" class="btn btn-primary">Peramalan</button>
                                       


    
</div>
</form>
</div>
</div>
</div>
</div>
</div>


   
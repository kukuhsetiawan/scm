
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Bahan_baku_tidakstok <?php echo $button ?></h2>
         <div class="box-body">
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">Id Bahan Baku Tidakstok <?php echo form_error('id_bahan_baku_tidakstok') ?></label>
            <input type="text" class="form-control" name="id_bahan_baku_tidakstok" id="id_bahan_baku_tidakstok" placeholder="Id Bahan Baku Tidakstok" value="<?php echo $id_bahan_baku_tidakstok; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Nama Bahan Baku <?php echo form_error('nama_bahan_baku') ?></label>
            <input type="text" class="form-control" name="nama_bahan_baku" id="nama_bahan_baku" placeholder="Nama Bahan Baku" value="<?php echo $nama_bahan_baku; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Id Supplier <?php echo form_error('id_supplier') ?></label>
            <input type="text" class="form-control" name="id_supplier" id="id_supplier" placeholder="Id Supplier" value="<?php echo $id_supplier; ?>" />
        </div>
	    <div class="form-group">
            <label for="double">Harga Bahan Baku <?php echo form_error('harga_bahan_baku') ?></label>
            <input type="text" class="form-control" name="harga_bahan_baku" id="harga_bahan_baku" placeholder="Harga Bahan Baku" value="<?php echo $harga_bahan_baku; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Satuan <?php echo form_error('satuan') ?></label>
            <input type="text" class="form-control" name="satuan" id="satuan" placeholder="Satuan" value="<?php echo $satuan; ?>" />
        </div>
	    <div class="form-group">
            <label for="keterangan">Keterangan <?php echo form_error('keterangan') ?></label>
            <textarea class="form-control" rows="3" name="keterangan" id="keterangan" placeholder="Keterangan"><?php echo $keterangan; ?></textarea>
        </div>
	    <input type="hidden" name="id" value="<?php echo $id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('bahan_baku_tidakstok') ?>" class="btn btn-default">Cancel</a>
	</form>
    </div>

        </div>
    </section>
    </div>
    </section>    
    
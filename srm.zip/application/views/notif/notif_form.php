
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Notif <?php echo $button ?></h2>
         <div class="box-body">
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">User <?php echo form_error('user') ?></label>
            <input type="text" class="form-control" name="user" id="user" placeholder="User" value="<?php echo $user; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Dari <?php echo form_error('dari') ?></label>
            <input type="text" class="form-control" name="dari" id="dari" placeholder="Dari" value="<?php echo $dari; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Ke <?php echo form_error('ke') ?></label>
            <input type="text" class="form-control" name="ke" id="ke" placeholder="Ke" value="<?php echo $ke; ?>" />
        </div>
	    <div class="form-group">
            <label for="timestamp">Tanggal <?php echo form_error('tanggal') ?></label>
            <input type="text" class="form-control" name="tanggal" id="tanggal" placeholder="Tanggal" value="<?php echo $tanggal; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Tipe <?php echo form_error('tipe') ?></label>
            <input type="text" class="form-control" name="tipe" id="tipe" placeholder="Tipe" value="<?php echo $tipe; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Template <?php echo form_error('template') ?></label>
            <input type="text" class="form-control" name="template" id="template" placeholder="Template" value="<?php echo $template; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Id  <?php echo form_error('id_') ?></label>
            <input type="text" class="form-control" name="id_" id="id_" placeholder="Id " value="<?php echo $id_; ?>" />
        </div>
	    <div class="form-group">
            <label for="link">Link <?php echo form_error('link') ?></label>
            <textarea class="form-control" rows="3" name="link" id="link" placeholder="Link"><?php echo $link; ?></textarea>
        </div>
	    <input type="hidden" name="id" value="<?php echo $id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('notif') ?>" class="btn btn-default">Cancel</a>
	</form>
    </div>

        </div>
    </section>
    </div>
    </section>    
    
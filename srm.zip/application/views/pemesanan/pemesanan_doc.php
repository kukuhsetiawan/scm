<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            .word-table {
                border:1px solid black !important; 
                border-collapse: collapse !important;
                width: 100%;
            }
            .word-table tr th, .word-table tr td{
                border:1px solid black !important; 
                padding: 5px 10px;
            }
        </style>
    </head>
    <body>
        <h2>Pemesanan List</h2>
        <table class="word-table" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>Kode Pemesanan</th>
		<th>Tgl Pemesanan</th>
		<th>Id Pelanggan</th>
		<th>Id User</th>
		<th>Bayar Dp</th>
		<th>Total Bayar</th>
		<th>Status Pemesanan</th>
		
            </tr><?php
            foreach ($pemesanan_data as $pemesanan)
            {
                ?>
                <tr>
		      <td><?php echo ++$start ?></td>
		      <td><?php echo $pemesanan->kode_pemesanan ?></td>
		      <td><?php echo $pemesanan->tgl_pemesanan ?></td>
		      <td><?php echo $pemesanan->id_pelanggan ?></td>
		      <td><?php echo $pemesanan->id_user ?></td>
		      <td><?php echo $pemesanan->bayar_dp ?></td>
		      <td><?php echo $pemesanan->total_bayar ?></td>
		      <td><?php echo $pemesanan->status_pemesanan ?></td>	
                </tr>
                <?php
            }
            ?>
        </table>
    </body>
</html>

<div id="page-wrapper">
            <div class="main-page">
                <div class="validation-section">
                    <h2>Pemesanan</h2>
<form id="defaultForm" method="post" class="form-horizontal" action="<?=base_url() ?>pemesanan/create">
                  

                    <div class="col-md-4 validation-grid">
                        
                        <div class="validation-grid1">
                            <div class="valid-top">
                                


                                    
                                           
                                  	    <div class="form-group">
                                              <label class="col-lg-3 control-label" for="double">Jumlah Transaksi </label>
                                             <div class="col-lg-5"> 
                                                
                                                  <input type="text" placeholder="Jumlah Produk Yang dipesan" name="transaksi" class="form-control">
                                             </div>
                                          </div>

                                        
	                                               <div class="form-group">
                                        <div class="col-lg-9 col-lg-offset-3">
                                            <button type="submit" class="btn btn-primary">Transaksi</button>
                                       
                                    
                                            <a href="<?php echo site_url('pemesanan') ?>" class="btn btn-default">Cancel</a>
                                        </div>
                                    </div>
                                    
                            </div>
                            
                          </div>
                      

   </form></div>
                            
                          </div></div>
                            
                          </div>
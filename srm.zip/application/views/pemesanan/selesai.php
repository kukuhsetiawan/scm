
        <div id="page-wrapper">
            <div class="main-page">

           
                   

                <div class="grid-section">
                        <h2 class="hdg">Pemesanan</h2>
                    <div class="row mb40">
                                <div class="col-md-12 table-grid">
                                <div class="panel panel-widget">
                                    <div class="bs-docs-example">
                                        
<!-- isi content -->
<div class="row" style="margin-bottom: 10px">
            <div class="col-md-4">
                 
               <!-- <?php echo anchor(site_url('pemesanan/create'),'Create', 'class="btn btn-primary"'); ?> -->
            </div>
            <div class="col-md-4 text-center">
                <div style="margin-top: 8px" id="message">
                    <?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
                </div>
            </div>
            <div class="col-md-1 text-right">
            </div>
            <div class="col-md-3 text-right">
                
            </div>
        </div>

        <table class="table table-striped" style="margin-bottom: 10px">
            <tr>
		<!-- <th>Kode Pemesanan</th> -->
		<th>Nama Retail</th>
        <th>Tgl Pemesanan</th>

		<!-- <th>User</th> -->
        <th>Jumlah</th>
		<th>Status Pemesanan</th>
        <th>Tanggal Selesai</th>
            </tr><?php
            foreach ($content as $pemesanan)
            {
                ?>
                <tr><!-- 
			<td>P0000<?php echo $pemesanan->id_pemesanan ?></td> -->
            <td><?php echo $pemesanan->retail ?></td>
			<td><?php echo $pemesanan->tgl_pemesanan ?></td>
			<!-- <td><?php echo $pemesanan->id_user ?></td> -->
            <td><?php echo $pemesanan->jumlah ?></td>
			<td><?php echo $pemesanan->status_pemesanan ?></td>
            <td><?php echo $pemesanan->tgl_selesai ?></td>
			
		</tr>
                <?php
            }
            ?>
         <!--    <tr>
                <td colspan="5">Total Keseluruhan</td>
                <?php foreach ($total as $key): ?>
                    <td>Rp <?php echo $key->total_selesai ?>,-</td>
                <?php endforeach ?>
            </tr>
             <tr>
                <td colspan="5">Laba Keseluruhan</td>
                <?php foreach ($laba as $key): ?>
                    <td>Rp <?php echo $key->laba_selesai ?>,-</td>
                <?php endforeach ?>
            </tr> -->
        </table>
        

        


                                    </div>
                                </div>
                            </div>

                </div>
                </div>
                </div>

                </div>
                <div class="clearfix"> </div>
            </div>
            </div>
            </div>



   

        <div id="page-wrapper">
            <div class="main-page">

           
                   

                <div class="grid-section">
                        <h2 class="hdg">Pemesanan</h2>
                    <div class="row mb40">
                                <div class="col-md-12 table-grid">
                                <div class="panel panel-widget">
                                    <div class="bs-docs-example">
                                        
<!-- isi content -->
<div class="row" style="margin-bottom: 10px">
            <div class="col-md-4">
                 <!-- <a href="<?=base_url() ?>pemesanan/pesan" title="Tambah data"><img src="<?=base_url() ?>add.png" width="75" ></a> -->
               <?php echo anchor(site_url('pemesanan/pesan'),'Create', 'class="btn btn-primary"'); ?>
            </div>
            <div class="col-md-4 text-center">
                <div style="margin-top: 8px" id="message">
                    <?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
                </div>
            </div>
            <div class="col-md-1 text-right">
            </div>
            <div class="col-md-3 text-right">
                <form action="<?php echo site_url('pemesanan/index'); ?>" class="form-inline" method="get">
                    <div class="input-group">
                        <input type="text" class="form-control" name="q" value="<?php echo $q; ?>">
                        <span class="input-group-btn">
                            <?php 
                                if ($q <> '')
                                {
                                    ?>
                                    <a href="<?php echo site_url('pemesanan'); ?>" class="btn btn-default">Reset</a>
                                    <?php
                                }
                            ?>
                          <button class="btn btn-primary" type="submit">Search</button>
                        </span>
                    </div>
                </form>
            </div>
        </div>

        <table class="table table-striped" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>Kode</th>

		<th>Tanggal Pesan</th>
		<!-- <th>User</th> -->
		
        <th>Nama Produk</th>
        <th>Satuan Produk /Ball</th>
        <th>Satuan kg</th>
        <th>Total Bayar</th>
        <th>Bayar Dp</th>
        <th>Sisa Bayar</th>
		<th>Status Pemesanan</th>
        <th>Tanggal Selesai</th>
        <th>Action</th> 
  
            </tr><?php
            foreach ($pemesanan_data as $pemesanan)
            {
                ?>
                <tr>
			<td width="80px"><?php echo ++$start ?></td>
			<td>Pemesanan : P0000<?php echo $pemesanan->id_pemesanan ?> <br>Retail : <?php echo $pemesanan->retail ?></td>
			<td><?php echo $pemesanan->tgl_pemesanan ?></td>
			<!-- <td><?php echo $pemesanan->id_user ?></td> -->
			
            <td><?php echo $pemesanan->nama_produk ?></td>
            <td><?php echo $pemesanan->jumlah/5 ?></td>
            <td><?php echo $pemesanan->jumlah ?></td>
            <td><?php echo $pemesanan->total_bayar ?></td>
             <td><?php echo $pemesanan->dp ?></td>
            <?php if ($pemesanan->status_pemesanan== "selesai") { ?>
                <td class="btn danger">LUNAS</td>
                <td><?php echo $pemesanan->status_pemesanan ?></td>
                <td><?php echo $pemesanan->tgl_selesai ?></td>
            <?php } else { ?>
               
                <td><?php echo $pemesanan->total_bayar-$pemesanan->dp ?></td>
                <td><?php echo $pemesanan->status_pemesanan ?></td>
                <td>Belum dikonfirmasi</td>
            <?php } ?>
            
			
        	
				<?php if ($this->session->userdata('role')=="Pemesanan") { ?>
                <td style="text-align:center" width="200px">
                   <?php if ($pemesanan->tgl_selesai==null): ?>
                       
                   <?php else: ?>
                       <?php echo anchor(site_url('pemesanan/cetak_nota/'.$pemesanan->suffix),'<i class="fa fa-print"></i>Cetak Nota',array('title'=>' Cetak Nota','class'=>'btn btn-default btn-sm')); ?>
                   <?php endif ?>
                </td> 
                <?php } else { ?>
                <td style="text-align:center" width="200px">
                    <?php if ($pemesanan->tgl_selesai==null): ?>
                       <?php echo anchor(site_url('pemesanan/update/'.$pemesanan->id_pemesanan),'<i class="fa fa-pencil-square-o"></i>konfirmasi status',array('title'=>'konfirmasi status','class'=>'btn btn-warning btn-sm')); ?>
                   <?php else: ?>
                      <a href="" class="btn btn-warning btn-sm" disabled><i class="fa fa-pencil-square-o"></i>Sudah Dikonfirmasi</a>
                   <?php endif ?>
                   
                </td> 
                <?php }
                ?>
			
		</tr>
                <?php
            }
            ?>
        </table>
        <div class="row">
            <div class="col-md-6">
                <a href="#" class="btn btn-primary">Total Record : <?php echo $total_rows ?></a>
		<?php echo anchor(site_url('pemesanan/excel'), 'Excel', 'class="btn btn-primary"'); ?>
		<?php echo anchor(site_url('pemesanan/word'), 'Word', 'class="btn btn-primary"'); ?>
	    </div>
            <div class="col-md-6 text-right">
                <?php echo $pagination ?>
            </div>
        </div>

        


                                    </div>
                                </div>
                            </div>

                </div>
                </div>
                </div>

                </div>
                <div class="clearfix"> </div>
            </div>
            </div>
            </div>



   
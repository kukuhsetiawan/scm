
<div id="page-wrapper">
            <div class="main-page">
                <div class="validation-section">
                    <h2>Pemesanan</h2>
<form id="defaultForm" method="post" class="form-horizontal" action="<?php echo $action; ?>">

                    <?php for ($i=0; $i < $_POST['transaksi']; $i++) { ?>

                    <div class="col-md-4 validation-grid">
                        
                        <div class="validation-grid1">
                            <div class="valid-top">
                                


                                    


                                    <div class="form-group">

                                            <input type="hidden" class="form-control" name="data[<?= $i ?>][tgl_pemesanan]" id="tgl_pemesanan" placeholder="Tgl Pemesanan" value="<?php echo date("Y-m-d H:i:s"); ?>" />
                                            <input type="hidden" class="form-control" name="data[<?= $i ?>][suffix]" value="<?php echo date("YmdHis"); ?>" />  
                                    <input type="hidden" class="form-control" name="data[<?= $i ?>][status_pemesanan]" id="status_pemesanan" value="proses" />
                                  	<input type="hidden" class="form-control" name="data[<?= $i ?>][id_user]" id="id_user" placeholder="Id User" value="<?php echo $this->session->userdata('username'); ?>" />
                                  	     <div class="form-group">
                                              <label class="col-lg-3 control-label" for="double">Retail </label>
                                             <div class="col-lg-5"> 
                                                  <select name="data[<?= $i ?>][retail]" class="form-control">
                                                      <option>--Pilih Retail--</option>
                                                     <?php foreach ($content_retail as $key): ?>
                                                          <option value="<?php echo $key->nama; ?>"><?php echo $key->id_retail; ?> - <?php echo $key->nama; ?></option>
                                                     <?php endforeach ?>
                                                  </select>
                                                  
                                             </div>
                                          </div>
                                  	    <div class="form-group">
                                              <label class="col-lg-3 control-label" for="double">Nama Produk </label>
                                             <div class="col-lg-5"> 
                                                  <select name="data[<?= $i ?>][id_produk]" class="form-control">
                                                      <option>--Pilih Produk--</option>
                                                     <?php foreach ($content_produk as $key): ?>
                                                          <option value="<?php echo $key->id_produk; ?>"><?php echo $key->nama_produk; ?></option>
                                                     <?php endforeach ?>
                                                  </select>
                                                  <input type="text" placeholder="Jumlah Produk Yang dipesan" name="data[<?= $i ?>][jumlah]" class="form-control">
                                             </div>
                                          </div>

                                         
                                  	    <input type="hidden" name="data[<?= $i ?>][id_pemesanan]" value="<?php echo $id_pemesanan; ?>" /> 
	    
                                    
                            </div>
                            
                          </div>
                      </div>
                </div>
                <?php } ?>
   <div class="form-group">
                                        <div class="col-lg-9 col-lg-offset-3">
                                            <button type="submit" class="btn btn-primary"><?php echo $button ?></button>
                                       
                                    
                                            <a href="<?php echo site_url('pemesanan/pesan') ?>" class="btn btn-default">Cancel</a>
                                        </div>
                                    </div>

   </form>
   </div>
            </div></div>
                            
                          </div>
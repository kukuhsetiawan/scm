<body onload="window.print()">
<img src="<?php echo base_url(); ?>folderfoto/logo_login.png" alt="" width="150"><br><br>
<?php foreach ($total as $key): ?>
    Nomor Nota : N<?php echo date("Ymd"); ?> <br>
    Tanggal Selesai : <?php echo $key->tgl_selesai; ?><br>
    
    DP :  <?php echo $key->dp; ?><br>
    Sisa :  <?php echo $key->total_bayar-$key->dp; ?><br> <br>
    
<?php endforeach ?>
        <table class="table table-striped" style="margin-bottom: 10px" border="1">
            <tr>
		<th>No.</th>
		<th>nama</th>
		<th>Jumlah</th>
            </tr><?php
            $start = 0;
            foreach ($rincian as $key)
            {
                ?>
                <tr>
			<td><?php echo ++$start ?></td>
			<td><?php echo $key->nama_produk ?></td>
			<td><?php echo $key->total_bayar ?></td>
		
		</tr>
                <?php
            }
            ?>
        <?php foreach ($total as $key): ?>
        <tr><td colspan="2">Total bayar</td><td><b><?php echo $key->total_bayar; ?></b></td></tr>    
        <?php endforeach ?>
        
        </table> <br> <br>
        <?php echo date("Y-m-d"); ?> <br>
        Tanda Terima, <br><br>
        <br><br>

        

   

<div id="page-wrapper">
            <div class="main-page">
                <div class="validation-section">
                    <h2></h2>
                    <div class="col-md-6 validation-grid">
                        <h4><span>Pemesanan</span> </h4>
                        <div class="validation-grid1">
                            <div class="valid-top">

                                <?php foreach ($content as $key): ?>
                                  <form id="defaultForm" method="post" class="form-horizontal" action="<?php echo base_url().'pemesanan/konfirm_status/'.$key->id_pemesanan; ?>">
                                <?php endforeach ?>
                                    <div class="form-group">

	    

	    
          <input type="hidden" class="form-control" name="tgl_selesai" id="tgl_selesai" placeholder="Tgl Pemesanan" value="<?php echo date("Y-m-d H:i:s"); ?>" />
	  
	    <div class="form-group">
            <label class="col-lg-3 control-label" for="enum">Status Pemesanan <?php echo form_error('status_pemesanan') ?></label>
           <div class="col-lg-5"> 
           <select name="status_pemesanan" class="form-control">
               <option>--Status Pemesanan--</option>
               <option value="proses">Proses</option>

               
               <option value="selesai">Selesai</option>
           </select>
          
        </div>

                                    <div class="form-group">
                                        <div class="col-lg-9 col-lg-offset-3">
                                            <button type="submit" class="btn btn-primary"><?php echo $button ?></button>
                                       

 
	    
                                    
                                            <a href="<?php echo site_url('pemesanan') ?>" class="btn btn-default">Cancel</a>
                                        </div>
                                    </div>

	
</div>
</form>
</div>
</div></div>
</div>
</div>
</div>
   </div>
</div>
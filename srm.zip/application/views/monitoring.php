
        <div id="page-wrapper">
            <div class="main-page">

           
                   

                <div class="grid-section">
                        <h2 class="hdg">Safety Stock</h2>
                    <div class="row mb40">
                                <div class="col-md-12 table-grid">
                                <div class="panel panel-widget">
                                    <div class="bs-docs-example">
                                        
<!-- isi content -->
<div class="row" style="margin-bottom: 10px">
            <div class="col-md-4">
                 <!-- <a href="<?=base_url() ?>bom/create" title="Tambah data"><img src="<?=base_url() ?>add.png" width="75" ></a> -->
               <!-- <?php echo anchor(site_url('bom/create'),'Create', 'class="btn btn-primary"'); ?> -->
            </div>
            <div class="col-md-4 text-center">
                <div style="margin-top: 8px" id="message">
                    <?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
                </div>
            </div>
            <div class="col-md-1 text-right">
            </div>
            <div class="col-md-3 text-right">
               <!--  <form action="<?php echo site_url('bom/index'); ?>" class="form-inline" method="get">
                    <div class="input-group">
                        <input type="text" class="form-control" name="q" value="<?php echo $q; ?>">
                        <span class="input-group-btn">
                            <?php 
                                if ($q <> '')
                                {
                                    ?>
                                    <a href="<?php echo site_url('bom'); ?>" class="btn btn-default">Reset</a>
                                    <?php
                                }
                            ?>
                          <button class="btn btn-primary" type="submit">Search</button>
                        </span>
                    </div>
                </form> -->
            </div>
        </div>

        <table class="table table-striped" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
        <th>Nama Bahan Baku</th>
        <th>Bahan Baku Yang Dibutuhkan</th>
        <th>Stok Bahan Baku</th>
        <th>Hasil Hitung</th>
        <th>Safety Stock</th>
        <th>Status</th>
        <!-- <th>Action</th> -->
            </tr><?php
            foreach ($bom_data->result() as $bom)
            {
                ?>
                <tr>
            <td width="80px"><?php echo ++$start ?></td>
            <td><?php echo $bom->n_bahan_baku ?></td>
            <td><?php echo $bom->j_kebutuhan.' '.$bom->s_bahan_baku ?></td>
            <td><?php echo abs($bom->stock).' '.$bom->s_bahan_baku ?></td>
            <td><?php echo ($bom->j_kebutuhan*3/31) ?></td>
            <td><?php echo ceil($bom->j_kebutuhan*3/31) ?></td>

            <?php if ($bom->j_kebutuhan < abs($bom->stock)){ ?>
                <td><p class="bg-primary">Pesediaan Aman</p></td>
                <!-- <td></td> -->
            <?php } else { ?>
                <td><p class="bg-danger">Pesediaan Tidak Aman</p></td>
                <!-- <td><a href="<?php base_url(); ?>bahan_baku/create" class="btn btn-success">Pengadaan</a></td> -->
            <?php } ?>
            

          
        </tr>
                <?php
            }
            ?>
        </table>
        <div class="row">
            <div class="col-md-6">
 
        </div>
            <div class="col-md-6 text-right">
                <?php echo $pagination ?>
            </div>
        </div>

        


                                    </div>
                                </div>
                            </div>

                </div>
                </div>
                </div>

                </div>
                <div class="clearfix"> </div>
            </div>
            </div>
            </div>



   
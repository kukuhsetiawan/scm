
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Daftar_pembelian_bahan_baku <?php echo $button ?></h2>
         <div class="box-body">
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="date">Tgl Pemesanan <?php echo form_error('tgl_pemesanan') ?></label>
            <input type="text" class="form-control" name="tgl_pemesanan" id="tgl_pemesanan" placeholder="Tgl Pemesanan" value="<?php echo $tgl_pemesanan; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Id User <?php echo form_error('id_user') ?></label>
            <input type="text" class="form-control" name="id_user" id="id_user" placeholder="Id User" value="<?php echo $id_user; ?>" />
        </div>
	    <div class="form-group">
            <label for="enum">Status Pemesanan <?php echo form_error('status_pemesanan') ?></label>
            <input type="text" class="form-control" name="status_pemesanan" id="status_pemesanan" placeholder="Status Pemesanan" value="<?php echo $status_pemesanan; ?>" />
        </div>
	    <div class="form-group">
            <label for="double">Total Beli <?php echo form_error('total_beli') ?></label>
            <input type="text" class="form-control" name="total_beli" id="total_beli" placeholder="Total Beli" value="<?php echo $total_beli; ?>" />
        </div>
	    <input type="hidden" name="no_kebutuhan" value="<?php echo $no_kebutuhan; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('daftar_pembelian_bahan_baku') ?>" class="btn btn-default">Cancel</a>
	</form>
    </div>

        </div>
    </section>
    </div>
    </section>    
    

        
        <section class="content">
        <div class="row">
         <section class="col-lg-12 connectedSortable">
         <div class="box">
        <h2 style="margin-top:0px">Daftar_pembelian_bahan_baku Read</h2>
        <div class="box-body">
        <table class="table">
	    <tr><td>Tgl Pemesanan</td><td><?php echo $tgl_pemesanan; ?></td></tr>
	    <tr><td>Id User</td><td><?php echo $id_user; ?></td></tr>
	    <tr><td>Status Pemesanan</td><td><?php echo $status_pemesanan; ?></td></tr>
	    <tr><td>Total Beli</td><td><?php echo $total_beli; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('daftar_pembelian_bahan_baku') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </div>

        </div>
    </section>
    </div>
    </section>    
    
        
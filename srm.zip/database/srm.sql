-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 21 Jul 2017 pada 05.45
-- Versi Server: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `srm`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `bahan_baku`
--

CREATE TABLE IF NOT EXISTS `bahan_baku` (
  `id` int(11) NOT NULL,
  `id_bahan_baku` varchar(10) DEFAULT NULL,
  `jenis_bahan_baku` varchar(20) DEFAULT NULL,
  `nama_bahan_baku` varchar(60) DEFAULT NULL,
  `id_supplier` varchar(20) DEFAULT NULL,
  `harga_bahan_baku` double DEFAULT NULL,
  `satuan` varchar(10) DEFAULT NULL,
  `stock_aman` int(11) DEFAULT NULL,
  `keterangan` text
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bahan_baku`
--

INSERT INTO `bahan_baku` (`id`, `id_bahan_baku`, `jenis_bahan_baku`, `nama_bahan_baku`, `id_supplier`, `harga_bahan_baku`, `satuan`, `stock_aman`, `keterangan`) VALUES
(1, 'BB-U-TM', 'Utama', 'Tempe', 'S-IB', 10000, 'kg', 50, 'Karna di kirim setiap hari 50 kg'),
(2, 'BB-U-TB', 'Utama', 'Tepung Beras', 'S-CS', 10000, 'kg', 19, 'Bahan Baku di stok'),
(3, 'BB-U-ACI', 'Utama', 'ACI', 'S-CS', 10000, 'kg', 6, 'Bahan Baku di Stok'),
(4, 'BB-U-BB', 'Utama', 'Bumbu Basah', 'S-AY', 10000, 'kg', 1, 'Bahan Baku di Stok'),
(5, 'BB-T_GU', 'Tambahan', 'Gula', 'S-CS', 2500, 'set', 0, 'Bahan Baku Tambahan'),
(6, 'BB-T_GR', 'Tambahan', 'Garam', 'S-CS', 1300, 'set', 0, 'Bahan Baku Tambahan'),
(7, 'BB-T-PC', 'Tambahan', 'Pecin', 'S-CS', 2400, 'runtuy', 12, 'Bahan Baku Tambahan'),
(8, 'BB-T-GAS', 'Tambahan', 'GAS', 'S-TA', 25000, 'Tabung', 0, 'Bahan Baku Tambahan'),
(9, 'BB-K-PL', 'Kemasan', 'Plastik', 'S-TR', 20000, 'Bundel', 0, 'Kemasan'),
(10, 'BB-T-CABAI', 'Tambahan', 'Cabai', 'S-AY', 20000, 'kg', 1, 'Bahan Baku Tambahan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `bahan_baku_stok`
--

CREATE TABLE IF NOT EXISTS `bahan_baku_stok` (
  `id` int(11) NOT NULL,
  `id_bahan_baku_stok` varchar(10) DEFAULT NULL,
  `jenis_bahan_baku` varchar(20) DEFAULT NULL,
  `nama_bahan_baku` varchar(60) DEFAULT NULL,
  `id_supplier` varchar(20) DEFAULT NULL,
  `harga_bahan_baku` bigint(20) DEFAULT NULL,
  `satuan` varchar(10) DEFAULT NULL,
  `stock_aman` int(11) DEFAULT NULL,
  `keterangan` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `bahan_baku_tidakstok`
--

CREATE TABLE IF NOT EXISTS `bahan_baku_tidakstok` (
  `id` int(11) NOT NULL,
  `id_bahan_baku_tidakstok` varchar(10) DEFAULT NULL,
  `nama_bahan_baku` varchar(60) DEFAULT NULL,
  `id_supplier` varchar(10) DEFAULT NULL,
  `harga_bahan_baku` double DEFAULT NULL,
  `satuan` varchar(10) DEFAULT NULL,
  `keterangan` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `bom`
--

CREATE TABLE IF NOT EXISTS `bom` (
  `id_bom` int(11) NOT NULL,
  `id_produk` int(11) DEFAULT NULL,
  `id_bahan_baku` varchar(10) DEFAULT NULL,
  `jumlah_kebutuhan` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bom`
--

INSERT INTO `bom` (`id_bom`, `id_produk`, `id_bahan_baku`, `jumlah_kebutuhan`) VALUES
(1, 1, '1', 20),
(2, 1, '2', 25),
(3, 1, '3', 13),
(4, 2, '3', 26),
(5, 2, '1', 5);

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_pembelian_bahan_baku`
--

CREATE TABLE IF NOT EXISTS `detail_pembelian_bahan_baku` (
  `id_detail_bahan_baku` int(11) NOT NULL,
  `id_pengadaan` int(10) DEFAULT NULL,
  `id_bahan_baku` varchar(10) DEFAULT NULL,
  `jumlah_kebutuhan` int(11) DEFAULT NULL,
  `harga` double DEFAULT NULL,
  `status_bahan_baku` enum('diterima','ditolak','pending') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_pemesanan`
--

CREATE TABLE IF NOT EXISTS `detail_pemesanan` (
  `no_pemesanan` int(11) NOT NULL,
  `id_pemesanan` int(10) DEFAULT NULL,
  `id_produk` int(10) DEFAULT NULL,
  `harga_produk` double DEFAULT NULL,
  `jumlah_beli` int(11) DEFAULT NULL,
  `satuan_produk` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
  `id` int(11) NOT NULL,
  `nama_kategori` varchar(50) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Struktur dari tabel `kendaraan`
--

CREATE TABLE IF NOT EXISTS `kendaraan` (
  `id` int(11) NOT NULL,
  `no_polisi` varchar(20) DEFAULT NULL,
  `jenis_kendaraan` varchar(20) DEFAULT NULL,
  `kapasitas` double DEFAULT NULL,
  `status_operasi` enum('jalan','kosong','service') DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kendaraan`
--

INSERT INTO `kendaraan` (`id`, `no_polisi`, `jenis_kendaraan`, `kapasitas`, `status_operasi`) VALUES
(1, 'D 4353 MS', 'Carry Pick Up', 700, 'jalan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemesanan`
--

CREATE TABLE IF NOT EXISTS `pemesanan` (
  `id_pemesanan` int(10) NOT NULL,
  `id_produk` int(11) DEFAULT NULL,
  `retail` varchar(100) DEFAULT NULL,
  `id_user` varchar(10) DEFAULT NULL,
  `tgl_pemesanan` datetime DEFAULT NULL,
  `bayar_dp` double DEFAULT NULL,
  `status_pemesanan` enum('tunggu','proses','selesai','batal','return') DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `tgl_selesai` datetime DEFAULT NULL,
  `suffix` varchar(50) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pemesanan`
--

INSERT INTO `pemesanan` (`id_pemesanan`, `id_produk`, `retail`, `id_user`, `tgl_pemesanan`, `bayar_dp`, `status_pemesanan`, `jumlah`, `tgl_selesai`, `suffix`) VALUES
(63, 1, 'Toko Kabita Sumedang', 'pemasaran', '2017-07-20 03:25:56', NULL, 'selesai', 10, '2017-07-20 03:29:08', '20170720032556'),
(65, 1, 'Toko Maya Rasa', 'pemasaran', '2017-07-20 18:29:42', NULL, 'proses', 20, NULL, '20170720182942');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengadaan`
--

CREATE TABLE IF NOT EXISTS `pengadaan` (
  `id` int(11) NOT NULL,
  `id_bahan_baku` varchar(50) DEFAULT NULL,
  `id_supplier` varchar(50) DEFAULT NULL,
  `jumlah_rencana_pemberlian` int(11) DEFAULT NULL,
  `tanggal_pembelian` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pengadaan`
--

INSERT INTO `pengadaan` (`id`, `id_bahan_baku`, `id_supplier`, `jumlah_rencana_pemberlian`, `tanggal_pembelian`) VALUES
(20, 'B000011', 'S00002', 16, '2017-02-24'),
(22, 'B000010', 'S00002', 15, '2017-02-03'),
(23, 'B000011', 'S00002', 16, '2017-02-21'),
(24, 'B000010', 'S00001', 15, '2017-02-23'),
(28, 'Kayu 8x8x200', 'S00001', 16, '2017-02-23'),
(30, 'Kayu 8x8x200', 'S00001', 16, '2017-02-24'),
(31, 'tepung', 'S00004', 106, '2017-07-18'),
(32, 'jenang', 'S00001', 16, '2017-07-18'),
(33, 'pemberi rasa', 'S00002', 4, '2017-07-18'),
(34, 'BB-U-TM', 'S-IB', 12, '2017-07-20');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengiriman`
--

CREATE TABLE IF NOT EXISTS `pengiriman` (
  `id` int(11) NOT NULL,
  `id_pemesanan` int(11) DEFAULT NULL,
  `tgl_pengiriman` date DEFAULT NULL,
  `kendaraan` varchar(20) DEFAULT NULL,
  `status_pengiriman` varchar(20) DEFAULT NULL,
  `supir` varchar(50) DEFAULT NULL,
  `alamat` text,
  `jarak` varchar(50) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pengiriman`
--

INSERT INTO `pengiriman` (`id`, `id_pemesanan`, `tgl_pengiriman`, `kendaraan`, `status_pengiriman`, `supir`, `alamat`, `jarak`) VALUES
(1, 63, '2017-07-20', 'Carry Pick Up', 'Dikirim', 'Opik', 'Jl. Bodogol, Ciwastra, Bandung', '9,5 km');

-- --------------------------------------------------------

--
-- Struktur dari tabel `peramalan_produk`
--

CREATE TABLE IF NOT EXISTS `peramalan_produk` (
  `id` int(11) NOT NULL,
  `nama_peramalan` varchar(50) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `produk` varchar(50) DEFAULT NULL,
  `jumlah_produk` double DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `peramalan_produk`
--

INSERT INTO `peramalan_produk` (`id`, `nama_peramalan`, `tanggal`, `produk`, `jumlah_produk`) VALUES
(2, 'peramalan 1', '2017-02-03', 'Tempe Manis', 18),
(3, 'Peramalan 2', '2017-02-10', 'Tempe Asin', 11),
(4, 'Peramalan 3', '2017-06-15', 'Tempe Pedas', 39),
(5, 'Peramalan 4', '2017-07-13', 'Tempe Gurih', 37);

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE IF NOT EXISTS `produk` (
  `id_produk` int(10) NOT NULL,
  `kode_produk` varchar(50) DEFAULT NULL,
  `nama_produk` varchar(100) DEFAULT NULL,
  `id_kategori` int(11) DEFAULT NULL,
  `satuan_produk` varchar(20) DEFAULT NULL,
  `harga` double DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id_produk`, `kode_produk`, `nama_produk`, `id_kategori`, `satuan_produk`, `harga`) VALUES
(1, 'P-TM-01', 'Tempe Manis', 1, 'pack', 175000),
(2, 'P-AS-01', 'Tempe Asin', 2, 'pack', 175000),
(3, 'P-PD-01', 'Tempe Pedas', 3, 'pack', 175000),
(4, 'P-OCM-01', 'Oncom', 1, 'pack', 180000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `retail`
--

CREATE TABLE IF NOT EXISTS `retail` (
  `id` int(11) NOT NULL,
  `id_retail` varchar(20) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `no_telp` varchar(20) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  `lokasi` varchar(20) DEFAULT NULL,
  `id_user` varchar(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `retail`
--

INSERT INTO `retail` (`id`, `id_retail`, `nama`, `no_telp`, `alamat`, `lokasi`, `id_user`) VALUES
(1, 'R-MR', 'Toko Maya Rasa', '082147483647', 'Jl. Bodogol, Ciwastra', 'Bandung', 'id_Pemasaran'),
(2, 'R-SK', 'Toko Saki Kembar', '087770226565', 'Jl. Jembar, Cicadas', 'Bandung', 'id_Pemasaran'),
(3, 'R-MH', 'Toko Mahdana', '081220188526', 'Jl. Gudang Utara, Bandung', 'Bandung', 'id_Pemasaran'),
(4, 'R-MB', 'Toko Makanan Bandung', '082120096624', 'Jl. Cijambe, Ujung Berung', 'Bandung', 'id_Pemasaran'),
(5, 'R-KS', 'Toko Kabita Sumedang', '081313407061', 'Jl. Umar Wirahadikusumah', 'Sumedang', 'id_Pemasaran'),
(6, 'R-BG', 'Toko Bahagia', '081222654610', 'Jl.Ir. H.Djuanda, SImpang Dago', 'Bandung', 'id_Pemasaran'),
(7, 'R-SS', 'Toko San-San', '081321334522', 'Jl.Purwakarta No.2 Antapani', 'Bandung', 'id_Pemasaran');

-- --------------------------------------------------------

--
-- Struktur dari tabel `supplier`
--

CREATE TABLE IF NOT EXISTS `supplier` (
  `id` int(11) NOT NULL,
  `id_supplier` varchar(10) DEFAULT NULL,
  `nama_supplier` varchar(40) DEFAULT NULL,
  `telp_supp` varchar(20) DEFAULT NULL,
  `alamat_supplier` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `supplier`
--

INSERT INTO `supplier` (`id`, `id_supplier`, `nama_supplier`, `telp_supp`, `alamat_supplier`) VALUES
(1, 'S-IB', 'Ibu Ayu  < Tempe>', '081223540618', 'Jl. Nagrog, Ujung Berung'),
(2, 'S-AY', 'Abah Yana < Bumbu>', '081536351082', 'Pasar Kosambi'),
(3, 'S-CS', 'Cv Sujana < BB>', '081729105657', 'Pasar Kosambi'),
(4, 'S-TA', 'Toko Ade < GAS>', '083829064368', 'Pasar Kosambi'),
(5, 'S-TR', 'Toko Romo < Plastik>', '085373077136', 'Pasar Kosambi'),
(6, 'S-PD', 'Pak Dededn < Oncom>', '081223140667', 'Jl. Padasuka, Cicaheum'),
(7, 'S-MU', 'Mas Ujo < Tempe>', '082120096624', 'Jl. Sindang Sari, Ujung Berung'),
(8, 'S-IY', 'Ibu Yani < Bumbu>', '08131228361', 'Pasar Kosambi'),
(9, 'S-TM', 'Toko Murni < BB>', '081323407061', 'Pasar Kosambi'),
(10, 'S-TA', 'Toko Abang < GAS>', '08134222070', 'Pasar Kosambi'),
(11, 'S-TMK', 'Toko Makmur', '08170207761', 'Pasar Kosambi'),
(12, 'S-PY', 'Pak Yana < Oncom>', '087721223677', 'Jl. Ujung Berung');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `role` enum('Pemilik','Keuangan','Pemasaran','Pengadaan','Gudang','Produksi','Distribusi') DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `nama` varchar(20) DEFAULT NULL,
  `jabatan` varchar(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `role`, `email`, `nama`, `jabatan`) VALUES
(10, 'gudang', 'a80dd043eb5b682b4148b9fc2b0feabb2c606fff', 'Gudang', 'gudang@gmaill.com', '', ''),
(11, 'pengadaan', 'b94d0178c96e09ac4c00c8c89fc74c25c62206a5', 'Pengadaan', 'pengadaan@gmail.com', '', ''),
(15, 'keuangan', '1f931595786f2f178358d0af5fe4d75eaee46819', 'Keuangan', 'keuangan@gmail.com', '', ''),
(16, 'pemilik', '1f86485ac9c8b00fb355bd1eb1c86d937f6d457c', 'Pemilik', 'pemilik@gmail.com', '', ''),
(17, 'pemasaran', 'ce960f3194f2eddaecd3e12a3f34145dcd624f73', 'Pemasaran', 'pemasaran@gmail.com', '', ''),
(18, 'produksi', '6e3bf9569d685dc740285417951b943b2452c2b5', 'Produksi', 'produksi@gmail.com', '', ''),
(19, 'distribusi', 'acfbc89be2bf31b05c6fd724690ed7f9faa4d4b0', 'Distribusi', 'distribusi@gmail.com', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bahan_baku`
--
ALTER TABLE `bahan_baku`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bahan_baku_supplier_fk` (`id_supplier`);

--
-- Indexes for table `bahan_baku_stok`
--
ALTER TABLE `bahan_baku_stok`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bahan_baku_tidakstok`
--
ALTER TABLE `bahan_baku_tidakstok`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bom`
--
ALTER TABLE `bom`
  ADD PRIMARY KEY (`id_bom`),
  ADD KEY `bom_produk_fk` (`id_produk`),
  ADD KEY `bom_bahan_baku_fk` (`id_bahan_baku`);

--
-- Indexes for table `detail_pembelian_bahan_baku`
--
ALTER TABLE `detail_pembelian_bahan_baku`
  ADD PRIMARY KEY (`id_detail_bahan_baku`),
  ADD KEY `detail_pembelian_bahan_baku_bahan_baku_fk` (`id_bahan_baku`),
  ADD KEY `detail_pembelian_bahan_baku_pengadaan_fk` (`id_pengadaan`);

--
-- Indexes for table `detail_pemesanan`
--
ALTER TABLE `detail_pemesanan`
  ADD PRIMARY KEY (`no_pemesanan`),
  ADD KEY `detail_pemesanan_pemesanan_fk` (`id_pemesanan`),
  ADD KEY `detail_pemesanan_produk_fk` (`id_produk`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kategori_user_fk` (`id_user`);

--
-- Indexes for table `kendaraan`
--
ALTER TABLE `kendaraan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemesanan`
--
ALTER TABLE `pemesanan`
  ADD PRIMARY KEY (`id_pemesanan`);

--
-- Indexes for table `pengadaan`
--
ALTER TABLE `pengadaan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pengiriman`
--
ALTER TABLE `pengiriman`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pengiriman_pemesanan_fk` (`id_pemesanan`),
  ADD KEY `pengiriman_kendaraan_fk` (`kendaraan`),
  ADD KEY `pengiriman_supir_fk` (`supir`);

--
-- Indexes for table `peramalan_produk`
--
ALTER TABLE `peramalan_produk`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`),
  ADD KEY `produk_produk_kategori_fk` (`id_kategori`);

--
-- Indexes for table `retail`
--
ALTER TABLE `retail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `retail_user_fk` (`id_user`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bahan_baku`
--
ALTER TABLE `bahan_baku`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `bahan_baku_stok`
--
ALTER TABLE `bahan_baku_stok`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `bahan_baku_tidakstok`
--
ALTER TABLE `bahan_baku_tidakstok`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `bom`
--
ALTER TABLE `bom`
  MODIFY `id_bom` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `detail_pembelian_bahan_baku`
--
ALTER TABLE `detail_pembelian_bahan_baku`
  MODIFY `id_detail_bahan_baku` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `detail_pemesanan`
--
ALTER TABLE `detail_pemesanan`
  MODIFY `no_pemesanan` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `kendaraan`
--
ALTER TABLE `kendaraan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pemesanan`
--
ALTER TABLE `pemesanan`
  MODIFY `id_pemesanan` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=66;
--
-- AUTO_INCREMENT for table `pengadaan`
--
ALTER TABLE `pengadaan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `pengiriman`
--
ALTER TABLE `pengiriman`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `peramalan_produk`
--
ALTER TABLE `peramalan_produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `retail`
--
ALTER TABLE `retail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
